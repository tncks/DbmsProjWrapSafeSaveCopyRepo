const express = require('express');
const router = express.Router();
const usersController = require('../controllers/UsersController');
const ordersController = require('../controllers/OrdersController');
const isAuthenticated = require('../middleware/auth');
//const sql_connection = require('../config/db');
// HERE THIS FILE contains "GET" ROUTES ONLY

/* ordersController defined */
router.get('/placestock/:symbol', isAuthenticated, ordersController.myPlaceStockBySymbol);  // /placestock path 
router.get('/ordersalllog', isAuthenticated, ordersController.myOrdersAllLog);  // / path 
router.get('/transactions/:symbol', isAuthenticated, ordersController.myTransactionsBySymbol);  // / path    
router.get('/materialweblistofmine/:symbol', isAuthenticated, ordersController.myMaterialWebListOfMineBySymbol);  // / path 
router.get('/bid/:symbol', isAuthenticated, ordersController.myBidBySymbol);  // / path 
/* usersController defined */
router.get('/welcome', usersController.myWelcome);  // / path 
router.get('/home', isAuthenticated, usersController.myHome);  // / path 
router.get('/login', usersController.getMyLogin);  // / path 
router.get('/signup', usersController.getMySignup);  // / path 
router.get('/getFunds', isAuthenticated, usersController.myGetFunds);  // / path 
router.get('/getPortfolio', isAuthenticated, usersController.myGetPortfolio);  // / path
router.get('/getOrderCancelable', isAuthenticated, usersController.myGetOrderCancelable);  // / path 
/* new */
router.get('/apis/timelyorder', isAuthenticated, usersController.myTimelyOrder);
router.get('/apis/trades', isAuthenticated, usersController.myTrades);
router.get('/apis/namelyorder', isAuthenticated, usersController.myNamelyOrder);
router.get('/apis/norms', isAuthenticated, usersController.myNorms);
router.get('/apis/ownings', isAuthenticated, usersController.myOwnings);
router.get('/api/listups', usersController.myListups);









































































//
//router.get('/orderseespecific/:id', ordersController.getOrder , ordersController.myOrderSeeSpecificById);  // / path 
































//






module.exports = router;


