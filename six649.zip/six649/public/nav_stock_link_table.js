document.addEventListener("DOMContentLoaded", function () {
    const rows = document.querySelectorAll("#tb tr");

    rows.forEach(row => {
        /* 특정 하나의 주식의 무언가를 하는 링크, a href를 동적으로 세팅. 예를 들어, 테슬라 주식의 디테일을 보는 화면으로 이동 / 테슬라 주식을 buy 하는 화면으로 이동 / 테슬라 주식의 5단계 호가를 보는 화면으로 이동 등 */
        const cells = row.querySelectorAll("td"); // 모든 셀 선택
        const link_1_detail = row.querySelector(".more-link-1-detail"); // 링크 선택
        const link_2_buy = row.querySelector(".more-link-2-buy");
        const link_3_five = row.querySelector(".more-link-3-five");

        if (cells.length > 1 && link_1_detail) { // 3 번째 열이 있는지 확인
            const stSymbol = cells[2].textContent.trim(); // 3 번째 열의 ticker name 가져오기
            link_1_detail.addEventListener("click", () => {
                return;
                //window.location.href = `http://localhost:3001/home?stocksymbol=${stSymbol}`;
            });
            link_2_buy.addEventListener("click", () => {
                window.location.href = `http://localhost:3001/placestock/${stSymbol}?stocksymbol=${stSymbol}`;
            });
            link_3_five.addEventListener("click", () => {
                window.location.href = `http://localhost:3001/bid/${stSymbol}?stocksymbol=${stSymbol}`;
            });
            
        }
    });
});