function manualSearchSubmitStockName() {
    const searching = document.getElementById('stockName_').value;    // value?
    // 유효성 검사부터

    // if



    $.get('/apis/namelyorder', { searching: searching }, function (res) {
        reflectSearchToUserScreen(res.orders);
    });
}
function reflectSearchToUserScreen(arg) {

    const tbody_ = document.getElementById('mainBody');
    tbody_.innerHTML = '';

    if (typeof arg !== 'undefined' && arg && arg.length > 0) {
        arg.forEach(function (data) {
            const row = document.createElement('tr');
            row.innerHTML = `
            <td>${data.StockName}</td>
            <td>${data.StockSymbol}</td>
            <td>${data.OrderType}</td>
            <td>${data.NumShares}</td>
            <td>${data.CusAccNum}</td>
            <td>${data.Timestamp_}</td>
            <td>${data.PriceType}</td>
            <td>${data.StopPrice}</td>
            <td>&nbsp;</td>
            <td>${data.CurSharePrice}</td>
            <td>${data.isPartiallyFilled}</td>
            <td>${data.Completed}</td>
            <td>${data.OriginalNumShares}</td>
        `;
            tbody_.appendChild(row);
        });
    } else {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td colspan="13">No data found.</td>
            
        `;
        tbody_.appendChild(row);
    }
}








function manualSearchSubmitStockName_() {
    const searching_ = document.getElementById('stockName__').value;    // value?
    // 유효성 검사부터

    // if



    $.get('/apis/norms', { searching_: searching_ }, function (res) {
        reflectSearchToUserScreen_(res.data);
    });
}
function reflectSearchToUserScreen_(trades) {

    const tbody_ = document.getElementById('transactionsBody');
    tbody_.innerHTML = '';

    if (typeof trades !== 'undefined' && trades && trades.length > 0) {
        trades.forEach(function (data) {
            const row = document.createElement('tr');
            row.innerHTML = `
            <td>${data.StockName}</td>
            <td>${data.Symbol}</td>
            <td>${data.TradedTimeAt}</td>
            <td>${data.Price}</td>
            <td>${data.TradeQuantity}</td>
            <td>${data.TradePosition}</td>
        `;
            tbody_.appendChild(row);
        });
    } else {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td colspan="6">No data found.</td>
        `;
        tbody_.appendChild(row);
    }
}











function manualSearchSubmitStockName3() {
    const searching = document.getElementById('stockName3').value;    // value?
    // 유효성 검사부터

    // if



    $.get('/apis/listups', { searching: searching }, function (res) {
        reflectSearchToUserScreen3(res.data);
    });
}
function reflectSearchToUserScreen3(arg) {

    const tbody = document.getElementById('tableBody');
    tbody.innerHTML = '';

    if (typeof arg !== 'undefined' && arg && arg.length > 0) {
        arg.forEach(function (data) {
            const row = document.createElement('tr');
            row.setAttribute('style', `z-index: 1`);
            row.innerHTML = `
            <td width="50"> </td>
            <td>${data.stockname}</td>
            <td>${data.stocksymbol}</td>
            <td>${data.current_price} 원</td>
            <td>${data.change_percent} %</td>
            <td style="cursor: pointer;" class="more-link-1-detail">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
            <td style="cursor: pointer;" class="more-link-2-buy">Trade&gt;</td>
            <td style="cursor: pointer;" class="more-link-3-five">Five&gt;</td>      
        `;
            tbody.appendChild(row);
        });
    } else {
        const row = document.createElement('tr');
        row.setAttribute('style', `z-index: 1`);
        row.innerHTML = `
            <td></td>
            <td height="40">No data found.</td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
        `;
        tbody.appendChild(row);
    }


    const rows = document.querySelectorAll("#tb tr");
    rows.forEach(row => {
        /* 특정 하나의 주식의 무언가를 하는 링크, a href를 동적으로 세팅. 예를 들어, 테슬라 주식의 디테일을 보는 화면으로 이동 / 테슬라 주식을 buy 하는 화면으로 이동 / 테슬라 주식의 5단계 호가를 보는 화면으로 이동 등 */
        const cells = row.querySelectorAll("td"); // 모든 셀 선택
        const link_1_detail = row.querySelector(".more-link-1-detail"); // 링크 선택
        const link_2_buy = row.querySelector(".more-link-2-buy");
        const link_3_five = row.querySelector(".more-link-3-five");

        if (cells.length > 1 && link_1_detail) { // 3 번째 열이 있는지 확인
            const stSymbol = cells[2].textContent.trim(); // 3 번째 열의 ticker name 가져오기
            link_1_detail.addEventListener("click", () => {
                return;
                //window.location.href = `http://localhost:3001/home?stocksymbol=${stSymbol}`;
            });
            link_2_buy.addEventListener("click", () => {
                window.location.href = `http://localhost:3001/placestock/${stSymbol}?stocksymbol=${stSymbol}`;
            });
            link_3_five.addEventListener("click", () => {
                window.location.href = `http://localhost:3001/bid/${stSymbol}?stocksymbol=${stSymbol}`;
            });

        }
    });

    new FixedTable({ fullMode: false });
}

