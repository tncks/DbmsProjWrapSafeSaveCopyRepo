const express_session = require('express-session');
const session_info = {
    secret: 'abIASDJWasodhwAHWagQ',
    resave: false,
    saveUninitialized: true,
    cookie: {
        secure: false,
        maxAge: 1000 * 60 * 60  // 1 hour expire setting
    }
}
const session = express_session(session_info);

module.exports = session;