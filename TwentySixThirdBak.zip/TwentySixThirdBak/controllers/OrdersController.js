const sql_connection = require('../config/db');
const ejs = require('ejs');

const { getWelcomePage, getLoginPage, getSignupPage, getFivePreferPricePage, getPlaceStockPage, getOrdersPage, getTransactionsPage, getHomePage, getMyIndexTest, getMyListOfMineTest } = require('../shared');



// POST(+small amount of GET) METHOD (Focusing on POST, not neccesarily GET)
exports.createOrder = (req, res) => {
    const p_Data = req.body;
    for (const key in p_Data) {
        if (p_Data.hasOwnProperty(key)) {
            console.log(`${key}: ${p_Data[key]}`);
        }
    }

    console.log(p_Data);
    console.log('post method');
    console.log('path:   ~/api/orders');
    console.log('c_o__OrdersController_js');
    console.log('routing success!!');
    res.json({ message: 'Greatly Received: additional msg: createOrder Binding (OrdersController_js test).' });
    //res.send('createOrder Binding (OrdersController_js test)');
    console.log('res send() completed.');
};

exports.getOrder = (req, res, next) => {
    let order;
    try {
        const my_custom_select_query = `SELECT * from order_ where OrderId = ?`;

        sql_connection.query(my_custom_select_query, [req.params.id], (err, results) => {
            if (err) throw err;

            if (results.length > 0) {
                order = results[0];
                res.order = order;
                next();
            } else {
                // order is null (result is null)
                return res.status(404).json({ message: 'Order does not exist. ' });
            }
        })


    } catch (err) {
        return res.status(500).json({ message: err.message })
    }

};


const saveTransactionArr = async (transactionArr) => {

    if (!Array.isArray(transactionArr) || !transactionArr.length) {
        console.log('Transaction array is empty');
        return;
    }

    const my_custom_query = `INSERT INTO transact (OrderId, PricePerShare) VALUES (?, ?)`;

    let i = 0;

    try {
        while (i < transactionArr.length) {
            await sql_connection.promise().query(my_custom_query, [transactionArr[i].OrderId, transactionArr[i].PricePerShare]);
            i = i + 1;
        }
    } catch (err) {
        console.log('Error during saveTransactionArr:', err);
    }
};

const updateFilledOrderArr = async (filledOrderArr) => {
    if (!Array.isArray(filledOrderArr) || !filledOrderArr.length) {
        console.log('Filled order array is empty');
        return;
    }

    try {
        const my_custom_query = `UPDATE order_ SET NumShares = 0, Completed = 1 WHERE OrderId IN (${filledOrderArr.map(() => '?').join(', ')})`;
        const values = filledOrderArr;
        await sql_connection.promise().execute(my_custom_query, values);
    } catch (err) {
        console.log('Error during updateFilledOrderArr:', err);
    }
};
const queryAndMatchPairs = async (req, res, isNewOrder) => {

    let transactionArr = [];
    let filledOrderArr = [];
    let topPairResult;
    let { OrderId, NumShares } = req.body;
    let OriginalNumShares = NumShares;

    if (isNewOrder && req.body.NumShares <= 0) {
        return res.status(400).json({ message: 'Invalid order input' });
    }

    const searchForPair = async () => {
        const filterQuery = `
        SELECT * FROM order_
        WHERE StockSymbol = ?
        AND OrderType = ?
        AND StopPrice ${req.body.OrderType === 'Buy' ? '<=' : '>='} ?
        AND NumShares > 0
        AND Completed = 0
        ORDER BY StopPrice ${req.body.OrderType === 'Buy' ? 'ASC' : 'DESC'}, Timestamp_ ASC
        LIMIT 1
        `;

        const updateQuery = `
        UPDATE order_
        SET NumShares = NumShares - ?, isPartiallyFilled = 1
        WHERE OrderId = ?
        `;


        try {
            const [rows] = await sql_connection.promise().query(filterQuery, [req.body.StockSymbol, (req.body.OrderType === 'Buy') ? 'Sell' : 'Buy', parseInt(req.body.StopPrice)]);

            if (rows.length === 0) {
                return null;
            }

            let resulted_order = rows[0];

            await sql_connection.promise().query(updateQuery, [resulted_order.NumShares, resulted_order.OrderId]);
            const [mresults] = await sql_connection.promise().query(`select * from order_ where OrderId = ?`, [resulted_order.OrderId]);
            if (mresults.length > 0) {
                resulted_order = mresults[0];
            }

            return resulted_order;


        } catch (err) {
            console.log(err);
            return null;
        }
    }


    let RemainingNumShares = NumShares;
    while (RemainingNumShares > 0) {
        topPairResult = await searchForPair();

        // No matching trading pair is found
        if (!topPairResult) {
            try {
                //  myTmpBool 필요함 나중을 위해서 (코드 지우면 안될듯)
                let myTmpBool;
                if (RemainingNumShares > 0 && NumShares !== RemainingNumShares) {
                    myTmpBool = 1;
                }
                if (isNewOrder) {
                    // insert into query statement (save)
                    if (typeof myTmpBool === 'undefined') {
                        // myTmpBool 이 1이 아닌 경우(type of undefined 와 같음)
                        const my_f_query = `insert into order_ (CusAccNum,StockSymbol,OrderType,OriginalNumShares,NumShares,StopPrice,Completed,isPartiallyFilled, PriceType) values (?,?,?,?,?,?,0,0,'Limit_Stop')`;
                        await sql_connection.promise().query(my_f_query, [req.body.CusAccNum, req.body.StockSymbol, req.body.OrderType, req.body.NumShares, req.body.NumShares, parseInt(req.body.StopPrice)]);

                    } else {
                        // myTmpBool == 1 인 경우
                        const my_f_query = `insert into order_ (CusAccNum,StockSymbol,OrderType,OriginalNumShares,NumShares,StopPrice,Completed,isPartiallyFilled, PriceType) values (?,?,?,?,?,?,0,1,'Limit_Stop')`;
                        await sql_connection.promise().query(my_f_query, [req.body.CusAccNum, req.body.StockSymbol, req.body.OrderType, req.body.NumShares, req.body.NumShares, parseInt(req.body.StopPrice)]);
                    }

                } else {
                    // update (updateOne)
                    if (typeof myTmpBool === 'undefined') {
                        // myTmpBool 이 1이 아닌 경우(type of undefined 와 같음)
                        const my_c_query = `update order_ set StopPrice = ?, NumShares = ?, OriginalNumShares = ? where OrderId = ?`;
                        sql_connection.promise().query(my_c_query, [parseInt(req.body.StopPrice), req.body.NumShares, OriginalNumShares, OrderId]);

                    } else {
                        // myTmpBool == 1 인 경우
                        const my_c_query = `update order_ set StopPrice = ?, NumShares = ?, OriginalNumShares = ?, isPartiallyFilled = 1 where OrderId = ?`;
                        sql_connection.promise().query(my_c_query, [parseInt(req.body.StopPrice), req.body.NumShares, OriginalNumShares, OrderId]);

                    }

                }
            } catch (err) {
                console.log(err);
                return res.status(400).json({ message: err.message });
            }
            break;
        } else { // A matching trading pair is found

            const [tmp] = await sql_connection.promise().query(`select OrderId from order_ ORDER BY OrderId desc limit 1`);
            const NextOrderId = parseInt(tmp[0].OrderId) + 1;


            const buy_order_id = req.body.OrderType === 'Buy' ? NextOrderId : topPairResult.OrderId;
            const sell_order_id = req.body.OrderType === 'Sell' ? NextOrderId : topPairResult.OrderId;

            // If one existing order can fill the entire new order
            if (topPairResult.NumShares >= 0) {

                if (buy_order_id) {
                    transactionArr.push({
                        OrderId: parseInt(buy_order_id),

                        PricePerShare: parseInt((parseInt(req.body.StopPrice) + parseInt(topPairResult.StopPrice)) / 2),

                    });
                }
                if (sell_order_id) {
                    transactionArr.push({

                        OrderId: parseInt(sell_order_id),

                        PricePerShare: parseInt((parseInt(req.body.StopPrice) + parseInt(topPairResult.StopPrice)) / 2),

                    });
                }



                RemainingNumShares = 0;

                if (isNewOrder) {
                    // insert into query statement (save)
                    const my_f_query = `insert into order_ (CusAccNum,StockSymbol,OrderType,OriginalNumShares,NumShares,StopPrice,Completed,isPartiallyFilled, PriceType) values (?,?,?,?,0,?,1,1,'Limit_Stop')`;
                    await sql_connection.promise().query(my_f_query, [req.body.CusAccNum, req.body.StockSymbol, req.body.OrderType, req.body.NumShares, parseInt(req.body.StopPrice)]);

                } else {
                    // update (updateOne)
                    const my_u_query = `update order_ set StopPrice = ?, NumShares = 0, OriginalNumShares = ?, isPartiallyFilled = 1, Completed = 1 where OrderId = ?`;
                    await sql_connection.promise().query(my_u_query, [parseInt(req.body.StopPrice), OriginalNumShares, OrderId]);
                }


                topPairResult.NumShares === 0 && filledOrderArr.push(topPairResult.OrderId);

            } else { // It will take multiple orders
                if (buy_order_id) {
                    transactionArr.push({
                        OrderId: parseInt(buy_order_id),

                        PricePerShare: parseInt((parseInt(req.body.StopPrice) + parseInt(topPairResult.StopPrice)) / 2),

                    });
                }
                if (sell_order_id) {
                    transactionArr.push({

                        OrderId: parseInt(sell_order_id),

                        PricePerShare: parseInt((parseInt(req.body.StopPrice) + parseInt(topPairResult.StopPrice)) / 2),

                    });
                }


                RemainingNumShares = Math.abs(topPairResult.NumShares);

                if (isNewOrder) {
                    // insert into query statement (save)

                    const my_f_query = `insert into order_ (CusAccNum,StockSymbol,OrderType,OriginalNumShares,NumShares,StopPrice,is_filled,isPartiallyFilled, PriceType) values (?,?,?,?,?,?,0,1,'Limit_Stop')`;
                    await sql_connection.promise().query(my_f_query, [req.body.CusAccNum, req.body.StockSymbol, req.body.OrderType, req.body.NumShares, RemainingNumShares, parseInt(req.body.StopPrice)]);
                } else {
                    // update (updateOne)

                    const my_u_query = `update order_ set StopPrice = ?, NumShares = ?, OriginalNumShares = ?, isPartiallyFilled = 1, Completed = 0 where OrderId = ?`;
                    sql_connection.promise().query(my_u_query, [parseInt(req.body.StopPrice), RemainingNumShares, OriginalNumShares, OrderId]);
                }


                filledOrderArr.push(topPairResult.OrderId);
            }
        }

    }




    await saveTransactionArr(transactionArr);
    await updateFilledOrderArr(filledOrderArr);

};



exports.myTossOrder = async (req, res) => {
    await queryAndMatchPairs(req, res, true); // true <-> isNewOrder <-> new order true. all meaning same, true (but can set false for update patch or delete)
    res.status(200).redirect('/orders');
};

// Fetch the top 5 bids and asks
const getOrderBook = async (symbol) => {


    const [buyOrders] = await sql_connection.promise().query(
        'SELECT price, SUM(quantity) AS total_quantity FROM orders WHERE symbol = ? AND order_type = "Buy" AND status = "Open" GROUP BY price ORDER BY price DESC LIMIT 5',
        [symbol]
    );

    const [sellOrders] = await sql_connection.promise().query(
        'SELECT price, SUM(quantity) AS total_quantity FROM orders WHERE symbol = ? AND order_type = "Sell" AND status = "Open" GROUP BY price ORDER BY price ASC LIMIT 5',
        [symbol]
    );



    return {
        bids: buyOrders.map(order => ({ price: order.price, quantity: order.total_quantity })),
        asks: sellOrders.map(order => ({ price: order.price, quantity: order.total_quantity })),
    };
}

// Insert into order_book table
const insertIntoOrderBook = async (symbol, bids, asks) => {


    const bestBid = bids[0] || { price: null, quantity: 0 };
    const bestAsk = asks[0] || { price: null, quantity: 0 };

    await sql_connection.promise().execute(
        'INSERT INTO order_book (symbol, bid_price, bid_quantity, ask_price, ask_quantity) VALUES (?, ?, ?, ?, ?)',
        [symbol, bestBid.price, bestBid.quantity, bestAsk.price, bestAsk.quantity]
    );


}


// 주문 매칭 함수
const matchOrders = async (symbol) => {
    const sql_connection__ = sql_connection.promise();
    let totalMatches = 0;

    try {
        await sql_connection__.beginTransaction();

        // 매도 및 매수 주문 가져오기
        const [buyOrders] = await sql_connection__.query(
            'SELECT * FROM orders WHERE symbol = ? AND order_type = "Buy" AND status = "Open" ORDER BY price DESC',
            [symbol]
        );

        const [sellOrders] = await sql_connection__.query(
            'SELECT * FROM orders WHERE symbol = ? AND order_type = "Sell" AND status = "Open" ORDER BY price ASC',
            [symbol]
        );

        // 매칭 로직
        for (let buyOrder of buyOrders) {
            for (let sellOrder of sellOrders) {
                if (buyOrder.price >= sellOrder.price) {
                    const matchedQuantity = Math.min(buyOrder.quantity, sellOrder.quantity);

                    console.log(`Matched: ${matchedQuantity} shares of ${sellOrder.symbol} at $${sellOrder.price}`);

                    // 수량 업데이트
                    buyOrder.quantity -= matchedQuantity;
                    sellOrder.quantity -= matchedQuantity;

                    // 데이터베이스 업데이트
                    await sql_connection__.query(
                        'UPDATE orders SET quantity = ?, status = ? WHERE id = ?',
                        [buyOrder.quantity, buyOrder.quantity === 0 ? 'Matched' : 'Open', buyOrder.id]
                    );
                    await sql_connection__.query(
                        'UPDATE orders SET quantity = ?, status = ? WHERE id = ?',
                        [sellOrder.quantity, sellOrder.quantity === 0 ? 'Matched' : 'Open', sellOrder.id]
                    );

                    // 매칭 횟수 증가
                    totalMatches += 1;

                    // 완전히 체결된 주문 제거
                    if (buyOrder.quantity === 0 && sellOrder.quantity === 0) {
                        console.log('buyOrder.quantity is 0 AND sellOrder.quantity is 0...');

                        await sql_connection__.query(`UPDATE order_book SET ask_quantity = 0 WHERE symbol = ? AND bid_price is NULL AND ask_quantity != 0`, [symbol]);
                        await sql_connection__.query(`UPDATE order_book SET bid_quantity = 0 WHERE symbol = ? AND ask_price is NULL AND bid_quantity != 0`, [symbol]);    
                        

                        await sql_connection__.query(`DELETE FROM order_book WHERE symbol = ? AND bid_price is NULL AND ask_quantity = 0`, [symbol]);
                        await sql_connection__.query(`DELETE FROM order_book WHERE symbol = ? AND ask_price is NULL AND bid_quantity = 0`, [symbol]);                          
                        
                        break;
                    }
                } else {
                    break; // 더 이상 매칭이 불가능한 경우
                }
            }
        }

        // 조건부 주문 매칭
        // await matchStopOrders(symbol, buyOrders, sellOrders);

        // 트랜잭션 커밋
        await sql_connection__.commit();
    } catch (error) {
        await sql_connection__.rollback();
        console.error(error);
    } finally {
        //sql_connection__.release();
    }

    return totalMatches; // 매칭된 총 주문 수 반환
}



exports.myMyMyOrders = async (req, res) => {
    const { symbol, price, quantity, orderType, stopPrice } = req.body;

    // 입력값 유효성 검사
    if (!symbol || !price || !quantity || !orderType) {
        return res.status(400).json({ error: 'Missing required fields' });
    }

    if (isNaN(price) || isNaN(quantity)) {
        return res.status(400).json({ error: 'Price and quantity must be numbers' });
    }

    try {
        const [result] = await sql_connection.promise().execute(
            'INSERT INTO orders (symbol, price, quantity, order_type, stop_price, status) VALUES (?, ?, ?, ?, ?, ?)',
            [symbol, price, quantity, orderType, stopPrice || null, 'Open']
        );

        const matchesMade = await matchOrders(symbol); // 주문 추가 후 매칭 호출

        if (matchesMade > 0) {
            console.log(`Matched ${matchesMade} orders for symbol ${symbol}`);
            res.status(201).json({ id: result.insertId });
        } else {
            // nothing..
            // Fetch the updated order book after placing the order
            const orderBook = await getOrderBook(symbol);
            // Insert the best bids and asks into order_book
            await insertIntoOrderBook(symbol, orderBook.bids, orderBook.asks);
            res.status(201).json({ id: result.insertId });
        }




    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Failed to add order' });
    }
};

// 히스토리, 주문 목록 조회 API
exports.myMyMyOrdersBySymbol =  async (req, res) => {
    const { symbol } = req.params;
    try {
        const [orders] = await sql_connection.promise().query('SELECT * FROM orders WHERE symbol = ? ORDER BY id DESC', [symbol]);
        res.json(orders);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Failed to fetch orders' });
    }
};

// 5단계 호가 주문 목록 조회 API
exports.myMyMyOrderbookBySymbol =  async (req, res) => {
    const { symbol } = req.params;
    try {
        const orderBook = await getOrderBook(symbol);        
        var page = ejs.render(getMyIndexTest(), { symbol, orderBook });
        res.send(page);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Failed to process orderBook data' });
    }
};

// 메인 페이지 렌더링
exports.myMyMyBySymbol =  async (req, res) => {
    try {
        const { symbol } = req.params;
        const orderBook = await getOrderBook(symbol);
        var page = ejs.render(getMyIndexTest(), { symbol, orderBook });
        res.send(page);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Failed to fetch symbols' });
    }
};

// 서브 페이지 렌더링
exports.myMyMyListOfMineBySymbol =  async (req, res) => {
    try {
        const { symbol } = req.params;
        var page = ejs.render(getMyListOfMineTest(), { symbol });
        res.send(page);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Failed to fetch symbols' });
    }
};


exports.myPlaceStock = (req, res) => {
    //placeStockPage

    if (typeof req.query.stocksymbol === 'undefined') console.error('error stocksymbol of tmp');
    var page = ejs.render(getPlaceStockPage(), {
        qdata: req.query.stocksymbol || ''
    });
    res.send(page);
};


exports.myOrders = (req, res) => {
    const my_custom_selall_query = `SELECT * from order_ ORDER BY Timestamp_ DESC`;
    try {

        sql_connection.query(my_custom_selall_query, (err, results) => {
            if (err) throw err;
            const orders = results;

            var page = ejs.render(getOrdersPage(), {
                orders: orders
            });
            res.send(page);


        });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

exports.myTransactions = (req, res) => {
    const my_custom_selall_query = `SELECT * FROM transact ORDER BY Timestamp_ DESC`;
    try {

        sql_connection.query(my_custom_selall_query, (err, results) => {
            if (err) throw err;
            const transactions = results;

            var page = ejs.render(getTransactionsPage(), {
                transactions: transactions
            });
            res.send(page);


        });

    } catch (err) {
        res.status(500).json({ message: err.message });
    }

};

exports.myOrdersById = (req, res) => {
    res.status(200).json(res.order);
};
