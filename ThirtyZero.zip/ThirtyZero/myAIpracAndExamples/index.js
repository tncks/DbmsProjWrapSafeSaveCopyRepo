// server..


const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const schedule = require('node-schedule');

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.set('view engine', 'ejs');



// 주문 추가 API
app.post('/order', (req, res) => {
    const { symbol, price, quantity, orderType } = req.body;

    const query = 'INSERT INTO order_book (symbol, price, quantity, order_type) VALUES (?, ?, ?, ?)';
    sql_connection.query(query, [symbol, price, quantity, orderType], (err, result) => {
        if (err) {
            console.error('Error inserting order:', err);
            return res.status(500).send('Error inserting order');
        }
        res.redirect('/');
    });
});

// 주문 조회 API
app.get('/', (req, res) => {
    const query = `
        SELECT order_type, price, SUM(quantity) AS total_quantity
        FROM order_book
        WHERE symbol = ?
        GROUP BY order_type, price
        ORDER BY (CASE WHEN order_type = 'Sell' THEN price END) DESC, 
                 (CASE WHEN order_type = 'Buy' THEN price END) ASC
        LIMIT 10;`;
    
    const symbol = 'TSLA'; // 예시로 TSLA 사용
    sql_connection.query(query, [symbol], (err, results) => {
        if (err) {
            console.error('Error fetching orders:', err);
            return res.status(500).send('Error fetching orders');
        }
        res.render('index', { orders: results });
    });
});

// 주기적인 주문 매칭
function matchOrders() {
    const query = `
        SELECT * FROM order_book 
        WHERE symbol = 'TSLA' 
        ORDER BY order_type, price`;

    sql_connection.query(query, (err, orders) => {
        if (err) {
            console.error('Error fetching orders for matching:', err);
            return;
        }

        let buyOrders = orders.filter(o => o.order_type === 'Buy');
        let sellOrders = orders.filter(o => o.order_type === 'Sell');

        let matches = [];
        let i = 0, j = 0;

        while (i < buyOrders.length && j < sellOrders.length) {
            const buyOrder = buyOrders[i];
            const sellOrder = sellOrders[j];

            if (buyOrder.price >= sellOrder.price) {
                const quantity = Math.min(buyOrder.quantity, sellOrder.quantity);
                matches.push({
                    buyOrderId: buyOrder.id,
                    sellOrderId: sellOrder.id,
                    quantity: quantity,
                    price: sellOrder.price
                });

                // 업데이트 주문 수량
                buyOrder.quantity -= quantity;
                sellOrder.quantity -= quantity;

                if (buyOrder.quantity === 0) i++;
                if (sellOrder.quantity === 0) j++;
            } else {
                j++;
            }
        }

        // 매칭 결과 처리
        matches.forEach(match => {
            const deleteQuery = 'DELETE FROM order_book WHERE id = ? OR id = ?';
            sql_connection.query(deleteQuery, [match.buyOrderId, match.sellOrderId], err => {
                if (err) console.error('Error deleting matched orders:', err);
            });
        });

        console.log('Matched Orders:', matches);
    });
}

// 5초마다 주문 매칭 실행
schedule.scheduleJob('*/5 * * * * *', matchOrders);
