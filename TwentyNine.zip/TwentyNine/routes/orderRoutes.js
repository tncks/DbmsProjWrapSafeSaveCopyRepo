const express = require('express');
const router = express.Router();
const usersController = require('../controllers/UsersController');
const ordersController = require('../controllers/OrdersController');
const isAuthenticated = require('../middleware/auth');
// HERE THIS FILE contains "POST" ROUTES ONLY


/* ordersController defined */
router.post('/tossorder', isAuthenticated, ordersController.myTossOrder);  // api/ path
router.post('/orders', isAuthenticated, ordersController.myOrders);  // api/ path 
router.post('/orders/:symbol', isAuthenticated, ordersController.myOrdersBySymbol);  // api/ path 
router.post('/orderbook/:symbol', isAuthenticated, ordersController.myOrderbookBySymbol);  // api/ path 
/* usersController defined */
router.post('/logout', usersController.myLogout);  // api/ path 
router.post('/login', usersController.myLogin);  // api/ path 
router.post('/signup', usersController.mySignup);  // api/ path 
router.post('/cashAdd', isAuthenticated, usersController.myCashAdd);  // api/ path 
router.post('/cashSub', isAuthenticated, usersController.myCashSub);  // api/ path 

// login 이나 signup 등은 loginController.myLogin 등등 으로 또 분할하고 적용하기 나중에 
// 그리고, 위에 require 도 추가하고 새 이름의 파일도 생성하고 연결



































































//


//





























module.exports = router;