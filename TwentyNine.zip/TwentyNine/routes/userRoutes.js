const express = require('express');
const router = express.Router();
const usersController = require('../controllers/UsersController');
const ordersController = require('../controllers/OrdersController');
const isAuthenticated = require('../middleware/auth');
// HERE THIS FILE contains "GET" ROUTES ONLY

/* ordersController defined */
router.get('/placestock', isAuthenticated, ordersController.myPlaceStock);  // /placestock path 
router.get('/ordersalllog', isAuthenticated, ordersController.myOrdersAllLog);  // / path 
router.get('/orderseespecific/:id', ordersController.getOrder , ordersController.myOrderSeeSpecificById);  // / path 
router.get('/transactions', isAuthenticated, ordersController.myTransactions);  // / path 
router.get('/materialweb/:symbol', isAuthenticated, ordersController.myMaterialWebBySymbol);  // / path 
router.get('/materialweblistofmine/:symbol', isAuthenticated, ordersController.myMaterialWebListOfMineBySymbol);  // / path 
/* usersController defined */
router.get('/getOrderBook', isAuthenticated, usersController.myGetOrderBook);  // / path 
router.get('/fivePreferPrice', isAuthenticated, usersController.myFivePreferPrice);  // / path 
router.get('/search_general', usersController.mySearchGeneral);  // / path 
router.get('/welcome', usersController.myWelcome);  // / path 
router.get('/home', isAuthenticated, usersController.myHome);  // / path 
router.get('/login', usersController.getMyLogin);  // / path 
router.get('/signup', usersController.getMySignup);  // / path 
router.get('/getFunds', isAuthenticated, usersController.myGetFunds);  // / path 
router.get('/getPortfolio', isAuthenticated, usersController.myGetPortfolio);  // / path 
router.get('/adminSuperDashboard', usersController.myAdminSuperDashboard);  // / path 
// login 이나 signup 등은 loginController.myLogin 등등 으로 또 분할하고 적용하기 나중에 
// 그리고, 위에 require 도 추가하고 새 이름의 파일도 생성하고 연결  












































































//

































//






module.exports = router;


