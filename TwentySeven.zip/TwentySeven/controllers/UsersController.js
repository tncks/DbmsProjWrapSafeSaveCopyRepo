const fs = require('fs');
const sql_connection = require('../config/db');
const ejs = require('ejs');
const {
    basicQ
} = require('../shared');
const shared = require('../shared');










// GET METHOD (Focusing on GET)
function executeQueries(queries, callback) {
    let results = [];
    let index = 0;
    let len = 1;

    function executeNextQuery() {
        if (index >= queries.length) {
            return callback(null, results); // 모든 쿼리 완료
        }

        sql_connection.query(queries[index], (err, result) => {
            if (err) {
                console.error('Error:', queries[index], err);
                return callback(err);
            }
            const meaning = ["ChangedPriceDataOfSpecificStockDetailInfoTable", "StockRevenue", "ChangedPriceDataOfSpecificStockDetailInfoTable", "MostTraded"]; // 5 6 7 8
            if (queries.length - index < 5 && queries.length - index >= 1) len = meaning.length - (queries.length - index);
            results.push({ table: meaning[len], data: result });
            index++;
            executeNextQuery(); // 다음 쿼리 실행
        });
    }

    executeNextQuery(); // 첫 번째 쿼리 실행
}


exports.myGetOrderBook = (req, res) => {
    const stocksymbol = req.query.stocksymbol;
    const queryFiveAskBidPriceOfStockSelectionQ = `
        select order_.OrderType, order_.StopPrice, sum(order_.NumShares) as total_quantity_shares
        from order_
        join stock on stock.stocksymbol = order_.stocksymbol
        where order_.stocksymbol = ? and order_.ordertype in ('Sell','Buy')
        group by order_.ordertype, order_.stopprice
        order by (case when order_.ordertype = 'Sell' then order_.stopprice END) desc, (case when order_.ordertype = 'Buy' then order_.stopprice END) asc
        limit 10;
        `;

    sql_connection.query(queryFiveAskBidPriceOfStockSelectionQ, [stocksymbol], (err, results) => {
        if (err) {
            res.status(500).json({ error: 'DB error occurs' });

        } else {
            res.json(results);

        }
    });
};

exports.myFivePreferPrice = (req, res) => {
    const pageContent = shared.getFivePreferPricePage;
    var page = ejs.render(pageContent(), {
        data: req.query.stocksymbol || '',
    });
    res.send(page);
};

exports.mySearchGeneral = (req, res) => {
    const pageContent = shared.getSearchGeneralPage;
    var page = ejs.render(pageContent());
    res.send(page);
};

exports.myWelcome = (req, res) => {
    var unconditionalStockListDeliveryToFrontSide;


    /* SELECT ALL STOCK AT FIRST */

    sql_connection.query(basicQ, (err, result) => {
        if (err) throw err;
        if (result.length > 0) {
            unconditionalStockListDeliveryToFrontSide = result;
        }
        else {
            console.log('Empty 테이블: 주식 정보 하나도 없음');
            unconditionalStockListDeliveryToFrontSide = 0;
        }



        if (typeof req.session.userID !== 'undefined' && req.session.userID.length >= 1) {

            console.log('Detected: strange request from a strange client..');
            console.log('username is :');
            console.log(req.session.userID);
            const pageContent = shared.getHomePage
            var page = ejs.render(pageContent(), {
                data: unconditionalStockListDeliveryToFrontSide || null,
            });
            return res.send(page);

        }


        const pageContent = shared.getWelcomePage
        var page = ejs.render(pageContent(), {
            data: unconditionalStockListDeliveryToFrontSide || null,
        });
        res.send(page);

    });



};

exports.myHome = (req, res) => {
    var unconditionalStockListDeliveryToFrontSide;


    /* SELECT ALL STOCK AT FIRST */

    sql_connection.query(basicQ, (err, result) => {
        if (err) throw err;
        if (result.length > 0) {
            unconditionalStockListDeliveryToFrontSide = result;
        }
        else {
            console.log('Empty 테이블: 주식 정보 하나도 없음');
            unconditionalStockListDeliveryToFrontSide = 0;
        }


        if (req.session.userID && req.session.userID.length >= 1) {

            const pageContent = shared.getHomePage
            var page = ejs.render(pageContent(), {
                data: unconditionalStockListDeliveryToFrontSide || null,
            });
            res.send(page);


        } else {

            console.log('Detected: strange request from an anonymous human..');
            const pageContent = shared.getWelcomePage
            var page = ejs.render(pageContent(), {
                data: unconditionalStockListDeliveryToFrontSide || null,
            });
            res.send(page);

        }

    });


};

// lgout
exports.myLogout = (req, res) => {
    var unconditionalStockListDeliveryToFrontSide;


    // in code level here: do something first, such as session destroy user, and other stuff works, then if all ok, then redirect to welcome Page. for now, logout process done!

    /* early code starts from here.. */
    req.session.destroy(err => {
        if (err) {
            return res.redirect('/welcome'); // somewhere : /welcome or any other path anything!
        }
        // Description:else -> destroy was normally done. then now execute next code line.
    });





    /* basic fundamental code starts from here.. */

    sql_connection.query(basicQ, (err, result) => {
        if (err) throw err;
        if (result.length > 0) {
            unconditionalStockListDeliveryToFrontSide = result;
        }
        else {
            console.log('Empty 테이블: 주식 정보 하나도 없음');
            unconditionalStockListDeliveryToFrontSide = 0;
        }
    });

    const pageContent = shared.getWelcomePage
    var page = ejs.render(pageContent(), {
        data: unconditionalStockListDeliveryToFrontSide || null,
    });
    res.send(page); // render the welcome Page with query data of stock list in order for displaying default home screen with basic table contents
    // all done.

};
// router.post('/logout', usersController.myLogout);  // api/ path 

exports.getMyLogin = (req, res) => {
    if (req.session.userID && req.session.userID.length >= 1) {

        console.log('Detected: strange request from a strange client..');
        console.log('username is :');
        console.log(req.session.userID);
        const pageContent = shared.getHomePage
        var page = ejs.render(pageContent(), {});
        return res.send(page);


    } else {

        const pageContent = shared.getLoginPage
        var page = ejs.render(pageContent(), {
            data: {},
        });
        res.send(page);

    }

}; // g

// lgin
exports.myLogin = (req, res) => {
    const { userID, userPassword } = req.body;
    var unconditionalStockListDeliveryToFrontSide;
    const queryUserCredentialMatchDuringLoginSelectionQ = `select * from login where Usr = ? and Pwd = ?`;


    /* SELECT ALL STOCK AT FIRST */

    sql_connection.query(basicQ, (err, result) => {
        if (err) throw err;
        if (result.length > 0) {
            unconditionalStockListDeliveryToFrontSide = result;
        }
        else {
            console.log('Empty 테이블: 주식 정보 하나도 없음');
            unconditionalStockListDeliveryToFrontSide = 0;
        }
    });



    /* CHECK LOGIN CREDENTIAL IF THE USER EXISTS TO PROCESS LOGIN STUFF AND MOVE TO HOME DASH IF OK */

    sql_connection.query(queryUserCredentialMatchDuringLoginSelectionQ, [userID, userPassword], (error, results, fields) => {
        if (error) throw error;
        if (results.length > 0) {
            //console.log('results 0 index thing');
            //console.log((results[0].Id));
            //console.log((results.CusId));
            // Good. 200 OK status:   로그인 성공

            req.session.userID = userID;    // userId를 세션에 저장
            req.session.CusId = results[0].Id; // CusID (Id)를 세션에 저장


            const pageContent = shared.getHomePage
            var page = ejs.render(pageContent(), { data: unconditionalStockListDeliveryToFrontSide || null });
            res.send(page);
        }
        else {
            const pageContent = shared.getLoginPage
            var page = ejs.render(pageContent(), { loginResult: 'fail' });
            res.send(page);


        }
    });

};
// router.post('/login', usersController.myLogin);  // api/ path 

exports.getMySignup = (req, res) => {
    const pageContent = shared.getSignupPage
    var page = ejs.render(pageContent(), {
        title: "Title",
        data: {},
    });
    res.send(page);
}; // g

// siup
exports.mySignup = (req, res) => {
    const { userID, userPassword, userLastName, userFirstName } = req.body;
    const queryUserinfoDuringRegistSelectionQ = `select * from login where Usr = ?`;
    const queryUserNormalAddDuringRegistInsertion_1Q_1 = `insert into customer (LastName, FirstName) values (?, ?)`;
    const queryUserNormalAddDuringRegistInsertion_2Q_2 = `insert into account_ (AccCreDate, CusId) values (NOW(),?);`;
    const queryUserNormalAddDuringRegistInsertion_3Q_3 = `insert into login (Usr, Pwd, Id) values (?, ?, ?);`;

    sql_connection.query(queryUserinfoDuringRegistSelectionQ, [userID], (error, results, fields) => {
        if (error) throw error;

        if (results.length > 0) {
            console.log("이미 존재하는 아이디로 회원가입시도.");
            const pageContent = shared.getSignupPage
            var page = ejs.render(pageContent(), { signupResult: 'fail' });
            res.send(page);
        }
        else {
            /* ADD A NEW USER UPDATE TO THE CUSTOMER TABLE */
            sql_connection.beginTransaction((err) => {
                if (err) throw err;



                sql_connection.query(queryUserNormalAddDuringRegistInsertion_1Q_1, [userLastName, userFirstName], (error, results, fields) => {
                    if (error) {
                        return sql_connection.rollback(() => {
                            throw error;
                        });
                    }

                    const newCusId = results.insertId;

                    sql_connection.query(queryUserNormalAddDuringRegistInsertion_2Q_2, [newCusId], (error, results, fields) => {
                        if (error) {
                            return sql_connection.rollback(() => {
                                throw error;
                            });
                        }

                        sql_connection.query(queryUserNormalAddDuringRegistInsertion_3Q_3, [userID, userPassword, newCusId], (error, results, fields) => {
                            if (error) {
                                return sql_connection.rollback(() => {
                                    throw error;
                                });
                            }

                            sql_connection.commit((err) => {
                                if (err) {
                                    return sql_connection.rollback(() => {
                                        throw err;
                                    });
                                }
                                // sc
                                console.log("serverlog: 회원가입 완료");

                                //res.send("회원가입 완료");

                                // redirection
                                res.redirect("http://localhost:3001/login");

                            });

                        });




                    });





                });
            });
        }
    });
};
// router.post('/signup', usersController.mySignup);  // api/ path 

exports.myGetFunds = (req, res) => { /* getFunds -> GET 방식만 처리. POST 방식으로 들어오는 요청에 대해서 처리하지 않음 */

    // 세션에서 CusID 가져옴 
    var id = req.session.CusId;  // req.session.CusId

    if (!id || typeof id === 'undefined') {
        console.log('req.session.CusId : ', id);
        console.log('req.session.CusId : ', req.session.CusId);
        console.log('redirect to /login..');
        return res.redirect('/login');
    }

    sql_connection.query(`SELECT MarginAvailable AS CustomerFund FROM account_ WHERE CusId = ?`, [id], (err, results) => {
        if (err) throw err;

        if (results.length > 0) {

            const pageContent = shared.getFundPage
            var page = ejs.render(pageContent(), { data: results });
            return res.send(page);

        } else {
            console.log('/getFunds (path): Server Detected: results. length 0 on marginbalance request..');
            res.sendStatus(500);
        }


    });

};

// ca
exports.myCashAdd = (req, res) => {
    var id = req.session.CusId;
    const { cash_a } = req.body;
    const queryUpdateMoneyAddQ = `update account_ set MarginAvailable = MarginAvailable + ? where AccNum = ?`;

    if (!id || typeof id === 'undefined') {
        return res.redirect('/login');
    }
    if (typeof cash_a === 'undefined') {
        return res.redirect('/getFunds');
    }

    sql_connection.query(queryUpdateMoneyAddQ, [cash_a, id], (err, results) => {
        if (err) throw err;

        sql_connection.query(`SELECT MarginAvailable AS CustomerFund FROM account_ WHERE CusId = ?`, [id], (err, results) => {
            if (err) throw err;

            if (results.length > 0) {

                const pageContent = shared.getFundPage
                var page = ejs.render(pageContent(), { data: results });
                return res.send(page);

            } else {
                console.log('/getFunds (path): Server Detected: results. length 0 on marginbalance request..');
                res.sendStatus(500);
            }


        });
    });
};
// router.post('/cashAdd', isAuthenticated, usersController.myCashAdd);  // api/ path

// cs
exports.myCashSub = (req, res) => {
    var id = req.session.CusId;
    const { cash_s } = req.body;
    const queryUpdateMoneySubQ = `update account_ set MarginAvailable = MarginAvailable - ? where AccNum = ?`;

    if (!id || typeof id === 'undefined') {
        return res.redirect('/login');
    }
    if (typeof cash_s === 'undefined') {
        return res.redirect('/getFunds');
    }

    sql_connection.query(queryUpdateMoneySubQ, [cash_s, id], (err, results) => {
        if (err) throw err;

        sql_connection.query(`SELECT MarginAvailable AS CustomerFund FROM account_ WHERE CusId = ?`, [id], (err, results) => {
            if (err) throw err;

            if (results.length > 0) {

                const pageContent = shared.getFundPage
                var page = ejs.render(pageContent(), { data: results });
                return res.send(page);

            } else {
                console.log('/getFunds (path): Server Detected: results. length 0 on marginbalance request..');
                res.sendStatus(500);
            }


        });
    });
};
// router.post('/cashSub', isAuthenticated, usersController.myCashSub);  // api/ path

exports.myAdminSuperDashboard = async (req, res) => {
    fs.readFile('queries.sql', 'utf-8', (err, data) => {
        if (err) {
            console.error('Error reading SQL file:', err);
            return res.status(500).send('Internal Server Error');
        }

        const queries = data.split(';').map(query => query.trim()).filter(query => query.length > 0);

        executeQueries(queries, (err, results) => {
            if (err) {
                console.error('Error in /adminSuperDashboard:', err);
                return res.status(500).send('Internal Server Error');
            }

            const concat = [];
            var n = 8;
            while (n > 0) {
                concat.push(results[results.length - n]);
                n = n - 1;
            }
            const pageContent = shared.getAdminSuperDashboardPage
            var page = ejs.render(pageContent(), {
                data: concat,
            });
            res.send(page);
        });
    });

};
