DROP VIEW IF EXISTS StockRevenue;
DROP VIEW IF EXISTS STOCKTYPEREVENUE;
DROP VIEW IF EXISTS CUSTOMERREVENUE;
DROP VIEW IF EXISTS MostTraded;
DROP VIEW IF EXISTS Suggest;
DROP VIEW IF EXISTS PreviousClose;
SELECT * from account_;
SELECT * from order_;
SELECT * from stockpricehistory;
SELECT * from stock;
SELECT * from portfolio;
CREATE VIEW StockRevenue(StockSymbol, StockName) AS
SELECT O.StockSymbol, S.StockName 
FROM Order_ O, Transact T, Stock S
WHERE O.OrderId = T.OrderId AND O.StockSymbol = S.StockSymbol
GROUP BY O.StockSymbol;
CREATE VIEW STOCKTYPEREVENUE(StockType) AS
SELECT S.StockType
FROM Stock S, Transact T, Order_ O
WHERE O.StockSymbol = S.StockSymbol
AND O.OrderID = T.OrderId
GROUP BY S.StockType;
CREATE VIEW CUSTOMERREVENUE(CusAccNum, FirstName, LastName) AS
SELECT O.CusAccNum, C.FirstName, C.LastName 
FROM Order_ O, Transact T, Customer C, Account_ A
WHERE O.OrderID = T.OrderId AND O.CusAccNum = A.AccNum AND A.CusId = C.CusId
GROUP BY O.CusAccNum;
CREATE VIEW MostTraded(StockSymbol, StockName, NumOrders) AS
SELECT O.StockSymbol, S.StockName, COUNT(*) AS NumOrders
FROM Order_ O, Stock S
WHERE O.StockSymbol = S.StockSymbol
GROUP BY O.StockSymbol
ORDER BY NumOrders DESC;
CREATE VIEW Suggest(StockSymbol, SharePrice, NumAvailShares, StockType) AS
SELECT S.StockSymbol, S.SharePrice, S.NumAvailShares, S.StockType
FROM Stock S, Order_ O
WHERE(O.CusAccNum = 1 AND O.StockSymbol = S.StockSymbol);
CREATE VIEW PreviousClose(stocksymbol, previous_close_price) AS 
SELECT 
    stocksymbol,
    stockpricehistory.shareprice AS previous_close_price
FROM 
    stockpricehistory
WHERE 
    timestamp_ = (SELECT MAX(timestamp_) FROM stockpricehistory WHERE stocksymbol = 'TSLA')
    and stocksymbol = 'TSLA';
SELECT * FROM account_ a_;
SELECT * FROM transact tr;
SELECT * FROM customer cu;
SELECT * FROM order_ o_;
SELECT * FROM Suggest su;
SELECT * FROM StockRevenue rv; -- 6
-- 
SELECT 
    Stock.stockname,
    Stock.stocksymbol,
    Stock.shareprice AS current_price,
    PreviousClose.previous_close_price,
    ROUND((Stock.shareprice - PreviousClose.previous_close_price), 2) AS change_price,
    ROUND((    (   (Stock.shareprice - PreviousClose.previous_close_price) / PreviousClose.previous_close_price  ) * 100), 2) AS change_percent
FROM 
    Stock
JOIN 
    PreviousClose ON Stock.stocksymbol = PreviousClose.stocksymbol;  -- PreviousClose.stock.stocksymbol
-- 
-- SELECT * FROM STOCKTYPEREVENUE styrv; -- 7
SELECT * FROM MostTraded mt; -- 8
