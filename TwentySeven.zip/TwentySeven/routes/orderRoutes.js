const express = require('express');
const router = express.Router();
const usersController = require('../controllers/UsersController');
const ordersController = require('../controllers/OrdersController');
const isAuthenticated = require('../middleware/auth');
// HERE THIS FILE contains "POST" ROUTES ONLY


//router.post('/orders', ordersController.createOrder);  // api/orders path 
/* ordersController defined */
router.post('/tossorder', ordersController.myTossOrder);  // api/ path
router.post('/mymyorders', ordersController.myMyMyOrders);  // api/ path 
router.post('/mymyorders/:symbol', ordersController.myMyMyOrdersBySymbol);  // api/ path 
router.post('/mymyorderbook/:symbol', ordersController.myMyMyOrderbookBySymbol);  // api/ path 
/* usersController defined */
router.post('/logout', usersController.myLogout);  // api/ path 
router.post('/login', usersController.myLogin);  // api/ path 
router.post('/signup', usersController.mySignup);  // api/ path 
router.post('/cashAdd', isAuthenticated, usersController.myCashAdd);  // api/ path 
router.post('/cashSub', isAuthenticated, usersController.myCashSub);  // api/ path 

// login 이나 signup 등은 loginController.myLogin 등등 으로 또 분할하고 적용하기 나중에 
// 그리고, 위에 require 도 추가하고 새 이름의 파일도 생성하고 연결



































































//


//





























module.exports = router;