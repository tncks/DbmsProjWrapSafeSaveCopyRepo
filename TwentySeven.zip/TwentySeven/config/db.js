const mysql = require('mysql2');
const targetDB = "live-stock";
const db_info = {
    host: "localhost",
    port: "3306",
    user: "root",
    password: "1234",
    database: targetDB,
    multipleStatements: true
};
const sql_connection = mysql.createConnection(db_info); //
sql_connection.connect();
module.exports = sql_connection;