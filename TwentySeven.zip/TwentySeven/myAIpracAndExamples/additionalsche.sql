CREATE TABLE order_book (
    id INT AUTO_INCREMENT PRIMARY KEY,
    symbol VARCHAR(10),
    price DECIMAL(10, 2),
    quantity INT,
    order_type ENUM('Buy', 'Sell'),
    level INT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE stock (
    stocksymbol VARCHAR(10) PRIMARY KEY,
    available_quantity INT,
    total_quantity INT
);

DELIMITER //

CREATE TRIGGER after_insert_order
AFTER INSERT ON order_book
FOR EACH ROW
BEGIN
    IF NEW.order_type = 'Sell' THEN
        UPDATE stock
        SET available_quantity = available_quantity + NEW.quantity
        WHERE stocksymbol = NEW.symbol;
    END IF;
END;

//

DELIMITER ;

DELIMITER //

CREATE TRIGGER after_delete_order
AFTER DELETE ON order_book
FOR EACH ROW
BEGIN
    IF OLD.order_type = 'Buy' THEN
        UPDATE stock
        SET available_quantity = available_quantity + OLD.quantity
        WHERE stocksymbol = OLD.symbol;
    END IF;
END;

//

DELIMITER ;
