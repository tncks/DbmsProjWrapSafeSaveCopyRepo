const express = require('express');
const router = express.Router();
const usersController = require('../controllers/UsersController');
const ordersController = require('../controllers/OrdersController');
const isAuthenticated = require('../middleware/auth');
// HERE THIS FILE contains "POST" ROUTES ONLY


/* ordersController defined */
router.post('/orders', isAuthenticated, ordersController.myOrders);  // api/ path 
router.post('/orders/:symbol', isAuthenticated, ordersController.myOrdersBySymbol);  // api/ path
router.post('/pending', isAuthenticated, ordersController.myPending);  // api/ path
router.post('/ordercancel', isAuthenticated, ordersController.myOrderCancel);  // /api path 
/* usersController defined */
router.post('/logout', usersController.myLogout);  // api/ path 
router.post('/login', usersController.myLogin);  // api/ path 
router.post('/signup', usersController.mySignup);  // api/ path 
router.post('/cashAdd', isAuthenticated, usersController.myCashAdd);  // api/ path 
router.post('/cashSub', isAuthenticated, usersController.myCashSub);  // api/ path
router.post('/cclaccount', usersController.myCclaccount);  // api/ path





































































//
// router.post('/tossorder', isAuthenticated, ordersController.myTossOrder);  // api/ path

//





























module.exports = router;