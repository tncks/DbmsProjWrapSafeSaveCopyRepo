document.addEventListener("DOMContentLoaded", function () {
    const rows = document.querySelectorAll("#transact_display_tb tr");

    rows.forEach(row => {
        
        const cells = row.querySelectorAll("td"); 
        const link_1_see_transact_log = row.querySelector(".more-link-1-see-transact-log");
        

        if (cells.length > 1 && link_1_see_transact_log) {
            const stSymbol = cells[0].textContent.trim(); 
            link_1_see_transact_log.addEventListener("click", () => {
                window.location.href = `http://localhost:3001/transactions/${stSymbol}?stocksymbol=${stSymbol}`;   // route.get(  /transactions/:symbol  )  (GET METHOD)
            });
            
            
        }
    });
});