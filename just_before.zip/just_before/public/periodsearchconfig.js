function submitSearch_(period) {

    $.get('/apis/timelyorder', { period: period }, function (res) {
        
        updateMainTable(res.orders); // 데이터를 받아와서 테이블 업데이트
    });
}

function submitCustomSearch_() {

    const startDate_ = document.getElementById('startDate_').value;
    const endDate_ = document.getElementById('endDate_').value;

    $.get('/apis/timelyorder', { startDate_: startDate_, endDate_: endDate_ }, function (res) {
        
        updateMainTable(res.orders); // 데이터를 받아와서 테이블 업데이트
    });
}

// 테이블 업데이트 함수
function updateMainTable(arg) {
    												
    const tbody_ = document.getElementById('mainBody'); // 테이블의 tbody 요소
    tbody_.innerHTML = ''; // 기존 내용 비우기

    if (typeof arg !== 'undefined' && arg && arg.length > 0) {
        arg.forEach(function (data) {
            const row = document.createElement('tr');
            row.innerHTML = `
            <td>${data.OrderId}</td>
            <td>${data.StockSymbol}</td>
            <td>${data.OrderType}</td>
            <td>${data.NumShares}</td>
            <td>${data.CusAccNum}</td>
            <td>${data.Timestamp_}</td>
            <td>${data.PriceType}</td>
            <td>${data.StopPrice}</td>
            <td>&nbsp;</td>
            <td>${data.CurSharePrice}</td>
            <td>${data.isPartiallyFilled}</td>
            <td>${data.Completed}</td>
            <td>${data.OriginalNumShares}</td>
        `;
            tbody_.appendChild(row);
        });
    } else {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td colspan="13">No data found.</td>
            
        `;
        tbody_.appendChild(row);
    }


} 		








//

function submitSearch(period) {

    $.get('/apis/trades', { period: period }, function (res) {
        
        updateTradesTable(res.data); // 데이터를 받아와서 테이블 업데이트
    });
}

function submitCustomSearch() {

    const startDate = document.getElementById('startDate').value;
    const endDate = document.getElementById('endDate').value;

    $.get('/apis/trades', { startDate: startDate, endDate: endDate }, function (res) {
        
        updateTradesTable(res.data); // 데이터를 받아와서 테이블 업데이트
    });
}

// 거래 내역 테이블 업데이트 함수
function updateTradesTable(trades) {
    
    const tbody = document.getElementById('transactionsBody'); // 테이블의 tbody 요소
    tbody.innerHTML = ''; // 기존 내용 비우기

    if (typeof trades !== 'undefined' && trades && trades.length > 0) {
        trades.forEach(function (data) {
            const row = document.createElement('tr');
            row.innerHTML = `
            <td>${data.StockName}</td>
            <td>${data.Symbol}</td>
            <td>${data.TradedTimeAt}</td>
            <td>${data.Price}</td>
            <td>${data.TradeQuantity}</td>
            <td>${data.TradePosition}</td>
        `;
            tbody.appendChild(row);
        });
    } else {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td colspan="6">No data found.</td>
            
        `;
        tbody.appendChild(row);
    }


} 		
