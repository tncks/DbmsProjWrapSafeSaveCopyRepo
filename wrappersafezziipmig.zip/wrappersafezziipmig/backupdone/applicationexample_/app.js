/* Server                                                                       * */
// TO DO : create seperate db config file and migrate this  
//       :기존 코드 지우고 이제 라우터쓰고(난잡한 코드 정리) 컨트롤러 라는거 공부하고, db 관련 코드 따로 빼기.



const express = require('express');
const app = express();
const router = express.Router(); //const { urlencoded } = require('body-parser');

const targetDB = "live-stock";
const targetTable = ["account_", "conditionalpricehistory", "customer", "employee", "login", "order_", "portfolio", "stock", "stockpricehistory", "transact"];
const mysql = require('mysql2');
const db_info = {
    host: "localhost",
    port: "3306",
    user: "root",
    password: "1234",
    database: targetDB
}; //
const sql_connection = mysql.createConnection(db_info); //
sql_connection.connect();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.set("view engine", "ejs");
app.set("views", "./views");
const ejs = require("ejs");
const fs = require('fs');
const sqlFilePath = './queries.sql';
const connectTestPage = fs.readFileSync('./views/connectTestPage.ejs', 'utf8');
const adminSuperDashboardPage = fs.readFileSync('./views/adminSuperDashboardPage.ejs', 'utf8');
var i = 0;


function executeQueries(queries, callback) {
    let results = [];
    let index = 0;
    let len = 1;

    function executeNextQuery() {
        if (index >= queries.length) {
            //console.log('모든 쿼리 완료');
            return callback(null, results); // 모든 쿼리 완료
        }

        sql_connection.query(queries[index], (err, result) => {
            if (err) {
                console.error('Error executing query:', queries[index], err);
                return callback(err);
            }

            //console.log('pushed');
            const meaning = ["Suggest","StockRevenue","STOCKTYPEREVENUE","MostTraded"];
            if(queries.length - index < 5 && queries.length - index >= 1) len = meaning.length - (queries.length - index);
            results.push({table: meaning[len], data: result });  //{ table: "tempResultTableName!", data: result }
            index++;
            executeNextQuery(); // 다음 쿼리 실행
        });
    }

    executeNextQuery(); // 첫 번째 쿼리 실행
}




app.get("/adminSuperDashboard", async (req, res) => {
    fs.readFile('./queries.sql', 'utf-8', (err, data) => {
        if (err) {
            console.error('Error reading SQL file:', err);
            return res.status(500).send('Internal Server Error');
        }

        const queries = data.split(';').map(query => query.trim()).filter(query => query.length > 0);

        executeQueries(queries, (err, results) => {
            //console.log('results', results[results.length -1]);
            if (err) {
                console.error('Error in /adminSuperDashboard:', err);
                return res.status(500).send('Internal Server Error');
            }

            
            const concat = [];
            var n = 8;
            while(n>0) {
                concat.push(results[results.length -n]);
                n = n - 1;
            }
            var page_ = ejs.render(adminSuperDashboardPage, {
                title: "MySQL DB",
                data: concat,
            });
            res.send(page_);
        });
    });
    
});


app.get("/t_mypage", (req, res) => {
    res.render("t_myPage");
});

app.post("/toss_new_account", (req, res) => {
    //console.log('요청 받음:', req.body);
    const targetOwnerName = "김석조"; // hard-coding 

    sql_connection.query('insert into financeaccountlist(ownerName) values (?)', [targetOwnerName], (error, results, fields) => {
        if (error) throw error;

        res.render("t_myPage", { tossResult: 'success' }); // 200 OK

    });
});

app.get('/getOrderBook', (req, res) => {
    const ticker = req.query.ticker;
    const query = `
        select Transactions.TransactionTypeID, ReservedPrice, SUM(Transactions.shares) as total_quantity
        from Transactions
        join stocks on stocks.ticker = Transactions.ticker
        join CurrentPrices on stocks.ticker = CurrentPrices.ticker
        where Transactions.ticker = ? and TransactionTypeID in (1,2)
        group by TransactionTypeID, ReservedPrice
        order by (case when TransactionTypeID = 2 then ReservedPrice END) desc, (case when TransactionTypeID = 1 then ReservedPrice END) asc
        limit 10;
    `;
    sql_connection.query(query, [ticker], (err, results) => {
        if (err) {
            res.status(500).json({ error: 'DB error occurs' });

        } else {
            res.json(results);

        }
    });
})

app.get('/testFivePreferPrice', (req, res) => {
    //console.log('app get /testFivePreferPrice - called');
    res.render("testFivePreferPricePage")
})



/* * * */
router.route("/")
    .get((req, res) => {
        res.render("app");
    })
/* * * */

app.get("/", (req, res) => {
    res.render("app")
});


app.get("/search_general", (req, res) => {
    res.render("searchGeneralPage")
});

app.get("/connectcheck_" + targetTable[i], (req, res) => {
    sql_connection.query("SELECT * FROM " + targetTable[i] + ";", (err, result) => {
        if (err) throw err;
        else {
            var page = ejs.render(connectTestPage, {
                title: "MySQL DB",
                data: result,
            });
            res.send(page);

            i = i + 1;
            if (i == targetTable.length) i = 0;
        }
    });
});  //remove soon




/* User and login and signup routing defined */

app.get("/login", (req, res) => {
    res.render("loginPage")
});
app.post("/login", (req, res) => {
    const { userID, userPassword } = req.body;

    sql_connection.query('select * from userinfo where userID = ? and userPassword = ?', [userID, userPassword], (error, results, fields) => {
        if (error) throw error;
        if (results.length > 0) {
            res.send("로그인 성공")
        }
        else {
            res.render("loginPage", { loginResult: 'fail' });

        }
    });

});


app.get("/signup", (req, res) => {
    res.render("signupPage")
});
app.post("/signup", (req, res) => {
    const { userID, userPassword } = req.body;

    sql_connection.query('select * from userinfo where userID = ?', [userID], (error, results, fields) => {
        if (error) throw error;

        if (results.length > 0) {
            //results.send("이미 존재하는 아이디입니다.")   // <- 이 코드 써야할 수도 있음
            console.log("유저화면기준,다음메시지가출력되게: (이미 존재하는 아이디입니다. 다른 아이디를 입력해주세요.)");
            res.render("signupPage", { signupResult: 'fail' });  // 일단 이 코드 쓰는중
        }
        else {
            sql_connection.query('insert into userinfo(userID, userPassword) values (?, ?)', [userID, userPassword], (error, results, fields) => {
                if (error) throw error;
                else {
                    res.send("회원가입 완료");
                }
            })
        }
    });
});














app.listen(3001, () => {
    console.log("서버 실행 중");
});


