#ifndef BTREE_MGR_H
#define BTREE_MGR_H

#include "dberror.h"
#include "tables.h"
#include "const.h"
#include "dberror.h"
#include "data_structures.h"
#include "storage_mgr.h"
#include "buffer_mgr.h"

// Include bool DT
#include "dt.h"

typedef struct BT_Node {
  int size; // values size
  int isLeaf;
  int pageNum;
  pairArray  *vals;
  smartArray *childrenPages;
  smartArray *leafRIDPages;
  smartArray *leafRIDSlots;
  // tree pointers
  struct BT_Node **children; // in all but in leaf
  struct BT_Node *parent; // in all but in root
  struct BT_Node *left; // in all but in root
  struct BT_Node *right; // in all but in root
} BT_Node;


// change log:  DataType key;  <-  removed;
// structure for accessing btrees
typedef struct BTreeHandle {
  char reserved[4076];
  char *idxId;
  int size;           //sizeof: 4  
  int numEntries;     //sizeof: 4  
  int numNodes;      //sizeof:  4 
  int depth;         //sizeof:  4 
  int rpo;           //sizeof:  4    // 명세에 맞게, off_t  타입으로 선언해야함 &  sizeof: 8 로 생각하고, 다른 코드들도 수정해야함
  int nextPage;     //sizeof:   4  
  BT_Node *root;      
  void *mgmtData;
} BTreeHandle;

typedef struct BT_ScanHandle {
  BTreeHandle *tree;
  void *mgmtData;
} BT_ScanHandle;

typedef struct ScanMgmtInfo {
  BT_Node *currentNode;
  int elementIndex;
} ScanMgmtInfo;

// Node functions
BT_Node *createBTNode(int size, int isLeaf, int pageNum);

// init and shutdown index manager
extern RC initIndexManager (void *mgmtData);
extern RC shutdownIndexManager ();

// create, destroy, open, and close an btree index
extern RC createBtree (char *idxId, /*DataType keyType,*/ int n);
extern RC openBtree (BTreeHandle **tree, char *idxId);
extern RC closeBtree (BTreeHandle *tree);
extern RC deleteBtree (char *idxId);

// access information about a b-tree
extern RC getNumNodes (BTreeHandle *tree, int *result);
extern RC getNumEntries (BTreeHandle *tree, int *result);

// index access
extern RC findKey (BTreeHandle *tree, Value *key, RID *result);
extern RC insertKey (BTreeHandle *tree, Value *key, RID rid, char* dtShortLetters, int clen);
extern RC deleteKey (BTreeHandle *tree, Value *key);
extern RC openTreeScan (BTreeHandle *tree, BT_ScanHandle **handle);
extern RC nextEntry (BT_ScanHandle *handle, RID *result);
extern RC closeTreeScan (BT_ScanHandle *handle);

// debug and test functions
extern char *printTree (BTreeHandle *tree);

#endif // BTREE_MGR_H
