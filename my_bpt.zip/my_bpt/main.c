#include <stdlib.h>

#include "dberror.h"
#include "btree_mgr.h"
#include "tables.h"
#include "test_helper.h"

#define ASSERT_EQUALS_RID(_l, _r, message)                                  \
  do                                                                        \
  {                                                                         \
    ASSERT_TRUE((_l).page == (_r).page && (_l).slot == (_r).slot, message); \
  } while (0)

// test methods
static void testInsertAndFind(void);
static void testDelete(void);
static void testIndexScan(void);

// helper methods
static Value *stringToValue(char *val);
static Value **createValues(char **stringVals, int size);
static void freeValues(Value **vals, int size);
static int *createPermutation(int size);

// test name
char *testName;

// main method
int main(void)
{
  testName = "";

  // testInsertAndFind();
  testDelete();
  // testIndexScan();

  return 0;
}

// ************************************************************
void testInsertAndFind(void)
{
  RID insert[] = {
      {1, 1},
      {2, 3},
      {1, 2},
      {3, 5},
      {4, 4},
      {3, 2},
  };
  int numInserts = 6;
  Value **keys;
  char *stringKeys[] = {
      "i1",
      "i11",
      "i13",
      "i17",
      "i23",
      "i16"};
  testName = "test b-tree inserting and search";
  int i, testint;
  BTreeHandle *tree = NULL;

  keys = createValues(stringKeys, numInserts);

  // init
  TEST_CHECK(initIndexManager(NULL));
  TEST_CHECK(createBtree("DB2022094839.db", /*DT_INT,*/ 2));
  TEST_CHECK(openBtree(&tree, "DB2022094839.db"));

  // printTree  before insertion
  // printTree(tree);

  // insert keys
  for (i = 0; i < numInserts; i++)
  {
    char partLetter = (char)(rand() % 20 + 65);
    char partLetterNext = (char)(rand() % 21 + 65);
    char datum[120];
    datum[0] = partLetter;
    datum[1] = partLetterNext;
    datum[2] = '\0';
    int sz = 2;
    TEST_CHECK(insertKey(tree, keys[i], insert[i], datum, sz));
    printTree(tree);
  }

  // check index stats
  TEST_CHECK(getNumNodes(tree, &testint));
  // ASSERT_EQUALS_INT(testint,4, "number of nodes in btree");
  TEST_CHECK(getNumEntries(tree, &testint));
  ASSERT_EQUALS_INT(testint, numInserts, "number of entries in btree");

  // search for keys
  for (i = 0; i < numInserts; i++)
  {
    int pos = rand() % numInserts;
    RID rid;
    Value *key = keys[pos];

    TEST_CHECK(findKey(tree, key, &rid));
    ASSERT_EQUALS_RID(insert[pos], rid, "didwe " /*"did we find the correct RID?"*/);
  }

  // print tree & schema
  printTree(tree);
  // printSchema();
  //  cleanup
  TEST_CHECK(closeBtree(tree));
  // TEST_CHECK(deleteBtree("DB2022094839.db"));
  TEST_CHECK(shutdownIndexManager());
  freeValues(keys, numInserts);

  TEST_DONE();
}

// ************************************************************
void testDelete(void)
{
  RID insert[] = {
      {1, 1},
      {2, 3},
      {1, 2},
      {3, 5},
      {4, 4},
      {3, 2},
  };
  int numInserts = 6;
  Value **keys;
  char *stringKeys[] = {
      "i1",
      "i11",
      "i13",
      "i17",
      "i23",
      "i16",
  };
  testName = "test b-tree inserting and search";
  int i, iter;
  BTreeHandle *tree = NULL;
  int numDeletes = 3;
  bool *deletes = (bool *)malloc(numInserts * sizeof(bool));

  keys = createValues(stringKeys, numInserts);

  // init
  TEST_CHECK(initIndexManager(NULL));

  // create test b-tree and randomly remove entries
  for (iter = 0; iter < 3; iter++) // iter 50?
  {
    // randomly select entries for deletion (may select the same on twice)
    for (i = 0; i < numInserts; i++)
      deletes[i] = FALSE;
    for (i = 0; i < numDeletes; i++)
      deletes[rand() % numInserts] = TRUE;

    // init B-tree
    TEST_CHECK(createBtree("DB2022094839.db", 2));
    TEST_CHECK(openBtree(&tree, "DB2022094839.db"));

    // insert keys
    for (i = 0; i < numInserts; i++)
    {
      char partLetter = (char)(rand() % 20 + 65);
      char partLetterNext = (char)(rand() % 21 + 65);
      char datum[120];
      datum[0] = partLetter;
      datum[1] = partLetterNext;
      datum[2] = '\0';
      int sz = 2;
      TEST_CHECK(insertKey(tree, keys[i], insert[i], datum, sz));
      printTree(tree);
    }

    // delete entries
    for (i = 0; i < numInserts; i++)
    {
      if (deletes[i])
      {
        TEST_CHECK(deleteKey(tree, keys[i]));
        printTree(tree);
      }
    }

    // search for keys
    for (i = 0; i < numInserts; i++)
    {
      int pos = rand() % numInserts;
      RID rid;
      Value *key = keys[pos];

      if (deletes[pos])
      {
        int rc = findKey(tree, key, &rid);
        ASSERT_TRUE((rc == RC_IM_KEY_NOT_FOUND), "entry was deleted, should not find it");
      }
      else
      {
        TEST_CHECK(findKey(tree, key, &rid));
        ASSERT_EQUALS_RID(insert[pos], rid, "didwe " /*"did we find the correct RID?"*/);
      }
    }

    // cleanup
    TEST_CHECK(closeBtree(tree));
    TEST_CHECK(deleteBtree("DB2022094839.db"));
  }

  TEST_CHECK(shutdownIndexManager());
  freeValues(keys, numInserts);
  free(deletes);

  TEST_DONE();
}

// ************************************************************
void testIndexScan(void)
{
  RID insert[] = {
      {1, 1},
      {2, 3},
      {1, 2},
      {3, 5},
      {4, 4},
      {3, 2},
  };
  int numInserts = 6;
  Value **keys;
  char *stringKeys[] = {
      "i1",
      "i11",
      "i13",
      "i17",
      "i23",
      "i16"};

  testName = "random insertion order and scan";
  int i, testint, iter, rc;
  BTreeHandle *tree = NULL;
  BT_ScanHandle *sc = NULL;
  RID rid;

  keys = createValues(stringKeys, numInserts);

  // init
  TEST_CHECK(initIndexManager(NULL));

  for (iter = 0; iter < 50; iter++)
  {
    int *permute;

    // create permutation
    permute = createPermutation(numInserts);

    // create B-tree
    TEST_CHECK(createBtree("DB2022094839.db", /*DT_INT,*/ 2));
    TEST_CHECK(openBtree(&tree, "DB2022094839.db"));

    // insert keys
    for (i = 0; i < numInserts; i++)
    {
      char partLetter = (char)(rand() % 20 + 65);
      char partLetterNext = (char)(rand() % 21 + 65);
      char datum[120];
      datum[0] = partLetter;
      datum[1] = partLetterNext;
      datum[2] = '\0';
      int sz = 2;
      TEST_CHECK(insertKey(tree, keys[permute[i]], insert[permute[i]], datum, sz));
    }

    // check index stats
    TEST_CHECK(getNumEntries(tree, &testint));
    ASSERT_EQUALS_INT(testint, numInserts, "number of entries in btree");

    // execute scan, we should see tuples in sort order
    openTreeScan(tree, &sc);
    i = 0;
    while ((rc = nextEntry(sc, &rid)) == RC_OK)
    {
      RID expRid = insert[i++];
      ASSERT_EQUALS_RID(expRid, rid, "didwe " /*"did we find the correct RID?"*/);
    }
    ASSERT_EQUALS_INT(RC_IM_NO_MORE_ENTRIES, rc, "no error returned by scan");
    ASSERT_EQUALS_INT(numInserts, i, "have seen all entries");
    closeTreeScan(sc);

    // cleanup
    TEST_CHECK(closeBtree(tree));
    // TEST_CHECK(deleteBtree("DB2022094839.db"));
    free(permute);
  }

  TEST_CHECK(shutdownIndexManager());
  freeValues(keys, numInserts);

  TEST_DONE();
}

// ************************************************************
int *createPermutation(int size)
{
  int *result = (int *)malloc(size * sizeof(int));
  int i;

  for (i = 0; i < size; result[i] = i, i++)
    ;

  for (i = 0; i < 100; i++)
  {
    int l, r, temp;
    l = rand() % size;
    r = rand() % size;
    temp = result[l];
    result[l] = result[r];
    result[r] = temp;
  }

  return result;
}

Value *
stringToValue(char *val)
{
  Value *result = (Value *)malloc(sizeof(Value));

  switch (val[0])
  {
  case 'i':
    result->dt = DT_INT;
    result->v.intV = atoi(val + 1);
    break;
  case 'f':
    result->dt = DT_FLOAT;
    result->v.floatV = atof(val + 1);
    break;
  case 's':
    result->dt = DT_STRING;
    result->v.stringV = malloc(strlen(val));
    strcpy(result->v.stringV, val + 1);
    break;
  case 'b':
    result->dt = DT_BOOL;
    result->v.boolV = (val[1] == 't') ? TRUE : FALSE;
    break;
  default:
    result->dt = DT_INT;
    result->v.intV = -1;
    break;
  }

  return result;
}

// ************************************************************
Value **
createValues(char **stringVals, int size)
{
  Value **result = (Value **)malloc(sizeof(Value *) * size);
  int i;

  for (i = 0; i < size; i++)
    result[i] = stringToValue(stringVals[i]);

  return result;
}

// ************************************************************
void freeValues(Value **vals, int size)
{
  while (--size >= 0)
    free(vals[size]);
  free(vals);
}
