#ifndef STORAGE_MGR_H
#define STORAGE_MGR_H

#include "dberror.h"
#include "const.h"
#include "data_structures.h"
#include "dt.h"
#include "tables.h"
#include "errno.h"
#include "stdint.h"
#include "inttypes.h"
#include "stdlib.h"
#include "string.h"
#include "sys/stat.h"
#include "sys/types.h"
#include "fcntl.h"
#include "unistd.h"




/************************************************************
 *                    handle data structures                *
 ************************************************************/
typedef struct SM_FileHandle {
  char fileName[4076];
  int64_t totalNumPages;   //sizeof: 8    
  int curPagePos;          //sizeof: 4    
  //int fpo;
  void *mgmtInfo;          //sizeof:     
} SM_FileHandle; 

typedef char* SM_PageHandle;

typedef struct HeaderPage {
    int size;                   // 페이지 크기
    off_t fpo;                  // 프리 페이지 오프셋
    int rpo;                    // 루트 페이지 오프셋
    int64_t numOfPages;         // 페이지 개수
    //char reserved[4076];        // hard coding? 4076
} HeaderPage;


/************************************************************
 *                    interface                             *
 ************************************************************/
/* manipulating page files */
extern void initStorageManager (void);
extern RC createPageFile (char *fileName);
extern RC openPageFile (char *fileName, SM_FileHandle *fHandle);
extern RC closePageFile (SM_FileHandle *fHandle);
extern RC destroyPageFile (char *fileName);

/* reading blocks from disc */
extern RC readBlock (int64_t pageNum, SM_FileHandle *fHandle, SM_PageHandle memPage);
extern int getBlockPos (SM_FileHandle *fHandle);
extern RC readFirstBlock (SM_FileHandle *fHandle, SM_PageHandle memPage);
extern RC readPreviousBlock (SM_FileHandle *fHandle, SM_PageHandle memPage);
extern RC readCurrentBlock (SM_FileHandle *fHandle, SM_PageHandle memPage);
extern RC readNextBlock (SM_FileHandle *fHandle, SM_PageHandle memPage);
extern RC readLastBlock (SM_FileHandle *fHandle, SM_PageHandle memPage);

/* writing blocks to a page file */
extern RC writeBlock (int64_t pageNum, SM_FileHandle *fHandle, SM_PageHandle memPage);
extern RC writeCurrentBlock (SM_FileHandle *fHandle, SM_PageHandle memPage);
extern RC appendEmptyBlock (SM_FileHandle *fHandle);
extern RC ensureCapacity (int64_t numberOfPages, SM_FileHandle *fHandle);

extern void printRootHeaderInfo(HeaderPage *my_h);
//extern void syncMyRootHeaderByAssigningBTHeader(HeaderPage *my_h, BTreeHandle *tree);
#endif
