
const express = require('express');
const path = require('path');
const app = express();
const session = require('./config/session');
const userRoutes = require('./routes/userRoutes');
const orderRoutes = require('./routes/orderRoutes');
const sql_connection = require('./config/db');
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(session);
app.use('/', userRoutes);
app.use('/api', orderRoutes);
app.set("view engine", "ejs");
app.set("views", "./views");
app.set("views", path.join(__dirname, 'views'));
const cron = require('node-cron');
app.get('/', (req, res) => {
    res.render('sitemapDeveloperPage');
})


// Next line ~ . . cron related: under test below..
// Get the latest transaction price for a stock
const getLatestTransactionPrice = (stockSymbol, callback) => {
    const query = 'SELECT pricepershare FROM transact JOIN order_ ON order_.OrderId = transact.OrderId WHERE StockSymbol = ? ORDER BY transact.timestamp_ DESC LIMIT 1';
    sql_connection.query(query, [stockSymbol], (err, results) => {

        if (err) throw err;

        callback(results.length > 0 ? results[0].pricepershare : null);
    });
};

// Fetch all stock symbols from the database
const getAllStockSymbols = (callback) => {

    const query = 'SELECT StockSymbol FROM stock';
    sql_connection.query(query, (err, results) => {

        if (err) throw err;

        callback(results.map(row => row.StockSymbol));

    });
};

// Save closing price to stockpricehistory
const saveClosingPrice = (stockSymbol) => {
    getLatestTransactionPrice(stockSymbol, (latestPrice) => {
        if (latestPrice !== null) {

            const query = 'INSERT INTO stockpricehistory (StockSymbol, SharePrice, Timestamp_) VALUES (?, ?, ?)';
            sql_connection.query(query, [stockSymbol, latestPrice, new Date()], (err) => {
                if (err) throw err;

            });
        } else {
            const query_exception_dealing_query = 'INSERT INTO stockpricehistory (StockSymbol, SharePrice, Timestamp_) VALUES (?, (SELECT SharePrice FROM stock WHERE StockSymbol = ?), ?)';
            sql_connection.query(query_exception_dealing_query, [stockSymbol, stockSymbol, new Date()], (err) => {
                if (err) throw err;
                // console.log(`[But Exceptionally dealt] Inserted closing price for ${stockSymbol}: `);
            });
        }
    });
};

// Check if the market is closed
cron.schedule('* * * * *', () => {
    const now = new Date();
    const currentHour = now.getHours(); // 1 ~ 23 으로 테스트하기 (현재 아래코드 보면, -1 넣어뒀음) 18시로 테스트하고 싶으면 === 18
    const currentMinute = now.getMinutes();

    // Check if market closes automatically 1분마다 
    if (currentHour === -1 && [7, 8, 9].includes(currentMinute)) { // <- hard coded yet just for my convenience  // later it should be modified
        //console.log('Market closed. Fetching closing prices...');
        //console.log(currentHour) console.log(currentMinute)
        console.log(currentMinute)

        getAllStockSymbols((symbols) => {

            for (let i = 0; i < symbols.length; i++) {

                saveClosingPrice(symbols[i]);
            }
        });
    }
});






//
app.listen(3001, () => {
    console.log("서버 실행 중");
});







module.exports = app;



// DetailPriceSelection 알고리즘 <- 이건 지우지 말기 일단
/*

const queryDetailPricePercentageSelectionQ = `SELECT
    stocksymbol,
    stockpricehistory.shareprice AS previous_close_price
FROM
    stockpricehistory
WHERE
    timestamp_ = (SELECT MAX(timestamp_) FROM stockpricehistory WHERE stocksymbol = ?)
    and stocksymbol = ?`;

 let page = ejs.render(detailPercentPage, {
                data: results,
            });
            res.send(page);

sql connection query (queryDetailPricePercentageSelectionQ, [ss, ss], () => {} */








/* version one, two NOT being used currently.. */
/*

    var versionOne_ALPHA_FULL = 
    WITH Previous_Close_ AS(SELECT stocksymbol, stockpricehistory.shar
    eprice AS previous_close_price FROM stockpricehistory WHERE timestamp_ = (SELECT MAX(timestamp_) F
    ROM stockpricehistory WHERE stocksymbol = ?) and stocksymbol = ?) SELECT Stock.stockname, Stock
        .stocksymbol, Stock.shareprice AS current_price, Pre
    vious_Close_.previous_close_price, ROUND((Stock.shareprice - Previous_Close_.previo

    us_close_price), 2) AS change_price, ROUND((((Stock.shareprice - Previous_Close_.previ
    ous_close_price) / Previous_Close_.previous_close_price  ) * 100), 2) AS change_percent FROM Stock JOIN Previous_Close_ ON Stock.stocksymbol = Previous_Close_.stocksymbol;
    var versionTwo_BETA_SIMPLE =
    WITH Previous_Close_ AS(SELECT stocksy
    mbol, stockpricehistory.shareprice AS previous_close_price FROM stockpricehisto
    ry WHERE timestamp_ =
    (SELECT MAX(timestamp_) FROM stockpricehistory WHERE stocksymbol = ?) and stocksymbol
        = ?) SELECT Stock.stockname, Stock.stocksymbol, Stock.shareprice AS current_price, ROUND((((Stock.shareprice - Previous_Close_.previous_close_price) /
        Previous_Close_.previous_close_price) * 100), 2) AS change_percent FROM Stock JOIN Previous_Close_ ON Stock.stocksymbol = Previous_Close_.stocksymbol;
*/

/* var versionThr_GAMMA_BEST = `WITH Previous_Close_ AS (
    SELECT 
    stocksymbol,
    MAX(timestamp_) AS latest_timestamp
FROM 
    stockpricehistory
GROUP BY 
    stocksymbol
),
something AS (
select
Previous_Close_.stocksymbol,
stockpricehistory.shareprice AS previous_close_price    
from stockpricehistory
join Previous_Close_ on Previous_Close_.stocksymbol = stockpricehistory.stocksymbol
where stockpricehistory.timestamp_ = Previous_Close_.latest_timestamp
)
SELECT 
Stock.stockname, 
Stock.stocksymbol, 
Stock.shareprice AS current_price, 
ROUND(
(
  (
    (
      Stock.shareprice - something.previous_close_price
    ) / something.previous_close_price
  ) * 100
), 
2
) AS change_percent 
FROM 
Stock 
JOIN something ON Stock.stocksymbol = something.stocksymbol`;*/

















