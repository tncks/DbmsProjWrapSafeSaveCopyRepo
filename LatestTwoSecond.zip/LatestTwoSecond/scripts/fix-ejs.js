const fs = require('fs');
const path = require('path');

// 수정할 EJS 파일 경로
const originalFilePath = path.join(__dirname, '..', 'node_modules', 'ejs', 'lib', 'ejs.js');
// 수정된 파일 경로
const modifiedFilePath = path.join(__dirname, 'ejs.js');

// 원본 파일 덮어쓰기
fs.copyFile(modifiedFilePath, originalFilePath, (err) => {
    if (err) {
        console.error('Error copying file:', err);
    } else {
        console.log('EJS file modified successfully!');
    }
});
