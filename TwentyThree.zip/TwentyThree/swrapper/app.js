
const express = require('express');
const path = require('path');
const app = express();
const orderRoutes = require('./routes/orderRoutes');
const mysql = require('mysql2');
const sql_connection = require('./config/db');
const targetTable = ["account_", "conditionalpricehistory", "customer", "login",
    "order_", "transact", "portfolio", "stock", "stockpricehistory", "order_history"];

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/api', orderRoutes);
app.set("view engine", "ejs");
app.set("views", "./views");
const ejs = require("ejs");
const fs = require('fs');
const cron = require('node-cron');
const welcomePage = fs.readFileSync('./views/welcomePage.ejs', 'utf8');
const fivePreferPricePage = fs.readFileSync('./views/fivePreferPricePage.ejs', 'utf8');
const ordersPage = fs.readFileSync('./views/ordersPage.ejs', 'utf8');
const transactionsPage = fs.readFileSync('./views/transactionsPage.ejs', 'utf8');
const homePage = fs.readFileSync('./views/homePage.ejs', 'utf8');
const fundPage = fs.readFileSync('./views/fundPage.ejs', 'utf8');
const loginPage = fs.readFileSync('./views/loginPage.ejs', 'utf8');
const signupPage = fs.readFileSync('./views/signupPage.ejs', 'utf8');
const connectTestPage = fs.readFileSync('./views/connectTestPage.ejs', 'utf8');
const adminSuperDashboardPage = fs.readFileSync('./views/adminSuperDashboardPage.ejs', 'utf8');
const session = require('express-session');
const isAuthenticated = require('./middleware/auth');
app.use(session({
    secret: 'abIASDJWasodhwAHWagQ',
    resave: false,
    saveUninitialized: true,
    cookie: {
        secure: false,
        maxAge: 1000 * 60 * 60  // 1 hour expire setting
    }
}));
var i = 0;
const basicQ = `WITH Previous_Close_ AS (
    SELECT 
        stocksymbol,
        MAX(timestamp_) AS latest_timestamp
    FROM 
        stockpricehistory
    GROUP BY 
        stocksymbol
),
something AS (
    select
    Previous_Close_.stocksymbol,
    stockpricehistory.shareprice AS previous_close_price    
    from stockpricehistory
    join Previous_Close_ on Previous_Close_.stocksymbol = stockpricehistory.stocksymbol
    where stockpricehistory.timestamp_ = Previous_Close_.latest_timestamp
)
SELECT 
  Stock.stockname, 
  Stock.stocksymbol, 
  Stock.shareprice AS current_price, 
  ROUND(
    (
      (
        (
          Stock.shareprice - something.previous_close_price
        ) / something.previous_close_price
      ) * 100
    ), 
    2
  ) AS change_percent 
FROM 
  Stock 
  JOIN something ON Stock.stocksymbol = something.stocksymbol`;
function executeQueries(queries, callback) {
    let results = [];
    let index = 0;
    let len = 1;

    function executeNextQuery() {
        if (index >= queries.length) {
            return callback(null, results); // 모든 쿼리 완료
        }

        sql_connection.query(queries[index], (err, result) => {
            if (err) {
                console.error('Error executing query:', queries[index], err);
                return callback(err);
            }
            const meaning = ["ChangedPriceDataOfSpecificStockDetailInfoTable", "StockRevenue", "ChangedPriceDataOfSpecificStockDetailInfoTable", "MostTraded"]; // 5 6 7 8
            if (queries.length - index < 5 && queries.length - index >= 1) len = meaning.length - (queries.length - index);
            results.push({ table: meaning[len], data: result });
            index++;
            executeNextQuery(); // 다음 쿼리 실행
        });
    }

    executeNextQuery(); // 첫 번째 쿼리 실행
}

const getOrder = /*async*/ (req, res, next) => {
    let order;
    try {
        const my_custom_select_query = `SELECT * from order_ where orderId = ?`;

        sql_connection.query(my_custom_select_query, [req.params.id], (err, results) => {
            if (err) throw err;

            if (results.length > 0) {
                order = results[0];
                console.log(';');
            } else {
                // order is null (result is null)
                return res.status(404).json({ message: 'Order does not exist. ' });
            }
        })


    } catch (err) {
        return res.status(500).json({ message: err.message })
    }
    res.order = order;
    next();
};




const saveTransactionArr = async (transactionArr) => {
    //console.log('saving transaction array');
    let transactions_data_prepared;    // userId amount type 순 
    transactions_data_prepared = transactionArr;

    // SQL 쿼리 생성
    const my_custom_query = `INSERT INTO transact (userId, amount, type) VALUES ?`;


    // values 배열 준비
    const values = transactions_data_prepared.map(transaction => [transaction.userId, transaction.amount, transaction.type]);



    if (!Array.isArray(transactionArr) || !transactionArr.length) {
        console.log('#');
        return;
    } else {
        try {

            sql_connection.query(my_custom_query, [values], (err, results) => {
                if (err) {
                    console.error(err);
                    throw err;
                }
            });


        } catch (err) {
            console.log(err);
        };
    };
    return;
};


const updateFilledOrderArr = /*async*/ (filledOrderArr) => {
    if (!Array.isArray(filledOrderArr) || !filledOrderArr.length) {
        return;
    } else {
        try {

            // prepare
            const my_custom_query = `UPDATE order_ SET units = 0, is_filled = 1 WHERE OrderId IN (${filledOrderArr.map(() => '?').join(', ')})`;

            // 값 배열 생성
            const values = filledOrderArr.map(orderId => orderId);

            // updateOne

            sql_connection.execute(my_custom_query, values /*[filledOrderArr[i]]*/);


            // await Order.updateOne(
            //     { _id: filledOrderArr[i] },
            //     {
            //         $set: {
            //             is_filled: 1,
            //             units: 0
            //         }
            //     },
            // );

        } catch (err) {
            console.log(err);
        };
    };
    return;
};



// CREATE one order
const queryAndMatchPairs = async (req, res, isNewOrder) => {    // conflict '/' path

    let transactionArr = [];
    let filledOrderArr = [];
    let topPairResult;
    let { id, user_id, stock_symbol, units, order_time } = req.body;
    let original_units = units;
    if (isNewOrder && req.body.units <= 0) {
        console.log('invalid req');
        return res.status(400).json({ message: 'Invalid order input' });
    }

    const searchForPair = async () => {
        const filterQuery = `
        SELECT * FROM order_
        WHERE stock_symbol = ?
        AND order_type = ?
        AND price ${req.body.order_type === 'buy' ? '<=' : '>='} ?
        AND units > 0
        AND is_filled = 0
        ORDER BY price ${req.body.order_type === 'buy' ? 'ASC' : 'DESC'}, order_time ASC
        LIMIT 1
        `;

        const updateQuery = `
        UPDATE order_
        SET units = units - ?, is_partially_filled = 1
        WHERE OrderId = ?
        `;


        try {

            // 1. 조건에 맞는 주문을 찾기
            const [rows] = await sql_connection.execute(filterQuery, [req.body.stock_symbol, (req.body.order_type === 'buy') ? 'sell' : 'buy', req.body.price]);

            if (rows.length === 0) {
                console.log('null');
                return null; // 조건에 맞는 주문이 없는 경우
            }

            let resulted_order = rows[0];
            console.log('resulted_order: ', resulted_order);

            // 2. 주문 업데이트
            await sql_connection.execute(updateQuery, [resulted_order.units, resulted_order.orderId]);


            sql_connection.query(`select * from order_ where OrderId = ?`, [resulted_order.orderId], (err, results) => {
                if (err) throw err;

                if (results.length > 0) {
                    resulted_order = results[0];

                }
            });
            return resulted_order; // 업데이트된 주문 반환
        } catch (err) {
            console.log(err);
            return null;
        }
    }

    let remaining_units = units;
    while (remaining_units > 0) {
        topPairResult = await searchForPair();

        // No matching trading pair is found
        if (!topPairResult) {
            try {
                // Since this could be after some paring iterations
                let myTmpBool;
                if (remaining_units > 0 && 1 !== 1) {
                    myTmpBool = 1;
                }
                if (isNewOrder) {
                    // insert into query statement (save)
                    if (typeof myTmpBool === 'undefined') {
                        // myTmpBool 이 1이 아닌 경우(type of undefined 와 같음)
                        const my_f_query = `insert into order_ (user_id,stock_symbol,order_type,original_units,units,price,is_filled,is_partially_filled) values (?,?,?,?,?,?,0,0)`;
                        await sql_connection.query(my_f_query, [req.body.user_id, req.body.stock_symbol, req.body.order_type, req.body.units, req.body.units, req.body.price]);


                    } else {
                        // myTmpBool == 1 인 경우
                        const my_f_query = `insert into order_ (user_id,stock_symbol,order_type,original_units,units,price,is_filled,is_partially_filled) values (?,?,?,?,?,?,0,1)`;
                        await sql_connection.query(my_f_query, [req.body.user_id, req.body.stock_symbol, req.body.order_type, req.body.units, req.body.units, req.body.price]);


                    }

                } else {
                    // update (updateOne)
                    if (typeof myTmpBool === 'undefined') {
                        // myTmpBool 이 1이 아닌 경우(type of undefined 와 같음)
                        // update target without changing the is_partiall_filled
                        // just update
                        const my_c_query = `update order_ set price = ?, units = ?, original_units = ? where OrderId = ?`;
                        sql_connection.execute(my_c_query, [req.body.price, req.body.units, original_units, id]);

                    } else {
                        // myTmpBool == 1 인 경우
                        // update target with option is_partially_filled = 1
                        // additional update
                        const my_c_query = `update order_ set price = ?, units = ?, original_units = ?, is_partially_filled = 1 where OrderId = ?`;
                        sql_connection.execute(my_c_query, [req.body.price, req.body.units, original_units, id]);

                    }

                }
            } catch (err) {
                console.log(err);
                return res.status(400).json({ message: err.message });
            }
            break;
        } else { // A matching trading pair is found
            const buy_order_id = req.body.order_type === 'buy' ? req.body.id : topPairResult.OrderId;
            const sell_order_id = req.body.order_type === 'sell' ? req.body.id : topPairResult.OrderId;

            // If one existing order can fill the entire new order
            if (topPairResult.units >= 0) {
                transactionArr.push({
                    stock_symbol: req.body.stock_symbol,
                    units: remaining_units,
                    price: Math.abs(
                        (req.body.price + topPairResult.price) / 2
                    ).toFixed(0),
                    buy_order_id: buy_order_id.toString(),
                    sell_order_id: sell_order_id.toString(),
                });

                remaining_units = 0;

                //
                if (isNewOrder) {
                    // insert into query statement (save)


                    const my_f_query = `insert into order_ (user_id,stock_symbol,order_type,original_units,units,price,is_filled,is_partially_filled) values (?,?,?,?,0,?,1,1)`;
                    await sql_connection.query(my_f_query, [req.body.user_id, req.body.stock_symbol, req.body.order_type, req.body.units, req.body.price]);




                } else {
                    // update (updateOne)



                    const my_u_query = `update order_ set price = ?, units = 0, original_units = ?, is_partially_filled = 1, is_filled = 1 where OrderId = ?`;
                    sql_connection.execute(my_u_query, [req.body.price, original_units, id]);



                }
                //


                topPairResult.units === 0 && filledOrderArr.push(topPairResult.orderId.toString());

            } else { // It will take multiple orders
                transactionArr.push({
                    stock_symbol: req.body.stock_symbol,
                    units: req.body.units - Math.abs(topPairResult.units),
                    price: Math.abs(
                        (req.body.price + topPairResult.price) / 2
                    ).toFixed(0),
                    buy_order_id: buy_order_id.toString(),
                    sell_order_id: sell_order_id.toString(),
                });

                remaining_units = Math.abs(topPairResult.units);
                //
                if (isNewOrder) {
                    // insert into query statement (save)


                    const my_f_query = `insert into order_ (user_id,stock_symbol,order_type,original_units,units,price,is_filled,is_partially_filled) values (?,?,?,?,?,?,0,1)`;
                    await sql_connection.query(my_f_query, [req.body.user_id, req.body.stock_symbol, req.body.order_type, req.body.units, remaining_units, req.body.price]);




                } else {
                    // update (updateOne)



                    const my_u_query = `update order_ set price = ?, units = ?, original_units = ?, is_partially_filled = 1, is_filled = 0 where OrderId = ?`;
                    sql_connection.execute(my_u_query, [req.body.price, remaining_units, original_units, id]);



                }
                //

                filledOrderArr.push(topPairResult.orderId.toString());
            }
        }

    }



    // SAVE THE T
    await saveTransactionArr(transactionArr);

    // UPDATE THE NEGATIVE
    await updateFilledOrderArr(filledOrderArr);

};


// GET all orders
app.get('/orders', (req, res) => {
    const my_custom_selall_query = `SELECT * from order_ ORDER BY order_time DESC`;
    try {

        sql_connection.query(my_custom_selall_query, (err, results) => {
            if (err) throw err;
            const orders = results;

            var page = ejs.render(ordersPage, {
                data: orders
            });
            res.send(page);


        });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});



// GET all orders in JSON format
// app.get('/orders/JSON', (req, res) => {
//     const my_custom_selall_query = `SELECT * from order_`;
//     try {
//         //const orders = await Order.find();
//         sql_connection.query(my_custom_selall_query, (err, results) => {
//             if (err) throw err;
//             const orders = results;
//             res.json(orders);
//         });
//     } catch (err) {
//         res.status(500).json({ message: err.message });
//     }
// });

/* */
// GET all transactions
app.get('/transactions', (req, res) => {
    const my_custom_selall_query = `SELECT * FROM transact ORDER BY transaction_time DESC`;
    try {

        sql_connection.query(my_custom_selall_query, (err, results) => {
            if (err) throw err;
            const transactions = results;

            var page = ejs.render(transactionsPage, {
                data: transactions
            });
            res.send(page);


        });

    } catch (err) {
        res.status(500).json({ message: err.message });
    }

});


// GET all transactions in JSON format
// app.get('/transactions/JSON', (req, res) => {
//     const my_custom_selall_query = `SELECT * FROM transact`;
//     try {
//         //const transactions = await Transaction.find();
//         sql_connection.query(my_custom_selall_query, (err, results) => {
//             if (err) throw err;
//             const transactions = results;
//             res.json(transactions);
//         });

//     } catch (err) {
//         res.status(500).json({ message: err.message });
//     }

// });



/* */
// GET one by id
app.get('/orders/:id', getOrder, (req, res) => {
    res.status(200).json(res.order);
});

// CREATE one order
app.post('/', async (req, res) => {   // path conflict potential issue
    await queryAndMatchPairs(req, res, true);

    res.status(200).redirect('/orders');
});


// PATCH one order
app.patch('/:id', /*async*/(req, res) => {

    const { id, user_id, stock_symbol, order_type, units, price, order_time } = req.body;   // id 주석? yes vs no?
    //  id 주석 처리 해야 할 수도 있음 (path 에서 id 를 받기 때문에 /:id )


    if (!res.order.is_filled && !res.order.is_partially_filled) {

        if (typeof units !== 'undefined' && units !== null) {
            res.order.units = units;
        }
        if (typeof price !== 'undefined' && price !== null) {
            res.order.price = price;
        }

        try {
            // findOneAndUpdate
            const my_custom_update_query = `update order_ set units = ?, price = ? where orderId = ?`;
            sql_connection.execute(my_custom_update_query, [res.order.units, res.order.price, id])
                .then((results) => { // results: rowNumAffected 를 의미
                    const updatedOrder = {
                        orderId: id,
                        user_id: user_id,
                        stock_symbol: stock_symbol,
                        order_type: order_type,
                        units: res.order.units,
                        price: res.order.price,
                        /*order_time: order_time*/
                        is_partially_filled: res.order.is_partially_filled,
                        is_filled: res.order.is_filled,
                    };
                    res.json(updatedOrder);
                })
            //

        } catch (err) {
            res.status(400).json({ message: err.message });
        }

    } else if (res.order.is_filled) {
        res.status(405).json({
            message: "Order is filled and cannot be modified."
        });

    } else {
        res.status(405).json({
            message: "Order is partially filled and cannot be modified."
        });
    }



});

// DELETE one
app.delete('/:id', getOrder, /*async*/(req, res) => {
    const { id, user_id } = req.body;   // id 주석? yes vs no?
    //  id 주석 처리 해야 할 수도 있음 (path 에서 id 를 받기 때문에 /:id )

    if (!res.order.is_filled && !res.order.is_partially_filled) {

        try {
            //await res.order.remove(); // delete query        

            const my_custom_delete_query = `delete from order_ where OrderId = ?`;
            sql_connection.execute(my_custom_delete_query, [id])
                .then((results) => {
                    if (results.affectedRows > 0) {
                        res.json({ message: "Order has been successfully cancelled" });
                    } else {
                        console.log('#');
                        res.json({ message: "Order cancellation failed" });
                    }
                });


        } catch (err) {
            res.status(400).json({ message: err.message });
        }

    } else if (res.order.is_filled) {
        res.status(405).json({
            message: "Order is filled and cannot be cancelled."
        });

    } else {
        res.status(405).json({
            message: "Order is partially filled and cannot be cancelled."
        });
    }
});






app.get('/getOrderBook', (req, res) => {
    const stocksymbol = req.query.stocksymbol;
    const queryFiveAskBidPriceOfStockSelectionQ = `
        select order_.OrderType, order_.StopPrice, sum(order_.NumShares) as total_quantity_shares
        from order_
        join stock on stock.stocksymbol = order_.stocksymbol
        where order_.stocksymbol = ? and order_.ordertype in ('Sell','Buy')
        group by order_.ordertype, order_.stopprice
        order by (case when order_.ordertype = 'Sell' then order_.stopprice END) desc, (case when order_.ordertype = 'Buy' then order_.stopprice END) asc
        limit 10;
        `;

    sql_connection.query(queryFiveAskBidPriceOfStockSelectionQ, [stocksymbol], (err, results) => {
        if (err) {
            res.status(500).json({ error: 'DB error occurs' });

        } else {
            res.json(results);

        }
    });
})

app.get('/fivePreferPrice', (req, res) => {
    var page = ejs.render(fivePreferPricePage, {
        data: req.query.stocksymbol,
    });
    res.send(page);
})

app.get("/search_general", (req, res) => {
    res.render("searchGeneralPage")
});

app.get("/welcome", (req, res) => {
    var unconditionalStockListDeliveryToFrontSide;


    /* SELECT ALL STOCK AT FIRST */

    sql_connection.query(basicQ, (err, result) => {
        if (err) throw err;
        if (result.length > 0) {
            unconditionalStockListDeliveryToFrontSide = result;
        }
        else {
            console.log('Empty 테이블: 주식 정보 하나도 없음');
            unconditionalStockListDeliveryToFrontSide = 0;
        }



        if (req.session.userID && req.session.userID.length >= 1) {

            console.log('Detected: strange request from a strange client..');
            console.log('username is :');
            console.log(req.session.userID);
            var page = ejs.render(homePage, {
                data: unconditionalStockListDeliveryToFrontSide,
            });
            return res.send(page);

        }


        var page = ejs.render(welcomePage, {
            data: unconditionalStockListDeliveryToFrontSide,
        });
        res.send(page);

    });



});

app.get("/home", isAuthenticated, (req, res) => {
    var unconditionalStockListDeliveryToFrontSide;


    /* SELECT ALL STOCK AT FIRST */

    sql_connection.query(basicQ, (err, result) => {
        if (err) throw err;
        if (result.length > 0) {
            unconditionalStockListDeliveryToFrontSide = result;
        }
        else {
            console.log('Empty 테이블: 주식 정보 하나도 없음');
            unconditionalStockListDeliveryToFrontSide = 0;
        }


        if (req.session.userID && req.session.userID.length >= 1) {

            var page = ejs.render(homePage, {
                data: unconditionalStockListDeliveryToFrontSide,
            });
            res.send(page);


        } else {

            console.log('Detected: strange request from an anonymous human..');
            var page = ejs.render(welcomePage, {
                data: unconditionalStockListDeliveryToFrontSide,
            });
            res.send(page);

        }

    });


});

/* logout(in) and signup routing defined */

app.post("/logout", (req, res) => {
    var unconditionalStockListDeliveryToFrontSide;


    // in code level here: do something first, such as session destroy user, and other stuff works, then if all ok, then redirect to welcome Page. for now, logout process done!

    /* early code starts from here.. */
    req.session.destroy(err => {
        if (err) {
            return res.redirect('/welcome'); // somewhere : /welcome or any other path anything!
        }
        // Description:else -> destroy was normally done. then now execute next code line.
    });





    /* basic fundamental code starts from here.. */

    sql_connection.query(basicQ, (err, result) => {
        if (err) throw err;
        if (result.length > 0) {
            unconditionalStockListDeliveryToFrontSide = result;
        }
        else {
            console.log('Empty 테이블: 주식 정보 하나도 없음');
            unconditionalStockListDeliveryToFrontSide = 0;
        }
    });

    var page = ejs.render(welcomePage, {
        data: unconditionalStockListDeliveryToFrontSide,
    });
    res.send(page); // render the welcome Page with query data of stock list in order for displaying default home screen with basic table contents
    // all done.

});


app.get("/login", (req, res) => {
    if (req.session.userID && req.session.userID.length >= 1) {

        console.log('Detected: strange request from a strange client..');
        console.log('username is :');
        console.log(req.session.userID);
        var page = ejs.render(homePage, {});
        return res.send(page);


    } else {

        var page = ejs.render(loginPage, {
            data: {},
        });
        res.send(page);

    }

});
app.post("/login", (req, res) => {
    const { userID, userPassword } = req.body;
    var unconditionalStockListDeliveryToFrontSide;
    const queryUserCredentialMatchDuringLoginSelectionQ = `select * from login where Usr = ? and Pwd = ?`;


    /* SELECT ALL STOCK AT FIRST */

    sql_connection.query(basicQ, (err, result) => {
        if (err) throw err;
        if (result.length > 0) {
            unconditionalStockListDeliveryToFrontSide = result;
        }
        else {
            console.log('Empty 테이블: 주식 정보 하나도 없음');
            unconditionalStockListDeliveryToFrontSide = 0;
        }
    });



    /* CHECK LOGIN CREDENTIAL IF THE USER EXISTS TO PROCESS LOGIN STUFF AND MOVE TO HOME DASH IF OK */

    sql_connection.query(queryUserCredentialMatchDuringLoginSelectionQ, [userID, userPassword], (error, results, fields) => {
        if (error) throw error;
        if (results.length > 0) {
            //console.log('results 0 index thing');
            //console.log((results[0].Id));
            //console.log((results.CusId));
            // Good. 200 OK status:   로그인 성공

            req.session.userID = userID;    // userId를 세션에 저장
            req.session.CusId = results[0].Id; // CusID (Id)를 세션에 저장


            var page = ejs.render(homePage, { data: unconditionalStockListDeliveryToFrontSide });
            res.send(page);
        }
        else {
            res.render("loginPage", { loginResult: 'fail' });

        }
    });

});


app.get("/signup", (req, res) => {
    var page = ejs.render(signupPage, {
        title: "Title",
        data: {},
    });
    res.send(page);
});
app.post("/signup", (req, res) => {
    const { userID, userPassword, userLastName, userFirstName } = req.body;
    const queryUserinfoDuringRegistSelectionQ = `select * from login where Usr = ?`;
    const queryUserNormalAddDuringRegistInsertion_1Q_1 = `insert into customer (LastName, FirstName) values (?, ?)`;
    const queryUserNormalAddDuringRegistInsertion_2Q_2 = `insert into account_ (AccCreDate, CusId) values (NOW(),?);`;
    const queryUserNormalAddDuringRegistInsertion_3Q_3 = `insert into login (Usr, Pwd, Id) values (?, ?, ?);`;

    sql_connection.query(queryUserinfoDuringRegistSelectionQ, [userID], (error, results, fields) => {
        if (error) throw error;

        if (results.length > 0) {
            console.log("이미 존재하는 아이디로 회원가입시도.");
            res.render("signupPage", { signupResult: 'fail' });
        }
        else {
            /* ADD A NEW USER UPDATE TO THE CUSTOMER TABLE */
            sql_connection.beginTransaction((err) => {
                if (err) throw err;



                sql_connection.query(queryUserNormalAddDuringRegistInsertion_1Q_1, [userLastName, userFirstName], (error, results, fields) => {
                    if (error) {
                        return sql_connection.rollback(() => {
                            throw error;
                        });
                    }

                    const newCusId = results.insertId;

                    sql_connection.query(queryUserNormalAddDuringRegistInsertion_2Q_2, [newCusId], (error, results, fields) => {
                        if (error) {
                            return sql_connection.rollback(() => {
                                throw error;
                            });
                        }

                        sql_connection.query(queryUserNormalAddDuringRegistInsertion_3Q_3, [userID, userPassword, newCusId], (error, results, fields) => {
                            if (error) {
                                return sql_connection.rollback(() => {
                                    throw error;
                                });
                            }

                            sql_connection.commit((err) => {
                                if (err) {
                                    return sql_connection.rollback(() => {
                                        throw err;
                                    });
                                }
                                // sc
                                console.log("serverlog: under test: 회원가입 완료");
                                //console.log("target: 6");
                                //res.send("회원가입 완료");

                                // redirection
                                res.redirect("/login");

                            });

                        });




                    });





                });
            });
        }
    });
});

/* End */


/* fund(mypage) and deposit cash routing defined */

app.get('/getFunds',
    isAuthenticated, (req, res) => { /* getFunds -> GET 방식만 처리. POST 방식으로 들어오는 요청에 대해서 처리하지 않음 */

        // 세션에서 CusID 가져옴 
        var id = req.session.CusId;  // req.session.CusId

        if (!id || typeof id === 'undefined') {
            console.log('req.session.CusId : ', id);
            console.log('req.session.CusId : ', req.session.CusId);
            console.log('redirect to /login..');
            return res.redirect('/login');
        }

        sql_connection.query(`SELECT MarginAvailable AS CustomerFund FROM account_ WHERE CusId = ?`, [id], (err, results) => {
            if (err) throw err;

            if (results.length > 0) {

                var page = ejs.render(fundPage, { data: results });
                return res.send(page);

            } else {
                console.log('/getFunds (path): Server Detected: results. length 0 on marginbalance request..');
                res.sendStatus(500);
            }


        });

    });

app.post('/cashAdd', isAuthenticated, (req, res) => {
    var id = req.session.CusId;
    const { cash_a } = req.body;
    const queryUpdateMoneyAddQ = `update account_ set MarginAvailable = MarginAvailable + ? where AccNum = ?`;

    if (!id || typeof id === 'undefined') {
        return res.redirect('/login');
    }
    if (typeof cash_a === 'undefined') {
        return res.redirect('/getFunds');
    }

    sql_connection.query(queryUpdateMoneyAddQ, [cash_a, id], (err, results) => {
        if (err) throw err;

        sql_connection.query(`SELECT MarginAvailable AS CustomerFund FROM account_ WHERE CusId = ?`, [id], (err, results) => {
            if (err) throw err;

            if (results.length > 0) {

                var page = ejs.render(fundPage, { data: results });
                return res.send(page);

            } else {
                console.log('/getFunds (path): Server Detected: results. length 0 on marginbalance request..');
                res.sendStatus(500);
            }


        });
    });
});

app.post('/cashSub', isAuthenticated, (req, res) => {
    var id = req.session.CusId;
    const { cash_s } = req.body;
    const queryUpdateMoneySubQ = `update account_ set MarginAvailable = MarginAvailable - ? where AccNum = ?`;

    if (!id || typeof id === 'undefined') {
        return res.redirect('/login');
    }
    if (typeof cash_s === 'undefined') {
        return res.redirect('/getFunds');
    }

    sql_connection.query(queryUpdateMoneySubQ, [cash_s, id], (err, results) => {
        if (err) throw err;

        sql_connection.query(`SELECT MarginAvailable AS CustomerFund FROM account_ WHERE CusId = ?`, [id], (err, results) => {
            if (err) throw err;

            if (results.length > 0) {

                var page = ejs.render(fundPage, { data: results });
                return res.send(page);

            } else {
                console.log('/getFunds (path): Server Detected: results. length 0 on marginbalance request..');
                res.sendStatus(500);
            }


        });
    });
});

/* End */





/* temporary admin dev routing defined */

app.get("/", (req, res) => {
    res.render("app")
});
app.get("/adminSuperDashboard", async (req, res) => {
    fs.readFile('./queries.sql', 'utf-8', (err, data) => {
        if (err) {
            console.error('Error reading SQL file:', err);
            return res.status(500).send('Internal Server Error');
        }

        const queries = data.split(';').map(query => query.trim()).filter(query => query.length > 0);

        executeQueries(queries, (err, results) => {
            if (err) {
                console.error('Error in /adminSuperDashboard:', err);
                return res.status(500).send('Internal Server Error');
            }

            const concat = [];
            var n = 8;
            while (n > 0) {
                concat.push(results[results.length - n]);
                n = n - 1;
            }
            var page = ejs.render(adminSuperDashboardPage, {
                data: concat,
            });
            res.send(page);
        });
    });

});
app.get("/connectcheck_" + targetTable[i], (req, res) => {
    sql_connection.query("SELECT * FROM " + targetTable[i] + ";", (err, result) => {
        if (err) throw err;
        else {
            var page = ejs.render(connectTestPage, {
                data: result,
            });
            res.send(page);

            i = i + 1;
            if (i == targetTable.length) i = 0;
        }
    });
});  // remove soon
app.post('/log', (req, res) => {
    console.log('[Client log] ', req.body.message);
    res.sendStatus(200);
});  // debug purpose, also remove soon
//



//






/* version one, two NOT being used currently.. */
/*

    var versionOne_ALPHA_FULL = 
    WITH Previous_Close_ AS(SELECT stocksymbol, stockpricehistory.shar
    eprice AS previous_close_price FROM stockpricehistory WHERE timestamp_ = (SELECT MAX(timestamp_) F
    ROM stockpricehistory WHERE stocksymbol = ?) and stocksymbol = ?) SELECT Stock.stockname, Stock
        .stocksymbol, Stock.shareprice AS current_price, Pre
    vious_Close_.previous_close_price, ROUND((Stock.shareprice - Previous_Close_.previo

    us_close_price), 2) AS change_price, ROUND((((Stock.shareprice - Previous_Close_.previ
    ous_close_price) / Previous_Close_.previous_close_price  ) * 100), 2) AS change_percent FROM Stock JOIN Previous_Close_ ON Stock.stocksymbol = Previous_Close_.stocksymbol;
    var versionTwo_BETA_SIMPLE =
    WITH Previous_Close_ AS(SELECT stocksy
    mbol, stockpricehistory.shareprice AS previous_close_price FROM stockpricehisto
    ry WHERE timestamp_ =
    (SELECT MAX(timestamp_) FROM stockpricehistory WHERE stocksymbol = ?) and stocksymbol
        = ?) SELECT Stock.stockname, Stock.stocksymbol, Stock.shareprice AS current_price, ROUND((((Stock.shareprice - Previous_Close_.previous_close_price) /
        Previous_Close_.previous_close_price) * 100), 2) AS change_percent FROM Stock JOIN Previous_Close_ ON Stock.stocksymbol = Previous_Close_.stocksymbol;
*/

/* var versionThr_GAMMA_BEST = `WITH Previous_Close_ AS (
    SELECT 
    stocksymbol,
    MAX(timestamp_) AS latest_timestamp
FROM 
    stockpricehistory
GROUP BY 
    stocksymbol
),
something AS (
select
Previous_Close_.stocksymbol,
stockpricehistory.shareprice AS previous_close_price    
from stockpricehistory
join Previous_Close_ on Previous_Close_.stocksymbol = stockpricehistory.stocksymbol
where stockpricehistory.timestamp_ = Previous_Close_.latest_timestamp
)
SELECT 
Stock.stockname, 
Stock.stocksymbol, 
Stock.shareprice AS current_price, 
ROUND(
(
  (
    (
      Stock.shareprice - something.previous_close_price
    ) / something.previous_close_price
  ) * 100
), 
2
) AS change_percent 
FROM 
Stock 
JOIN something ON Stock.stocksymbol = something.stocksymbol`;*/







//



// Get the latest transaction price for a stock
const getLatestTransactionPrice = (stockSymbol, callback) => {
    const query = 'SELECT pricepershare FROM transact JOIN order_ ON order_.OrderId = transact.OrderId WHERE StockSymbol = ? ORDER BY transact.timestamp_ DESC LIMIT 1';
    sql_connection.query(query, [stockSymbol], (err, results) => {

        if (err) throw err;

        callback(results.length > 0 ? results[0].pricepershare : null);
    });
};

// Fetch all stock symbols from the database
const getAllStockSymbols = (callback) => {

    const query = 'SELECT StockSymbol FROM stock';
    sql_connection.query(query, (err, results) => {

        if (err) throw err;

        callback(results.map(row => row.StockSymbol));
        // console.log('callback results.map iteration statment sequentially done.');
    });
};

// Save closing price to stockpricehistory
const saveClosingPrice = (stockSymbol) => {
    getLatestTransactionPrice(stockSymbol, (latestPrice) => {
        if (latestPrice !== null) {

            const query = 'INSERT INTO stockpricehistory (StockSymbol, SharePrice, Timestamp_) VALUES (?, ?, ?)';
            sql_connection.query(query, [stockSymbol, latestPrice, new Date()], (err) => {
                if (err) throw err;
                // console.log(`Inserted closing price for ${stockSymbol}: ${latestPrice}`);
            });
        } else {

            // console.log(`No transactions found for ${stockSymbol}`);

            const query_exception_dealing_query = 'INSERT INTO stockpricehistory (StockSymbol, SharePrice, Timestamp_) VALUES (?, (SELECT SharePrice FROM stock WHERE StockSymbol = ?), ?)';
            sql_connection.query(query_exception_dealing_query, [stockSymbol, stockSymbol, new Date()], (err) => {
                if (err) throw err;
                // console.log(`[But Exceptionally dealt] Inserted closing price for ${stockSymbol}: `);
            });
        }
    });
};

// Check if the market is closed
cron.schedule('* * * * *', () => {
    const now = new Date();
    const currentHour = now.getHours(); // 1 ~ 23 으로 테스트하기 (현재 아래코드 보면, -1 넣어뒀음) 18시로 테스트하고 싶으면 === 18
    const currentMinute = now.getMinutes();

    // Check if market closes automatically 1분마다 
    if (currentHour === -1 && [7, 8, 9].includes(currentMinute)) { // <- hard coded yet just for my convenience  // later it should be modified
        //console.log('Market closed. Fetching closing prices...');
        //console.log(currentHour) console.log(currentMinute)
        console.log(currentMinute)

        getAllStockSymbols((symbols) => {

            for (let i = 0; i < symbols.length; i++) {

                saveClosingPrice(symbols[i]);
            }
        });
    }
});




//
app.listen(3001, () => {
    console.log("서버 실행 중");
});











// DetailPriceSelection 알고리즘 <- 이건 지우지 말기 일단
/*

const queryDetailPricePercentageSelectionQ = `SELECT 
    stocksymbol,
    stockpricehistory.shareprice AS previous_close_price
FROM 
    stockpricehistory
WHERE 
    timestamp_ = (SELECT MAX(timestamp_) FROM stockpricehistory WHERE stocksymbol = ?)
    and stocksymbol = ?`;

 var page = ejs.render(detailPercentPage, {
                data: results,
            });
            res.send(page);

sql connection query (queryDetailPricePercentageSelectionQ, [ss, ss], () => {} */




