exports.createOrder = (req, res) => {
    const p_Data = req.body;
    for (const key in p_Data) {
        if (p_Data.hasOwnProperty(key)) {
            console.log(`${key}: ${p_Data[key]}`);
        }
    }

    console.log(p_Data);
    console.log('post method');
    console.log('path:   ~/api/orders');
    console.log('c_o__OrdersController_js');
    console.log('routing success!!');
    res.json({ message: 'Greatly Received: additional msg: createOrder Binding (OrdersController_js test).' });
    //res.send('createOrder Binding (OrdersController_js test)');
    console.log('res send() completed.');
};