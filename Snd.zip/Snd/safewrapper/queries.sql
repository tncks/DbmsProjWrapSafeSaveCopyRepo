DROP VIEW IF EXISTS StockRevenue;
DROP VIEW IF EXISTS STOCKTYPEREVENUE;
DROP VIEW IF EXISTS CUSTOMERREVENUE;
DROP VIEW IF EXISTS MostTraded;
DROP VIEW IF EXISTS Suggest;
SELECT * from account_;
SELECT * from order_;
SELECT * from stockpricehistory;
SELECT * from stock;
SELECT * from portfolio;
CREATE VIEW StockRevenue(StockSymbol, StockName, TotalRevenue) AS
SELECT O.StockSymbol, S.StockName, SUM(T.TransFee) AS TotalRevenue 
FROM Order_ O, Transact T, Stock S
WHERE O.Recorded = 1 AND O.OrderId = T.OrderId AND O.StockSymbol = S.StockSymbol
GROUP BY O.StockSymbol;
CREATE VIEW STOCKTYPEREVENUE(StockType, TotalRevenue) AS
SELECT S.StockType, SUM(T.TransFee)
FROM Stock S, Transact T, Order_ O
WHERE O.StockSymbol = S.StockSymbol AND O.Recorded = 1
AND O.OrderID = T.OrderId
GROUP BY S.StockType;
CREATE VIEW CUSTOMERREVENUE(CusAccNum, FirstName, LastName, TotalRevenue) AS
SELECT O.CusAccNum, C.FirstName, C.LastName, SUM(T.TransFee) AS TotalRevenue 
FROM Order_ O, Transact T, Customer C, Account_ A
WHERE O.Recorded = 1 AND O.OrderID = T.OrderId AND O.CusAccNum = A.AccNum AND A.CusId = C.CusId
GROUP BY O.CusAccNum;
CREATE VIEW MostTraded(StockSymbol, StockName, NumOrders) AS
SELECT O.StockSymbol, S.StockName, COUNT(*) AS NumOrders
FROM Order_ O, Stock S
WHERE O.StockSymbol = S.StockSymbol
GROUP BY O.StockSymbol
ORDER BY NumOrders DESC;
CREATE VIEW Suggest(StockSymbol, SharePrice, NumAvailShares, StockType) AS
SELECT S.StockSymbol, S.SharePrice, S.NumAvailShares, S.StockType
FROM Stock S, Order_ O
WHERE(O.CusAccNum = 1 AND O.StockSymbol = S.StockSymbol);
SELECT * FROM account_ a_;
SELECT * FROM transact tr;
SELECT * FROM customer cu;
SELECT * FROM order_ o_;
SELECT * FROM Suggest su;
SELECT * FROM StockRevenue rv;
SELECT * FROM STOCKTYPEREVENUE styrv;
SELECT * FROM MostTraded mt;
