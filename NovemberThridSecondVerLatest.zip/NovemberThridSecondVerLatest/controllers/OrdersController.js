const sql_connection = require('../config/db');
const ejs = require('ejs');
const { getWelcomePage, getLoginPage, getSignupPage, getPlaceStockPage, getOrdersAllLogPage, getTransactionsPage, getFundPage, getHomePage,
    getMaterialWebListOfMine, getPortfolioPage, getBidPage, getOrderCancelPage } = require('../shared');
const { savePairOfPeersPortfolios, setLatestStockSharePrice } = require('./matchingutil');


// POST METHOD












// 주문 매칭 함수 (현재 사용중)
const matchOrders = async (symbol) => {
    //console.log(`matchOrders`);
    const sql_connection__ = sql_connection.promise();  // important!
    let totalMatches = 0;
    let transactionArr = [];

    try {
        await sql_connection__.beginTransaction();

        // 매도 및 매수 주문 가져오기 
        const [allExistingOrders] = await sql_connection__.query(
            `SELECT * FROM order_ WHERE StockSymbol = ? AND Completed = 0 AND StopPrice is not NULL`,
            [symbol]
        );

        const buyOrders = allExistingOrders.filter(o => o.OrderType === 'Buy');
        const sellOrders = allExistingOrders.filter(o => o.OrderType === 'Sell');



        // 매칭 로직
        for (let buyOrder of buyOrders) {
            for (let sellOrder of sellOrders) {
                if (buyOrder.CusAccNum === sellOrder.CusAccNum) // same person match himself ; cannot trade with self
                {
                    continue;
                }
                if (buyOrder.StopPrice === sellOrder.StopPrice) {
                    // 일단 가격이 같은 편이니까 수요공급이 맞아 매칭이 일어나 이 if 블록으로 들어는 왔는데, 그 다음

                    const matchedQuantity = Math.min(buyOrder.NumShares, sellOrder.NumShares);

                    console.log(`Matched: ${matchedQuantity} quantities of ${sellOrder.StockSymbol} at [ ${sellOrder.StopPrice} won ]`);

                    // 트랜잭션 데이터 두번 push (1차적 과정)
                    transactionArr.push({
                        OrderId: parseInt(buyOrder.OrderId),
                        PricePerShare: parseInt(buyOrder.StopPrice),
                    });
                    transactionArr.push({
                        OrderId: parseInt(sellOrder.OrderId),
                        PricePerShare: parseInt(sellOrder.StopPrice),
                    });

                    // 포트폴리오 업데이트
                    await savePairOfPeersPortfolios(buyOrder, sellOrder, symbol, matchedQuantity);

                    // 수량 업데이트
                    buyOrder.NumShares -= matchedQuantity;
                    sellOrder.NumShares -= matchedQuantity;

                    // 데이터베이스 업데이트
                    await sql_connection__.query(
                        `UPDATE order_ SET NumShares = ?, isPartiallyFilled = 1, Completed = ? WHERE OrderId = ?`,
                        [buyOrder.NumShares, buyOrder.NumShares === 0 ? 1 : 0, buyOrder.OrderId]
                    );
                    await sql_connection__.query(
                        `UPDATE order_ SET NumShares = ?, isPartiallyFilled = 1, Completed = ? WHERE OrderId = ?`,
                        [sellOrder.NumShares, sellOrder.NumShares === 0 ? 1 : 0, sellOrder.OrderId]
                    );

                    // 매칭 횟수 증가
                    totalMatches += 1;

                    // << 비즈니스 로직 파트 * 코드 모듈화 가능 >> 
                    // 완전히 100% 서로서로 체결된 경우
                    if (buyOrder.NumShares === 0 && sellOrder.NumShares === 0) {
                        console.log('buyOrder.NumShares is 0 AND sellOrder.NumShares is 0...');

                        // Transact data append
                        if (!Array.isArray(transactionArr) || !transactionArr.length) {
                            console.log('Transaction array is empty');
                        } else {
                            await sql_connection__.query(`INSERT INTO transact (OrderId, PricePerShare) VALUES (?, ?)`, [transactionArr[0].OrderId, transactionArr[0].PricePerShare]);
                            await sql_connection__.query(`INSERT INTO transact (OrderId, PricePerShare) VALUES (?, ?)`, [transactionArr[1].OrderId, transactionArr[1].PricePerShare]);

                            console.log('Transaction record insertion done.');
                            transactionArr = [];   // clear code  (flush array)
                        }

                        await setLatestStockSharePrice(symbol);
                        await sql_connection__.query(`UPDATE order_book SET AskQuantity = 0 WHERE StockSymbol = ? AND BidPrice is NULL AND AskQuantity != 0`, [symbol]);
                        await sql_connection__.query(`UPDATE order_book SET BidQuantity = 0 WHERE StockSymbol = ? AND AskPrice is NULL AND BidQuantity != 0`, [symbol]);


                        // 아래 두 줄의 코드를 트리거로 할지..
                        await sql_connection__.query(`DELETE FROM order_book WHERE StockSymbol = ? AND BidPrice is NULL AND AskQuantity = 0`, [symbol]);
                        await sql_connection__.query(`DELETE FROM order_book WHERE StockSymbol = ? AND AskPrice is NULL AND BidQuantity = 0`, [symbol]);

                        break;
                    } // else if else  조건 더 추가하기 한쪽만 fill 인 경우 // 로직 세분화 필요 // 주의: sql_connect 언더바 두개필수
                } else {
                    break; // 더 이상 매칭이 불가능한 경우
                }
            }
        }




        // MYSQL 수정사항 커밋
        await sql_connection__.commit();
    } catch (error) {
        console.error(`Err:`, error);
        await sql_connection__.rollback();  // 에러시 수정사항 롤백
    }

    return totalMatches; // 매칭된 총 주문 수 반환
}



// Insert into order_book table
const insertIntoOrderBook = async (symbol, StopPrice, NumShares, OrderType) => {
    await sql_connection.promise().execute(
        `INSERT INTO order_book (StockSymbol, 
        BidPrice, BidQuantity,
        AskPrice, AskQuantity) VALUES (?, ?, ?, ?, ?)`,
        [symbol,
            OrderType === 'Buy' ? parseInt(StopPrice) : null, OrderType === 'Buy' ? parseInt(NumShares) : null,
            OrderType === 'Sell' ? parseInt(StopPrice) : null, OrderType === 'Sell' ? parseInt(NumShares) : null
        ]
    );


}


// 새로운 주문 요청 처리 API
exports.myOrders = async (req, res) => {
    //console.log(`myOrders`);
    const { StockSymbol, StopPrice, NumShares, OrderType } = req.body;
    console.log(`${StockSymbol}, ${StopPrice}, ${NumShares}, ${OrderType}`); // StopPrice is null 이라면 -> 시장가 처리 -> 해야 하나? - 고민 후 나중에 구현..


    // 입력값 유효성 검사
    if (!StockSymbol || !NumShares || !OrderType) {
        return res.status(400).json({ error: 'Missing required fields' });
        // StockSymbol 입력값없음 -> reject   NumShare 입력값없음 -> reject   OrderType 입력값없음 -> reject 
    }

    if (StockSymbol) {
        const [result] = await sql_connection.promise().query(`SELECT StockSymbol FROM stock WHERE StockSymbol = ?`, [StockSymbol]);
        if (result == null || result.length === 0) {
            return res.status(400).json({ error: 'Cannot find stock name of that. Invalid request' });
        }
    }

    if (NumShares <= 0) {
        return res.status(400).json({ error: 'Invalid num request' });
    }

    if (OrderType == "Sell") {

        const [result] = await sql_connection.promise().query(`SELECT NumShares, SellingShares FROM portfolio WHERE StockSymbol = ? AND AccNum = ?`, [StockSymbol, req.session.CusId]);

        if (result && (NumShares > (result[0].NumShares - result[0].SellingShares))) {
            res.status(400).json({ error: '해당 수량으로 sell 주문을 넣었기에 거래가능수량을 초과함.' });
        }
    }

    if (StopPrice && StopPrice <= 0) {
        return res.status(400).json({ error: 'Invalid val request' });
    }

    if (!(OrderType == "Sell" || OrderType == "Buy")) {
        return res.status(400).json({ error: 'Sell Buy type is unknown fields' });
    }

    if (OrderType == "Sell") {
        if (NumShares <= 0) {
            return res.status(400).json({ error: 'Unknown values' });
        }

        const [validatingNumRes] = await sql_connection.promise().query(`SELECT NumShares FROM portfolio WHERE AccNum = ? AND StockSymbol = ?`, [req.session.CusId, StockSymbol]);
        let comp;
        if (validatingNumRes && validatingNumRes.length > 0) {
            comp = validatingNumRes[0].NumShares;
        } else {
            console.log('weird case..');
        }
        if (!(NumShares >= 1 && (NumShares - comp) <= 0)) {
            return res.status(400).json({ error: 'Invalid NumShares the number of selling share can not exceed your ownings shares num' });
        }

    }

    if (isNaN(NumShares)) {
        return res.status(400).json({ error: 'Quantity must be numbers' });
    }

    // 끝. 입력값 유효성 검사 통과
    console.log(`Passed valid.. , Next func call is..`);

    try {
        const marketStopLimitWhichIs = (typeof StopPrice !== 'undefined' && parseInt(StopPrice) > 0) ? 'Limit_Stop' : 'Market';
        // check 
        // 1. enough buy money?
        const [currentMoney] = await sql_connection.promise().query(`SELECT MarginAvailable FROM account_ WHERE CusId = ?`, [req.session.CusId]);
        if (currentMoney.length > 0 && (OrderType === 'Buy') && (currentMoney[0].MarginAvailable - StopPrice * NumShares < 0)) {
            console.log(`return res.status(400).json({ error: 'Not enough cash balance.' })`);
            return res.status(400).json({ error: 'Not enough cash balance.' });
        }

        // after checking, normal status, then 
        // subtract buyer's cash by total calculated stockprice
        // update seller's portfolio, sellingshares number
        if (OrderType === 'Buy') await sql_connection.promise().query(`UPDATE account_ SET MarginAvailable = (MarginAvailable - ?) WHERE CusId = ?`, [parseInt((StopPrice * NumShares)), req.session.CusId]);
        if (OrderType === 'Sell') await sql_connection.promise().query(`UPDATE portfolio SET SellingShares = (SellingShares + ?) WHERE AccNum = ? AND StockSymbol = ?`, [NumShares, req.session.CusId, StockSymbol]);


        const [result] = await sql_connection.promise().execute(
            `INSERT INTO order_ (StockSymbol, StopPrice, NumShares, OrderType , isPartiallyFilled, Completed, CusAccNum, PriceType, OriginalNumShares) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [StockSymbol, StopPrice, NumShares, OrderType, 0, 0, req.session.CusId, marketStopLimitWhichIs, NumShares]
        );

        const matchesMade = await matchOrders(StockSymbol); // 주문 추가 후 매칭 호출

        if (matchesMade > 0) {
            console.log(`Matched ${matchesMade} orders for symbol ${StockSymbol}`);
            res.status(201).json({ id: result.insertId });
        } else {
            // nothing..
            // orderbook 에 무작정 넣는게 과연 맞을까? 맞는것같음 클라이언트 단에서 출력시 상위 5,5 개만 뽑아서 보여주면됨
            // 5단계 호가 범위에 들어오는 것만 넣어야 할듯 <- 다시 생각해보니 아님.
            // 조건 체크 및 비교하여 현재시간기준 5단계 호가 범위 벗어난 것은
            // orderbook 에 넣지 않도록 로직 수정 필요함 <- 아닌듯.
            // Fetch the updated order book after placing the order
            //const orderBook = await getOrderBook(StockSymbol);
            // Insert the best bids and asks into order_book
            await insertIntoOrderBook(StockSymbol, StopPrice, NumShares, OrderType);

            res.status(201).json({ id: result.insertId });
        }




    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Failed to add order' });
    }
};



// 펜딩, 접수상태인 주문 목록 조회 API
exports.myPending = async (req, res) => {

    try {
        const [orders_] = await sql_connection.promise().query(`SELECT * FROM order_ WHERE CusAccNum = ? AND isPartiallyFilled = 0 AND Completed = 0 ORDER BY StockSymbol ASC`, [req.session.CusId]);

        if (orders_ && orders_.length > 0) {
            const orders = orders_;

            // 결과를 JSON 형태로 반환
            res.status(200).json({ orders });


        } else {
            res.status(200).json({ orders: orders_, error: 'Failed to fetch orders' });
        }



    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Failed to fetch orders' });
    }
};


// 취소 API
exports.myOrderCancel = async (req, res) => {

    // First:  유효성 검사 코드.. 구현 여기..
    // if() {

    // }



    //      1. 유효성 검사? yes -> pass  / no  -> reject
    // done:1-1. 정보 추출 <- 변수에 모두 임시 저장
    // done:2. 매도주문 취소? yes ->
    // done:then
    // done:포트폴리오 sellingshares 업데이트

    // done:  매수주문 취소? yes ->
    // done:then
    // done:계좌 marginbalnance 업데이트

    // done:한단계 마지막 직전 -> order_book 에서 행 삭제 
    // done:finally -> order_ talbe 에서 행 삭제 하고 모듈 블록 끝 도달
    // done:취소 성공 / 취소 실패  둘중 하나의 결과를 다시 클라이언트 단에 res 로 보내기 


    // 정보 추출
    const [extractedPreResult] = await sql_connection.promise().query(`SELECT Timestamp_, OrderType, PriceType, NumShares, StopPrice, StockSymbol from order_ WHERE OrderId = ?`, [req.body.OrderId]);
    const timeData = extractedPreResult[0].Timestamp_;
    const myOrderType = extractedPreResult[0].OrderType;
    const myPriceType = extractedPreResult[0].PriceType; //
    const myNumShares = extractedPreResult[0].NumShares;
    const myStopPrice = extractedPreResult[0].StopPrice;
    const myStockSymbol = extractedPreResult[0].StockSymbol;


    // check logic 필요 odbook_delResult affectNum 이랑 결과 fail vs success 등 처리 필

    if (extractedPreResult && extractedPreResult.length > 0) {

        try {

            if (myOrderType == "Sell") {
                // do following action      
                const [updatePortfolioResult] = await sql_connection.promise().query(`UPDATE portfolio SET SellingShares = (SellingShares - ?) WHERE AccNum = ? AND StockSymbol = ?`, [myNumShares, req.session.CusId, myStockSymbol]);  // 포트폴리오 sellingshares 업데이트
            }
            else {
                // "Buy"
                const calculation = parseInt(myNumShares) * parseInt(myStopPrice);
                // do following action
                const [updateAccountResult] = await sql_connection.promise().query(`UPDATE account_ SET MarginAvailable = (MarginAvailable + ?) WHERE CusId = ?`, [calculation, req.session.CusId]);  // 계좌 marginbalnance 업데이트
            }


        } catch (err) {
            console.log(err);
            res.status(400).json({ error: "fail, abnormal case" });
        }

    } else {
        console.error(`abnormal case.. orderscontroller.js`);
    }





    try {
        // 1
        const odbookResult = await sql_connection.promise().query(`DELETE from order_book WHERE Timestamp_ = ?`, [timeData]); // orderbook 변동

        // 2
        const mainResult = await sql_connection.promise().query(`DELETE FROM order_ WHERE OrderId = ?`, [req.body.OrderId]); // order_ 테이블에서, 취소된 주문 행을 DELETE

        // optional) 조건 추가 ->  만약  mainResult affectedNum  이 1 이 아니라면 -> 문제.   1이면 ->  성공 
        res.status(200).json({ cancelResult: "success" });

    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Failed' });
    }
};



/******************************************************** */
// 히스토리, 주문 목록 조회(체결 미체결 스플릿) API
exports.myOrdersBySymbol = async (req, res) => {
    const { symbol } = req.params;
    try {
        const [orders] = await sql_connection.promise().query(`SELECT * FROM order_ WHERE StockSymbol = ? AND CusAccNum = ? ORDER BY Timestamp_ DESC`, [symbol, req.session.CusId]);

        // 미체결주문과 체결주문으로 분리
        const openOrders = orders.filter(order => order.Completed === 0);
        const completedOrders = orders.filter(order => order.Completed === 1);

        // 결과를 JSON 형태로 반환
        res.json({ openOrders, completedOrders });

    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Failed to fetch orders' });
    }
};
// 체결 미체결 페이지 렌더링
exports.myMaterialWebListOfMineBySymbol = async (req, res) => {
    try {
        const { symbol } = req.params;
        let page = ejs.render(getMaterialWebListOfMine(), { symbol });
        res.send(page);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Failed to fetch symbols' });
    }
};
/******************************************************** */







/******************************************************** */
// (호가 데이터 로드 함수) Limit 5 Bid and Ask
const myGetOrderBook = async (symbol) => {

    const queryTopBidSelectionQ = `
        WITH bid_side AS (SELECT BidPrice, BidQuantity FROM order_book WHERE StockSymbol = ? AND BidPrice is NOT NULL)
        SELECT BidPrice AS StopPrice, SUM(BidQuantity) AS total_quantity
        FROM bid_side
        GROUP BY BidPrice
        ORDER BY BidPrice DESC
        LIMIT 5;
        `;
    const queryTopAskSelectionQ = `
        WITH ask_side AS (SELECT AskPrice, AskQuantity FROM order_book WHERE StockSymbol = ? AND AskPrice is NOT NULL)
        SELECT AskPrice AS StopPrice, SUM(AskQuantity) AS total_quantity
        FROM ask_side
        GROUP BY AskPrice
        ORDER BY AskPrice ASC
        LIMIT 5;
        `;

    const [buyOrders] = await sql_connection.promise().query(
        queryTopBidSelectionQ,
        [symbol]
    );

    const [sellOrders] = await sql_connection.promise().query(
        queryTopAskSelectionQ,
        [symbol]
    );


    const mybids = buyOrders.map(order => ({ StopPrice: order.StopPrice, NumShares: order.total_quantity }));
    const myasks = sellOrders.map(order => ({ StopPrice: order.StopPrice, NumShares: order.total_quantity }));

    if ((buyOrders.length === 0) && (sellOrders.length === 0)) {
        return null;
    } else if ((buyOrders.length !== 0) && (sellOrders.length === 0)) {
        return {
            bids: mybids.reverse(),
            asks: []
        };
    } else if ((buyOrders.length === 0) && (sellOrders.length !== 0)) {
        return {
            bids: [],
            asks: myasks
        };
    } else { // case - normal status 
        return {
            bids: mybids.reverse(),
            asks: myasks
        };
    }


};
// 호가 페이지 렌더링
exports.myBidBySymbol = async (req, res) => {
    const { symbol } = req.params;
    const orderBook = await myGetOrderBook(symbol);

    let page = ejs.render(getBidPage(), { symbol, orderBook });
    res.send(page);
};
/******************************************************** */




// 주문 작성 폼 페이지 렌더링
exports.myPlaceStockBySymbol = (req, res) => {
    //placeStockPage
    const { symbol } = req.params;

    let page = ejs.render(getPlaceStockPage(), {
        qdata: req.query.stocksymbol || '',
        symbol: symbol || ''
    });
    res.send(page);
};





// 사용자 모든 주문내용 뷰 페이지 렌더링
exports.myOrdersAllLog = async (req, res) => {
    const my_custom_selall_query = `SELECT * from order_ WHERE CusAccNum = ? ORDER BY Timestamp_ DESC`;
    const t_query = `SELECT stock.StockName, order_.StockSymbol as Symbol, transact.Timestamp_ as TradedTimeAt, transact.PricePerShare as Price, order_.OrderType as TradePosition FROM transact JOIN order_ ON transact.OrderId = order_.OrderId INNER JOIN stock ON order_.StockSymbol = stock.StockSymbol WHERE order_.CusAccNum = ? ORDER BY transact.Timestamp_ DESC`;
    try {

        const [results] = await sql_connection.promise().query(my_custom_selall_query, [req.session.CusId]);

        const orders = results;

        let [ts] = await sql_connection.promise().query(t_query, [req.session.CusId]);

        if (ts && ts.length > 0) {
            let page = ejs.render(getOrdersAllLogPage(), {
                orders: orders,
                data: ts
            });
            res.send(page);
        } else {
            let page = ejs.render(getOrdersAllLogPage(), {
                orders: orders
            });
            res.send(page);
        }






    } catch (err) {
        res.status(500).json({ message: err.message });
    }










};





// 사용자 종목별 거래 내역 페이지 렌더링
exports.myTransactionsBySymbol = async (req, res) => {
    const my_custom_selall_query = `SELECT stock.StockName, order_.StockSymbol as Symbol, transact.Timestamp_ as TradedTimeAt, transact.PricePerShare as Price, order_.OrderType as TradePosition FROM transact JOIN order_ ON transact.OrderId = order_.OrderId INNER JOIN stock ON order_.StockSymbol = stock.StockSymbol WHERE order_.CusAccNum = ? AND order_.StockSymbol = ? ORDER BY transact.Timestamp_ DESC`;
    try {

        const [results] = await sql_connection.promise().query(my_custom_selall_query, [req.session.CusId, req.query.stocksymbol]);

        if (results && results.length > 0) {

            let page = ejs.render(getTransactionsPage(), {
                data: results
            });
            res.send(page);

        } else {
            let page = ejs.render(getTransactionsPage(), {

            });
            res.send(page);
        }







    } catch (err) {
        res.status(500).json({ message: err.message });
    }

};



























/******************************************************** */
/******************************************************** */
/*exports.myOrderSeeSpecificById = (req, res) => {
    res.status(200).json(res.order);
};*/
/*exports.getOrder = (req, res, next) => {
    let order;
    try {
        const my_custom_select_query = `SELECT * from order_ where OrderId = ?`;

        sql_connection.query(my_custom_select_query, [req.params.id], (err, results) => {
            if (err) throw err;

            if (results.length > 0) {
                order = results[0];
                res.order = order;
                next();
            } else {
                // order is null (result is null)
                return res.status(404).json({ message: 'Order does not exist. ' });
            }
        })


    } catch (err) {
        return res.status(500).json({ message: err.message })
    }

};*/
/*exports.myTossOrder = async (req, res) => {
    await queryAndMatchPairs(req, res, true); // true <-> isNewOrder (set false for update patch or delete)
    res.status(200).redirect('/ordersalllog');
};*/










/*{
    
const saveTransactionArr = async (transactionArr) => {

    if (!Array.isArray(transactionArr) || !transactionArr.length) {
        console.log('Transaction array is empty');
        return;
    }

    const my_custom_query = `INSERT INTO transact (OrderId, PricePerShare) VALUES (?, ?)`;

    let i = 0;

    try {
        while (i < transactionArr.length) {
            await sql_connection.promise().query(my_custom_query, [transactionArr[i].OrderId, transactionArr[i].PricePerShare]);
            i = i + 1;
        }
    } catch (err) {
        console.log('Error during saveTransactionArr:', err);
    }
};
const updateFilledOrderArr = async (filledOrderArr) => {
    if (!Array.isArray(filledOrderArr) || !filledOrderArr.length) {
        console.log('Filled order array is empty');
        return;
    }

    try {
        const my_custom_query = `UPDATE order_ SET NumShares = 0, Completed = 1 WHERE OrderId IN (${filledOrderArr.map(() => '?').join(', ')})`;
        const values = filledOrderArr;
        await sql_connection.promise().execute(my_custom_query, values);
    } catch (err) {
        console.log('Error during updateFilledOrderArr:', err);
    }
};
const queryAndMatchPairs = async (req, res, isNewOrder) => {

    let transactionArr = [];
    let filledOrderArr = [];
    let topPairResult;
    const { NumShares } = req.body;


    if (isNewOrder && req.body.NumShares <= 0) {
        return res.status(400).json({ message: 'Invalid order input' });
    }

    const searchForPair = async () => {
        const filterQuery = `
        SELECT * FROM order_
        WHERE StockSymbol = ?
        AND OrderType = ?
        AND StopPrice ${req.body.OrderType === 'Buy' ? '<=' : '>='} ?
        AND NumShares > 0
        AND Completed = 0
        ORDER BY StopPrice ${req.body.OrderType === 'Buy' ? 'ASC' : 'DESC'}, Timestamp_ ASC
        LIMIT 1
        `;

        const updateQuery = `
        UPDATE order_
        SET NumShares = NumShares - ?, isPartiallyFilled = 1
        WHERE OrderId = ?
        `;


        try {
            const [rows] = await sql_connection.promise().query(filterQuery, [req.body.StockSymbol, (req.body.OrderType === 'Buy') ? 'Sell' : 'Buy', parseInt(req.body.StopPrice)]);

            if (rows.length === 0) {
                return null;
            }

            let resulted_order = rows[0];

            await sql_connection.promise().query(updateQuery, [resulted_order.NumShares, resulted_order.OrderId]);
            const [mresults] = await sql_connection.promise().query(`select * from order_ where OrderId = ?`, [resulted_order.OrderId]);
            if (mresults.length > 0) {
                resulted_order = mresults[0];
            }

            return resulted_order;


        } catch (err) {
            console.log(err);
            return null;
        }
    }


    let RemainingNumShares = NumShares;
    while (RemainingNumShares > 0) {
        topPairResult = await searchForPair();

        // No matching trading pair is found
        if (!topPairResult) {
            try {
                //  myTmpBool 필요함 나중을 위해서 (코드 지우면 안될듯)
                let myTmpBool;
                if (RemainingNumShares > 0 && NumShares !== RemainingNumShares) {
                    myTmpBool = 1;
                }
                if (isNewOrder) {
                    // insert into query statement (save)
                    if (typeof myTmpBool === 'undefined') {
                        // myTmpBool 이 1이 아닌 경우(type of undefined 와 같음)
                        const my_f_query = `insert into order_ (CusAccNum,StockSymbol,OrderType,OriginalNumShares,NumShares,StopPrice,Completed,isPartiallyFilled, PriceType) values (?,?,?,?,?,?,0,0,'Limit_Stop')`;
                        await sql_connection.promise().query(my_f_query, [req.session.CusId, req.body.StockSymbol, req.body.OrderType, req.body.NumShares, req.body.NumShares, parseInt(req.body.StopPrice)]);

                    } else {
                        // myTmpBool == 1 인 경우
                        const my_f_query = `insert into order_ (CusAccNum,StockSymbol,OrderType,OriginalNumShares,NumShares,StopPrice,Completed,isPartiallyFilled, PriceType) values (?,?,?,?,?,?,0,1,'Limit_Stop')`;
                        await sql_connection.promise().query(my_f_query, [req.session.CusId, req.body.StockSymbol, req.body.OrderType, req.body.NumShares, req.body.NumShares, parseInt(req.body.StopPrice)]);
                    }

                }
            } catch (err) {
                console.log(err);
                return res.status(400).json({ message: err.message });
            }
            break;
        } else { // A matching trading pair is found

            const [tmp] = await sql_connection.promise().query(`select OrderId from order_ ORDER BY OrderId desc limit 1`);
            const NextOrderId = parseInt(tmp[0].OrderId) + 1;


            const buy_order_id = req.body.OrderType === 'Buy' ? NextOrderId : topPairResult.OrderId;
            const sell_order_id = req.body.OrderType === 'Sell' ? NextOrderId : topPairResult.OrderId;

            // If one existing order can fill the entire new order
            if (topPairResult.NumShares >= 0) {

                if (buy_order_id) {
                    transactionArr.push({
                        OrderId: parseInt(buy_order_id),

                        PricePerShare: parseInt((parseInt(req.body.StopPrice) + parseInt(topPairResult.StopPrice)) / 2),

                    });
                }
                if (sell_order_id) {
                    transactionArr.push({

                        OrderId: parseInt(sell_order_id),

                        PricePerShare: parseInt((parseInt(req.body.StopPrice) + parseInt(topPairResult.StopPrice)) / 2),

                    });
                }



                RemainingNumShares = 0;

                if (isNewOrder) {
                    // insert into query statement (save)
                    const my_f_query = `insert into order_ (CusAccNum,StockSymbol,OrderType,OriginalNumShares,NumShares,StopPrice,Completed,isPartiallyFilled, PriceType) values (?,?,?,?,0,?,1,1,'Limit_Stop')`;
                    await sql_connection.promise().query(my_f_query, [req.session.CusId, req.body.StockSymbol, req.body.OrderType, req.body.NumShares, parseInt(req.body.StopPrice)]);

                }


                topPairResult.NumShares === 0 && filledOrderArr.push(topPairResult.OrderId);

            } else { // It will take multiple orders
                if (buy_order_id) {
                    transactionArr.push({
                        OrderId: parseInt(buy_order_id),

                        PricePerShare: parseInt((parseInt(req.body.StopPrice) + parseInt(topPairResult.StopPrice)) / 2),

                    });
                }
                if (sell_order_id) {
                    transactionArr.push({

                        OrderId: parseInt(sell_order_id),

                        PricePerShare: parseInt((parseInt(req.body.StopPrice) + parseInt(topPairResult.StopPrice)) / 2),

                    });
                }


                RemainingNumShares = Math.abs(topPairResult.NumShares);

                if (isNewOrder) {
                    // insert into query statement (save)

                    const my_f_query = `insert into order_ (CusAccNum,StockSymbol,OrderType,OriginalNumShares,NumShares,StopPrice,is_filled,isPartiallyFilled, PriceType) values (?,?,?,?,?,?,0,1,'Limit_Stop')`;
                    await sql_connection.promise().query(my_f_query, [req.session.CusId, req.body.StockSymbol, req.body.OrderType, req.body.NumShares, RemainingNumShares, parseInt(req.body.StopPrice)]);
                }


                filledOrderArr.push(topPairResult.OrderId);
            }
        }

    }




    await saveTransactionArr(transactionArr);
    await updateFilledOrderArr(filledOrderArr);
    await setLatestStockSharePrice(req.body.StockSymbol);
    console.log('219');

};  // 레퍼런스이며 -> 전혀 다른 로직




}*/
/*

    
    switch
    case 1( *구 현 done):
     사려는 사람 예수금 체크해서 부족하면 -> reject
    case 1-1( *구 현 done) (ordertype 이 스트링 Sell 또는 Buy 가 아닌경우 -> reject exact match 가 아니면 reject )
    case 2~3(구현 done):   (초기 단계에서부터 reject)  -> 구현(예정): 서버 단에서밖에 처리못함, 이유는 디비에 예수금 정보가 저장되어있기 때문 (클라이언트 구현 x)
    ( *구 현 done) 파려는 사람 보유하고 있던 주식수 체크해서 5를 갖고있는데 1~5가 아닌, 0이 들어오거나, 6,7,8... 이 들어오면 -> reject                                                                 (구현: 서버 및 클라이언트 유효성 검사 모두 구현 o)
     ( *구 현 done)ordertype==="Sell" && req.body.NumShared <= 0 => reject                  -> 구현(예정): 서버 단에서밖에 처리못함 (클라이언트 구현 x)
    case 4(*구현 done):
     사려는 사람 보유하고 있던 주식수 체크해서 1 개 이상을 갖고 있는데 매칭 및 성공 체결완료 이후 -> accept & 그사람 portfolio 업데이트   /  그렇지 않으면(이또한 accept) 기존에 보유하고 있던 해당 종목 주식수가 0개였음(데이터가 조회되지 않았었음)을 의미 -> 한번도 안사봤던 완전 새로산 주식이니까 해당 user portfolio 에 새롭게 insert             (이거는 정상 케이스인데? 적을필요있나?)                                        -> 구현 : 매칭처리하는 함수 코드 내부에서 매칭==true 가 된 block 내부에서 portfolio table select 하고, rows selected 된 결과를 변수에 담고 결과가 length>0 이면 있는거니까 업데이트 (insert가 맞을까 update가 맞을까? 수량만 따지면 update인데 가격이 구매시점마다 다르니까 insert가 맞나 ) (참고로, 서버단만 구현하면 될듯함)
    case 5(*구현 done):
     파려는 사람 삼성을 3주 갖고 있는데 1주 혹은 2주만 팔겠다고 주문이 들어오면 -> accept                                                                                        -> 예수금은 체결전까지 변화없고 체결 이후 예수금 업데이트 필요하고 portfolio 업데이트 필요 (서버단만 구현하면 될듯)
    case 6(*구현 done):
     파려는 사람 삼성을 3주 갖고 있는데 3주 다 팔겠다고 주문이 들어오면 -> accept                                                                                                비고) 전부 all match 및 다 팔리는 매칭 -> 체결 완료 시 -> portfolio 에서 row 삭제 (portfolio 테이블에 해당 user, 해당 stock 에 대해 row가 한개 기존에 존재하는데-> portfolio.numshares ==0 되면 삭제 트리거 작동하도록 리스너 설정 켜두면 자동으로 되게 구현 가능, 조건 굳이 여기서 안따져도 됨. 근데 트리거를 구현안하고 안쓴다면 조건 여기서 따져야함.)
    case 7(*구현 done):
     주식을 0개를 팔겠다 || 주식을 0개를 사겠다 -> reject                                                                                                                    (QUANTITY 기준이고 둘중 하나라도 해당되면 무조건 reject 시켜야 되는 case. 그리고 서버단도 구현하고 클라이언트 단도 유효성 처리 쪽에서 둘다 쉽게 구현하기, 필.)
    case 8(*구현 done):
    주식을 0원에 사겠다 -> reject    (case 7 이랑 아주 살짝 다른데 같이 확인하면서 포함하여 코드 작성!)
    case 9(*구현 done):
    주식을 0원에 팔겠다    reject.     구현: 클라이언트는 입력폼 onchange 시 음수나 0 넣으려 하면 막아주면 될것 같고 / 서버단에서는 accept? then -> 먼저 order_ table 에 새 데이터 insertion 되게 해주고 -> 매칭 잡아주고 -> 매칭일어나면 transact table에 관련 데이터 insertion 되게 해주고 & portfolio table buyer seller 각각 이것저것 되게 처리 
    case 10:
    (*구현 done)StockSymbol -> 이상한거 입력 -> db에 없는 종목명 혹은 심볼 -> reject
    case 11:
    나머지는 다른거 구현하다가 생각나면 더 구현하는걸로.. 
    간단하게 요약하자면 -> 사려고 하는 주문 (ordertype == buy) -> 사려는 사람 예수금만 적절한지 안적절한지 비교해서 따져보고 안적절하면 reject 시키고 적절하면 accept 후에 ordertable 에 넣어주고 매칭 돌려주면 된다
    팔려고 하는 주문 -> 팔겠다는 사람 porfolio 테이블 조회하여 해당 종목에 대해 보유 주식 수가 팔려는 주식 수와 비교하여 적절한지 따져보고 안적절하면 reject 시키면 됨 적절하면 accept 후에 ordertable 에 넣어주고 매칭 돌려주면 된다  
    초기에 체크해야 하는 case 들(reject 시 order_ table 에 insert 조차 안일어나게 해야하는 것들) ->  case 1 2 3 7 8 9 10


*/