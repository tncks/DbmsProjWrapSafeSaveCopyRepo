
-- Make sure share price is positive.
CREATE TRIGGER SharePriceValid
	BEFORE INSERT ON Stock FOR EACH ROW
	SET NEW.SharePrice = IF
		(NEW.SharePrice > 0,
        NEW.SharePrice,
        NULL);

-- Make sure share price is positive.
CREATE TRIGGER SharePriceValid2
	BEFORE UPDATE ON Stock FOR EACH ROW
	SET NEW.SharePrice = IF
		(NEW.SharePrice > 0,
        NEW.SharePrice,
        NULL);

-- Make sure that there is not a negative number of shares available.
CREATE TRIGGER AvailSharesValid
	BEFORE INSERT ON Stock FOR EACH ROW
	SET NEW.NumAvailShares = IF
		(NEW.NumAvailShares > -1,
        NEW.NumAvailShares,
        NULL);

-- Make sure the Order being added is for a valid number of shares.
CREATE TRIGGER NumSharesValid
	BEFORE INSERT ON Order_ FOR EACH ROW
		SET NEW.NumShares = IF
			(NEW.NumShares > 0,
            NEW.NumShares,
            NULL);

-- Change the prices on an inserted Order.
CREATE TRIGGER GetPrices
	BEFORE INSERT ON Order_ FOR EACH ROW
		SET NEW.CurSharePrice = (SELECT S.SharePrice FROM Stock S WHERE S.StockSymbol = NEW.StockSymbol);
		
-- Make sure the order type is in the domain allowed.
CREATE TRIGGER OrderTypes 
	BEFORE INSERT ON Order_ FOR EACH ROW
		SET NEW.OrderType = IF
			(NEW.OrderType IN ('Buy', 'Sell'),
			NEW.OrderType,
            NULL);

-- Make sure that the price type is allowed.
CREATE TRIGGER PriceTypes 
	BEFORE INSERT ON Order_ FOR EACH ROW
		SET NEW.PriceType = IF
			(NEW.PriceType IN ('Market', 'Market on Close', 'Trailing Stop', 'Hidden Stop'),
			NEW.PriceType,
            NULL);

-- Calculates the difference between stop price and current price.
CREATE TRIGGER CalcStopDiff
	BEFORE INSERT ON Order_ FOR EACH ROW
		SET NEW.StopDiff = IF
			(NEW.PriceType IN ('Trailing Stop', 'Hidden Stop'),
            NEW.CurSharePrice - NEW.StopPrice,
            NULL);

delimiter |
-- Set price in Transact table.
CREATE TRIGGER GetPrices2
	BEFORE INSERT ON Transact FOR EACH ROW
    BEGIN 
		SET NEW.PricePerShare = (SELECT S.SharePrice
								 FROM Stock S, Order_ O
								 WHERE S.StockSymbol = O.StockSymbol
										AND O.OrderId = NEW.OrderId);
	END;
|
delimiter ;

delimiter |
-- Executes a transaction for an order.
-- Checks to make sure that the number of shares being
-- bought or sold is correct.
CREATE TRIGGER DoTransact
	BEFORE UPDATE ON Order_ FOR EACH ROW
		
			IF(NEW.OrderType = 'Sell')
				THEN IF(NEW.PriceType = 'Market')
					THEN IF(NEW.NumShares <= 
							(SELECT P.NumShares
							FROM Portfolio P
							WHERE NEW.CusAccNum = P.AccNum
							AND NEW.StockSymbol = P.StockSymbol))
						THEN INSERT INTO Transact(OrderId)
							VALUES(NEW.OrderId);
						SET NEW.Completed = 1;
					END IF;
				END IF;
                IF(NEW.PriceType <> 'Market')
					THEN IF(NEW.NumShares <= 
							(SELECT P.NumShares
							FROM Portfolio P
							WHERE NEW.CusAccNum = P.AccNum
							AND NEW.StockSymbol = P.StockSymbol)
                            AND EXISTS(SELECT *
										FROM ConditionalPriceHistory C
                                        WHERE C.CurSharePrice <= C.StopPrice
                                        AND C.OrderId = NEW.OrderId
                                        AND C.Timestamp_= (SELECT MAX(H.Timestamp_)
															FROM ConditionalPriceHistory H
															WHERE NEW.OrderId = H.OrderId)))
						THEN INSERT INTO Transact(OrderId)
							VALUES(NEW.OrderId);
						SET NEW.Completed = 1;
					END IF;
                END IF;
			END IF;
            IF(NEW.OrderType = 'Buy')
				THEN IF(NEW.NumShares <= 
						(SELECT S.NumAvailShares
						FROM Stock S
						WHERE NEW.StockSymbol = S.StockSymbol))
					THEN INSERT INTO Transact(OrderId)
						VALUES(NEW.OrderId);
					SET NEW.Completed = 1;
				END IF;
			END IF;
        
|
delimiter ;

-- Check that the stop is in the allowed domain.
CREATE TRIGGER Stops 
	BEFORE INSERT ON Portfolio FOR EACH ROW
		SET NEW.Stop_ = IF
			(NEW.Stop_ IN ('Trailing', 'Hidden', 'None'),
			NEW.Stop_,
            NULL);
            
-- Make sure that there is not a negative number of shares.
CREATE TRIGGER NumSharesValid2
	BEFORE INSERT ON Portfolio FOR EACH ROW
	SET NEW.NumShares = IF
		(NEW.NumShares > -1,
        NEW.NumShares,
        NULL);

delimiter |
-- Adds or subtracts shares from the portfolio following an order transaction.
CREATE TRIGGER UpdatePortfolio
	BEFORE INSERT ON Transact FOR EACH ROW
    BEGIN
		UPDATE Portfolio P
		SET P.NumShares = P.NumShares + 
			(SELECT O.NumShares * POW(-1, O.OrderType = 'Sell')
				FROM Order_ O, Account_ A
				WHERE NEW.OrderId = O.OrderId
				AND O.CusAccNum = A.AccNum
				AND O.StockSymbol = P.StockSymbol
                AND P.AccNum = A.AccNum
				LIMIT 1)
		WHERE P.AccNum = 
			(SELECT A.AccNum
            FROM Account_ A, Order_ O
            WHERE NEW.OrderID = O.OrderId
			AND O.CusAccNum = A.AccNum
            AND O.StockSymbol = P.StockSymbol
            LIMIT 1);
	END;
|
delimiter ;

delimiter |
-- Adds a new portfolio entry to account following a transaction.
CREATE TRIGGER AddToAccount
	BEFORE INSERT ON Transact FOR EACH ROW
    BEGIN
		IF(NOT EXISTS(SELECT * FROM Portfolio P, Account_ A, Order_ O
					  WHERE NEW.OrderId = O.OrderId
                      AND O.CusAccNum = A.AccNum
                      AND A.AccNum = P.AccNum
                      AND P.StockSymbol = O.StockSymbol))
		THEN INSERT INTO Portfolio(AccNum, StockSymbol, NumShares, Stop_, StopPrice)
			VALUES((SELECT O.CusAccNum
					   FROM Order_ O
					   WHERE NEW.OrderId = O.OrderId),
					(SELECT O.StockSymbol
						FROM Order_ O
						WHERE NEW.OrderId = O.OrderId),
					(SELECT O.NumShares
						FROM Order_ O
						WHERE NEW.OrderId = O.OrderId),
					'None',
					Null);
		END IF;
	END;
|
delimiter ;

-- Make sure that the price type is allowed.
CREATE TRIGGER PriceTypes2
	BEFORE INSERT ON ConditionalPriceHistory FOR EACH ROW
		SET NEW.PriceType = IF
			(NEW.PriceType IN ('Market', 'Market on Close', 'Trailing Stop', 'Hidden Stop'),
			NEW.PriceType,
            NULL);
            
delimiter |
-- Execute a transact for an order with a stop price.
CREATE TRIGGER SellOrder
	BEFORE INSERT ON ConditionalPriceHistory FOR EACH ROW
    BEGIN
		IF (NEW.CurSharePrice <= NEW.StopPrice 
			AND (SELECT O.NumShares
				 FROM Order_ O
                 WHERE O.OrderId = NEW.OrderId) <= 
                 (SELECT P.NumShares
                  FROM Portfolio P, Order_ O
                  WHERE P.StockSymbol = O.StockSymbol
                  AND O.OrderId = NEW.OrderId
                  AND O.CusAccNum = P.AccNum))
		THEN INSERT INTO Transact (OrderId, PricePerShare)
			VALUES (NEW.OrderId, NEW.CurSharePrice);
		END IF;
	END;
|
delimiter ;

delimiter |
-- Adds an entry to CondPriceHist when an order is placed with a stock.
CREATE TRIGGER InitalAddToConditionalPriceHistoryShare
	AFTER INSERT ON Order_ FOR EACH ROW
	BEGIN
		IF (NEW.PriceType IN ('Trailing Stop', 'Hidden Stop'))
		THEN INSERT INTO ConditionalPriceHistory(OrderId, CurSharePrice, PriceType, StopPrice)
			VALUES(NEW.OrderId, NEW.CurSharePrice, NEW.PriceType, NEW.StopPrice);
        END IF;
	END;
|
delimiter ;

-- Adds an entry to StockPriceHistory when a stock is created.
CREATE TRIGGER InitialAddToStockPriceHistory
	AFTER INSERT ON Stock FOR EACH ROW
		INSERT INTO StockPriceHistory(StockSymbol, SharePrice)
        VALUES(NEW.StockSymbol, NEW.SharePrice);

delimiter |
-- Adds an entry to StockPriceHistory when a stock price changes.
CREATE TRIGGER AddToStockPriceHistory
	AFTER UPDATE ON Stock FOR EACH ROW
    BEGIN
		IF (NEW.SharePrice <> OLD.SharePrice)
			THEN IF(NOT EXISTS(SELECT * FROM StockPriceHistory S
							   WHERE S.StockSymbol = NEW.StockSymbol
                               AND TIMESTAMPDIFF(SECOND, S.Timestamp_,NOW()) <= 2))
				THEN INSERT INTO StockPriceHistory(StockSymbol, SharePrice)
					VALUES(NEW.StockSymbol, NEW.SharePrice);
			END IF;
		END IF;
	END;
|
delimiter ;

delimiter |
-- Updates the number of available shares of a stock
-- after an order is executed.
CREATE TRIGGER UpdateStockQuantity
	BEFORE INSERT ON Transact FOR EACH ROW
    BEGIN
		UPDATE Stock S
		SET S.NumAvailShares = S.NumAvailShares - 
			(SELECT O.NumShares * POW(-1, O.OrderType = 'Sell')
			FROM Order_ O
			WHERE NEW.OrderId = O.OrderId
            LIMIT 1)
		WHERE S.StockSymbol = 
			(SELECT O.StockSymbol
			FROM Order_ O
			WHERE NEW.OrderId = O.OrderId
            LIMIT 1);
	END;
|
delimiter ;

