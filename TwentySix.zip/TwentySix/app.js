
const express = require('express');
const path = require('path');
const app = express();
const orderRoutes = require('./routes/orderRoutes');
const mysql = require('mysql2');
const sql_connection = require('./config/db');
const targetTable = ["account_", "conditionalpricehistory", "customer", "login",
    "order_", "transact", "portfolio", "stock", "stockpricehistory", "order_history"];

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/api', orderRoutes);
app.set("view engine", "ejs");
app.set("views", "./views");
const ejs = require("ejs");
const fs = require('fs');
const cron = require('node-cron');
const welcomePage = fs.readFileSync('./views/welcomePage.ejs', 'utf8');
const fivePreferPricePage = fs.readFileSync('./views/fivePreferPricePage.ejs', 'utf8');
const placeStockPage = fs.readFileSync('./views/placeStockPage.ejs', 'utf8');
const ordersPage = fs.readFileSync('./views/ordersPage.ejs', 'utf8');
const transactionsPage = fs.readFileSync('./views/transactionsPage.ejs', 'utf8');
const homePage = fs.readFileSync('./views/homePage.ejs', 'utf8');
const fundPage = fs.readFileSync('./views/fundPage.ejs', 'utf8');
const loginPage = fs.readFileSync('./views/loginPage.ejs', 'utf8');
const signupPage = fs.readFileSync('./views/signupPage.ejs', 'utf8');
const connectTestPage = fs.readFileSync('./views/connectTestPage.ejs', 'utf8');
const adminSuperDashboardPage = fs.readFileSync('./views/adminSuperDashboardPage.ejs', 'utf8');
const session = require('express-session');
const isAuthenticated = require('./middleware/auth');
app.use(session({
    secret: 'abIASDJWasodhwAHWagQ',
    resave: false,
    saveUninitialized: true,
    cookie: {
        secure: false,
        maxAge: 1000 * 60 * 60  // 1 hour expire setting
    }
}));
var i = 0;
const basicQ = `WITH Previous_Close_ AS (
    SELECT 
        stocksymbol,
        MAX(timestamp_) AS latest_timestamp
    FROM 
        stockpricehistory
    GROUP BY 
        stocksymbol
),
something AS (
    select
    Previous_Close_.stocksymbol,
    stockpricehistory.shareprice AS previous_close_price    
    from stockpricehistory
    join Previous_Close_ on Previous_Close_.stocksymbol = stockpricehistory.stocksymbol
    where stockpricehistory.timestamp_ = Previous_Close_.latest_timestamp
)
SELECT 
  Stock.stockname, 
  Stock.stocksymbol, 
  Stock.shareprice AS current_price, 
  ROUND(
    (
      (
        (
          Stock.shareprice - something.previous_close_price
        ) / something.previous_close_price
      ) * 100
    ), 
    2
  ) AS change_percent 
FROM 
  Stock 
  JOIN something ON Stock.stocksymbol = something.stocksymbol`;
function executeQueries(queries, callback) {
    let results = [];
    let index = 0;
    let len = 1;

    function executeNextQuery() {
        if (index >= queries.length) {
            return callback(null, results); // 모든 쿼리 완료
        }

        sql_connection.query(queries[index], (err, result) => {
            if (err) {
                console.error('Error:', queries[index], err);
                return callback(err);
            }
            const meaning = ["ChangedPriceDataOfSpecificStockDetailInfoTable", "StockRevenue", "ChangedPriceDataOfSpecificStockDetailInfoTable", "MostTraded"]; // 5 6 7 8
            if (queries.length - index < 5 && queries.length - index >= 1) len = meaning.length - (queries.length - index);
            results.push({ table: meaning[len], data: result });
            index++;
            executeNextQuery(); // 다음 쿼리 실행
        });
    }

    executeNextQuery(); // 첫 번째 쿼리 실행
}



const getOrder = (req, res, next) => {
    let order;
    try {
        const my_custom_select_query = `SELECT * from order_ where OrderId = ?`;

        sql_connection.query(my_custom_select_query, [req.params.id], (err, results) => {
            if (err) throw err;

            if (results.length > 0) {
                order = results[0];
                res.order = order;
                next();
            } else {
                // order is null (result is null)
                return res.status(404).json({ message: 'Order does not exist. ' });
            }
        })


    } catch (err) {
        return res.status(500).json({ message: err.message })
    }

};


const saveTransactionArr = async (transactionArr) => {

    if (!Array.isArray(transactionArr) || !transactionArr.length) {
        console.log('Transaction array is empty');
        return;
    }

    const my_custom_query = `INSERT INTO transact (OrderId, PricePerShare) VALUES (?, ?)`;

    let i = 0;

    try {
        while (i < transactionArr.length) {
            await sql_connection.promise().query(my_custom_query, [transactionArr[i].OrderId, transactionArr[i].PricePerShare]);
            i = i + 1;
        }
    } catch (err) {
        console.log('Error during saveTransactionArr:', err);
    }
};

const updateFilledOrderArr = async (filledOrderArr) => {
    if (!Array.isArray(filledOrderArr) || !filledOrderArr.length) {
        console.log('Filled order array is empty');
        return;
    }

    try {
        const my_custom_query = `UPDATE order_ SET NumShares = 0, Completed = 1 WHERE OrderId IN (${filledOrderArr.map(() => '?').join(', ')})`;
        const values = filledOrderArr;
        await sql_connection.promise().execute(my_custom_query, values);
    } catch (err) {
        console.log('Error during updateFilledOrderArr:', err);
    }
};
const queryAndMatchPairs = async (req, res, isNewOrder) => {

    let transactionArr = [];
    let filledOrderArr = [];
    let topPairResult;
    let { OrderId, NumShares } = req.body;
    let OriginalNumShares = NumShares;

    if (isNewOrder && req.body.NumShares <= 0) {
        return res.status(400).json({ message: 'Invalid order input' });
    }

    const searchForPair = async () => {
        const filterQuery = `
        SELECT * FROM order_
        WHERE StockSymbol = ?
        AND OrderType = ?
        AND StopPrice ${req.body.OrderType === 'Buy' ? '<=' : '>='} ?
        AND NumShares > 0
        AND Completed = 0
        ORDER BY StopPrice ${req.body.OrderType === 'Buy' ? 'ASC' : 'DESC'}, Timestamp_ ASC
        LIMIT 1
        `;

        const updateQuery = `
        UPDATE order_
        SET NumShares = NumShares - ?, isPartiallyFilled = 1
        WHERE OrderId = ?
        `;


        try {
            const [rows] = await sql_connection.promise().query(filterQuery, [req.body.StockSymbol, (req.body.OrderType === 'Buy') ? 'Sell' : 'Buy', parseInt(req.body.StopPrice)]);

            if (rows.length === 0) {
                return null;
            }

            let resulted_order = rows[0];

            await sql_connection.promise().query(updateQuery, [resulted_order.NumShares, resulted_order.OrderId]);
            const [mresults] = await sql_connection.promise().query(`select * from order_ where OrderId = ?`, [resulted_order.OrderId]);
            if (mresults.length > 0) {
                resulted_order = mresults[0];
            }

            return resulted_order;


        } catch (err) {
            console.log(err);
            return null;
        }
    }


    let RemainingNumShares = NumShares;
    while (RemainingNumShares > 0) {
        topPairResult = await searchForPair();

        // No matching trading pair is found
        if (!topPairResult) {
            try {
                //  myTmpBool 필요함 나중을 위해서 (코드 지우면 안될듯)
                let myTmpBool;
                if (RemainingNumShares > 0 && NumShares !== RemainingNumShares) {
                    myTmpBool = 1;
                }
                if (isNewOrder) {
                    // insert into query statement (save)
                    if (typeof myTmpBool === 'undefined') {
                        // myTmpBool 이 1이 아닌 경우(type of undefined 와 같음)
                        const my_f_query = `insert into order_ (CusAccNum,StockSymbol,OrderType,OriginalNumShares,NumShares,StopPrice,Completed,isPartiallyFilled, PriceType) values (?,?,?,?,?,?,0,0,'Limit_Stop')`;
                        await sql_connection.promise().query(my_f_query, [req.body.CusAccNum, req.body.StockSymbol, req.body.OrderType, req.body.NumShares, req.body.NumShares, parseInt(req.body.StopPrice)]);

                    } else {
                        // myTmpBool == 1 인 경우
                        const my_f_query = `insert into order_ (CusAccNum,StockSymbol,OrderType,OriginalNumShares,NumShares,StopPrice,Completed,isPartiallyFilled, PriceType) values (?,?,?,?,?,?,0,1,'Limit_Stop')`;
                        await sql_connection.promise().query(my_f_query, [req.body.CusAccNum, req.body.StockSymbol, req.body.OrderType, req.body.NumShares, req.body.NumShares, parseInt(req.body.StopPrice)]);
                    }

                } else {
                    // update (updateOne)
                    if (typeof myTmpBool === 'undefined') {
                        // myTmpBool 이 1이 아닌 경우(type of undefined 와 같음)
                        const my_c_query = `update order_ set StopPrice = ?, NumShares = ?, OriginalNumShares = ? where OrderId = ?`;
                        sql_connection.promise().query(my_c_query, [parseInt(req.body.StopPrice), req.body.NumShares, OriginalNumShares, OrderId]);

                    } else {
                        // myTmpBool == 1 인 경우
                        const my_c_query = `update order_ set StopPrice = ?, NumShares = ?, OriginalNumShares = ?, isPartiallyFilled = 1 where OrderId = ?`;
                        sql_connection.promise().query(my_c_query, [parseInt(req.body.StopPrice), req.body.NumShares, OriginalNumShares, OrderId]);

                    }

                }
            } catch (err) {
                console.log(err);
                return res.status(400).json({ message: err.message });
            }
            break;
        } else { // A matching trading pair is found

            const [tmp] = await sql_connection.promise().query(`select OrderId from order_ ORDER BY OrderId desc limit 1`);
            const NextOrderId = parseInt(tmp[0].OrderId) + 1;


            const buy_order_id = req.body.OrderType === 'Buy' ? NextOrderId : topPairResult.OrderId;
            const sell_order_id = req.body.OrderType === 'Sell' ? NextOrderId : topPairResult.OrderId;

            // If one existing order can fill the entire new order
            if (topPairResult.NumShares >= 0) {

                if (buy_order_id) {
                    transactionArr.push({
                        OrderId: parseInt(buy_order_id),

                        PricePerShare: parseInt((parseInt(req.body.StopPrice) + parseInt(topPairResult.StopPrice)) / 2),

                    });
                }
                if (sell_order_id) {
                    transactionArr.push({

                        OrderId: parseInt(sell_order_id),

                        PricePerShare: parseInt((parseInt(req.body.StopPrice) + parseInt(topPairResult.StopPrice)) / 2),

                    });
                }



                RemainingNumShares = 0;

                if (isNewOrder) {
                    // insert into query statement (save)
                    const my_f_query = `insert into order_ (CusAccNum,StockSymbol,OrderType,OriginalNumShares,NumShares,StopPrice,Completed,isPartiallyFilled, PriceType) values (?,?,?,?,0,?,1,1,'Limit_Stop')`;
                    await sql_connection.promise().query(my_f_query, [req.body.CusAccNum, req.body.StockSymbol, req.body.OrderType, req.body.NumShares, parseInt(req.body.StopPrice)]);

                } else {
                    // update (updateOne)
                    const my_u_query = `update order_ set StopPrice = ?, NumShares = 0, OriginalNumShares = ?, isPartiallyFilled = 1, Completed = 1 where OrderId = ?`;
                    await sql_connection.promise().query(my_u_query, [parseInt(req.body.StopPrice), OriginalNumShares, OrderId]);
                }


                topPairResult.NumShares === 0 && filledOrderArr.push(topPairResult.OrderId);

            } else { // It will take multiple orders
                if (buy_order_id) {
                    transactionArr.push({
                        OrderId: parseInt(buy_order_id),

                        PricePerShare: parseInt((parseInt(req.body.StopPrice) + parseInt(topPairResult.StopPrice)) / 2),

                    });
                }
                if (sell_order_id) {
                    transactionArr.push({

                        OrderId: parseInt(sell_order_id),

                        PricePerShare: parseInt((parseInt(req.body.StopPrice) + parseInt(topPairResult.StopPrice)) / 2),

                    });
                }


                RemainingNumShares = Math.abs(topPairResult.NumShares);

                if (isNewOrder) {
                    // insert into query statement (save)

                    const my_f_query = `insert into order_ (CusAccNum,StockSymbol,OrderType,OriginalNumShares,NumShares,StopPrice,is_filled,isPartiallyFilled, PriceType) values (?,?,?,?,?,?,0,1,'Limit_Stop')`;
                    await sql_connection.promise().query(my_f_query, [req.body.CusAccNum, req.body.StockSymbol, req.body.OrderType, req.body.NumShares, RemainingNumShares, parseInt(req.body.StopPrice)]);
                } else {
                    // update (updateOne)

                    const my_u_query = `update order_ set StopPrice = ?, NumShares = ?, OriginalNumShares = ?, isPartiallyFilled = 1, Completed = 0 where OrderId = ?`;
                    sql_connection.promise().query(my_u_query, [parseInt(req.body.StopPrice), RemainingNumShares, OriginalNumShares, OrderId]);
                }


                filledOrderArr.push(topPairResult.OrderId);
            }
        }

    }




    await saveTransactionArr(transactionArr);
    await updateFilledOrderArr(filledOrderArr);

};



























app.get('/placestock', (req, res) => {
    //placeStockPage

    if (typeof req.query.stocksymbol === 'undefined') console.error('error stocksymbol of tmp');
    var page = ejs.render(placeStockPage, {
        qdata: req.query.stocksymbol
    });
    res.send(page);
});


// GET all orders
app.get('/orders', (req, res) => {
    const my_custom_selall_query = `SELECT * from order_ ORDER BY Timestamp_ DESC`;
    try {

        sql_connection.query(my_custom_selall_query, (err, results) => {
            if (err) throw err;
            const orders = results;

            var page = ejs.render(ordersPage, {
                orders: orders
            });
            res.send(page);


        });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});




// GET all transactions
app.get('/transactions', (req, res) => {
    const my_custom_selall_query = `SELECT * FROM transact ORDER BY Timestamp_ DESC`;
    try {

        sql_connection.query(my_custom_selall_query, (err, results) => {
            if (err) throw err;
            const transactions = results;

            var page = ejs.render(transactionsPage, {
                transactions: transactions
            });
            res.send(page);


        });

    } catch (err) {
        res.status(500).json({ message: err.message });
    }

});





// GET one by id
app.get('/orders/:id', getOrder, (req, res) => {
    res.status(200).json(res.order);
});

// CREATE one order
app.post('/tossorder', async (req, res) => {
    await queryAndMatchPairs(req, res, true); // true <-> isNewOrder <-> new order true. all meaning same, true (but can set false for update patch or delete)
    res.status(200).redirect('/orders');
});

// PATCH one order
app.patch('/tossorder_pa/:id', async (req, res) => {

    // 저거 쓰려면, req.params.id 로 접근 가능 

    const { id, CusAccNum, StockSymbol, OrderType, NumShares, StopPrice } = req.body; // id -> undefined 뜰거임. sql 로 select 해서 limit 1 해서 + 1 tmp -> 이거를 NextOrderId 로 쓰삼 

    if (!res.order.Completed && !res.order.isPartiallyFilled) {

        if (typeof NumShares !== 'undefined' && NumShares !== null) {
            res.order.NumShares = NumShares;
        }
        if (typeof StopPrice !== 'undefined' && StopPrice !== null) {
            res.order.StopPrice = StopPrice;
        }

        try {
            // findOneAndUpdate
            const my_custom_update_query = `update order_ set NumShares = ?, StopPrice = ? where OrderId = ?`;
            await sql_connection.promise().query(my_custom_update_query, [res.order.NumShares, res.order.StopPrice, id]);

            const updatedOrder = {
                OrderId: id,
                CusAccNum: CusAccNum,
                StockSymbol: StockSymbol,
                OrderType: OrderType,
                NumShares: res.order.NumShares,
                StopPrice: res.order.StopPrice,
                isPartiallyFilled: res.order.isPartiallyFilled,
                Completed: res.order.Completed,
            };
            res.json(updatedOrder); // umm..


        } catch (err) {
            res.status(400).json({ message: err.message });
        }

    } else if (res.order.Completed) {
        res.status(405).json({
            message: "Order is filled and cannot be modified."
        });

    } else {
        res.status(405).json({
            message: "Order is partially filled and cannot be modified."
        });
    }

});

// DELETE one
app.delete('/tossorder_de/:id', getOrder, async (req, res) => {
    const { id, CusAccNum } = req.body; // id 대신 NextOrderId 쓰는게 맞을거임      

    if (!res.order.Completed && !res.order.isPartiallyFilled) {

        try {

            const my_custom_delete_query = `delete from order_ where OrderId = ?`;
            await sql_connection.promise().query(my_custom_delete_query, [id]);
            res.json({ message: "Order has been successfully either cancelled or not. please check" });

        } catch (err) {
            res.status(400).json({ message: err.message });
        }

    } else if (res.order.Completed) {
        res.status(405).json({
            message: "Order is filled and cannot be cancelled."
        });

    } else {
        res.status(405).json({
            message: "Order is partially filled and cannot be cancelled."
        });
    }
});



app.get('/getOrderBook', (req, res) => {
    const stocksymbol = req.query.stocksymbol;
    const queryFiveAskBidPriceOfStockSelectionQ = `
        select order_.OrderType, order_.StopPrice, sum(order_.NumShares) as total_quantity_shares
        from order_
        join stock on stock.stocksymbol = order_.stocksymbol
        where order_.stocksymbol = ? and order_.ordertype in ('Sell','Buy')
        group by order_.ordertype, order_.stopprice
        order by (case when order_.ordertype = 'Sell' then order_.stopprice END) desc, (case when order_.ordertype = 'Buy' then order_.stopprice END) asc
        limit 10;
        `;

    sql_connection.query(queryFiveAskBidPriceOfStockSelectionQ, [stocksymbol], (err, results) => {
        if (err) {
            res.status(500).json({ error: 'DB error occurs' });

        } else {
            res.json(results);

        }
    });
})

app.get('/fivePreferPrice', (req, res) => {
    var page = ejs.render(fivePreferPricePage, {
        data: req.query.stocksymbol,
    });
    res.send(page);
})

app.get("/search_general", (req, res) => {
    res.render("searchGeneralPage")
});

app.get("/welcome", (req, res) => {
    var unconditionalStockListDeliveryToFrontSide;


    /* SELECT ALL STOCK AT FIRST */

    sql_connection.query(basicQ, (err, result) => {
        if (err) throw err;
        if (result.length > 0) {
            unconditionalStockListDeliveryToFrontSide = result;
        }
        else {
            console.log('Empty 테이블: 주식 정보 하나도 없음');
            unconditionalStockListDeliveryToFrontSide = 0;
        }



        if (req.session.userID && req.session.userID.length >= 1) {

            console.log('Detected: strange request from a strange client..');
            console.log('username is :');
            console.log(req.session.userID);
            var page = ejs.render(homePage, {
                data: unconditionalStockListDeliveryToFrontSide,
            });
            return res.send(page);

        }


        var page = ejs.render(welcomePage, {
            data: unconditionalStockListDeliveryToFrontSide,
        });
        res.send(page);

    });



});

app.get("/home", isAuthenticated, (req, res) => {
    var unconditionalStockListDeliveryToFrontSide;


    /* SELECT ALL STOCK AT FIRST */

    sql_connection.query(basicQ, (err, result) => {
        if (err) throw err;
        if (result.length > 0) {
            unconditionalStockListDeliveryToFrontSide = result;
        }
        else {
            console.log('Empty 테이블: 주식 정보 하나도 없음');
            unconditionalStockListDeliveryToFrontSide = 0;
        }


        if (req.session.userID && req.session.userID.length >= 1) {

            var page = ejs.render(homePage, {
                data: unconditionalStockListDeliveryToFrontSide,
            });
            res.send(page);


        } else {

            console.log('Detected: strange request from an anonymous human..');
            var page = ejs.render(welcomePage, {
                data: unconditionalStockListDeliveryToFrontSide,
            });
            res.send(page);

        }

    });


});

/* logout(in) and signup routing defined */

app.post("/logout", (req, res) => {
    var unconditionalStockListDeliveryToFrontSide;


    // in code level here: do something first, such as session destroy user, and other stuff works, then if all ok, then redirect to welcome Page. for now, logout process done!

    /* early code starts from here.. */
    req.session.destroy(err => {
        if (err) {
            return res.redirect('/welcome'); // somewhere : /welcome or any other path anything!
        }
        // Description:else -> destroy was normally done. then now execute next code line.
    });





    /* basic fundamental code starts from here.. */

    sql_connection.query(basicQ, (err, result) => {
        if (err) throw err;
        if (result.length > 0) {
            unconditionalStockListDeliveryToFrontSide = result;
        }
        else {
            console.log('Empty 테이블: 주식 정보 하나도 없음');
            unconditionalStockListDeliveryToFrontSide = 0;
        }
    });

    var page = ejs.render(welcomePage, {
        data: unconditionalStockListDeliveryToFrontSide,
    });
    res.send(page); // render the welcome Page with query data of stock list in order for displaying default home screen with basic table contents
    // all done.

});


app.get("/login", (req, res) => {
    if (req.session.userID && req.session.userID.length >= 1) {

        console.log('Detected: strange request from a strange client..');
        console.log('username is :');
        console.log(req.session.userID);
        var page = ejs.render(homePage, {});
        return res.send(page);


    } else {

        var page = ejs.render(loginPage, {
            data: {},
        });
        res.send(page);

    }

});
app.post("/login", (req, res) => {
    const { userID, userPassword } = req.body;
    var unconditionalStockListDeliveryToFrontSide;
    const queryUserCredentialMatchDuringLoginSelectionQ = `select * from login where Usr = ? and Pwd = ?`;


    /* SELECT ALL STOCK AT FIRST */

    sql_connection.query(basicQ, (err, result) => {
        if (err) throw err;
        if (result.length > 0) {
            unconditionalStockListDeliveryToFrontSide = result;
        }
        else {
            console.log('Empty 테이블: 주식 정보 하나도 없음');
            unconditionalStockListDeliveryToFrontSide = 0;
        }
    });



    /* CHECK LOGIN CREDENTIAL IF THE USER EXISTS TO PROCESS LOGIN STUFF AND MOVE TO HOME DASH IF OK */

    sql_connection.query(queryUserCredentialMatchDuringLoginSelectionQ, [userID, userPassword], (error, results, fields) => {
        if (error) throw error;
        if (results.length > 0) {
            //console.log('results 0 index thing');
            //console.log((results[0].Id));
            //console.log((results.CusId));
            // Good. 200 OK status:   로그인 성공

            req.session.userID = userID;    // userId를 세션에 저장
            req.session.CusId = results[0].Id; // CusID (Id)를 세션에 저장


            var page = ejs.render(homePage, { data: unconditionalStockListDeliveryToFrontSide });
            res.send(page);
        }
        else {
            res.render("loginPage", { loginResult: 'fail' });

        }
    });

});


app.get("/signup", (req, res) => {
    var page = ejs.render(signupPage, {
        title: "Title",
        data: {},
    });
    res.send(page);
});
app.post("/signup", (req, res) => {
    const { userID, userPassword, userLastName, userFirstName } = req.body;
    const queryUserinfoDuringRegistSelectionQ = `select * from login where Usr = ?`;
    const queryUserNormalAddDuringRegistInsertion_1Q_1 = `insert into customer (LastName, FirstName) values (?, ?)`;
    const queryUserNormalAddDuringRegistInsertion_2Q_2 = `insert into account_ (AccCreDate, CusId) values (NOW(),?);`;
    const queryUserNormalAddDuringRegistInsertion_3Q_3 = `insert into login (Usr, Pwd, Id) values (?, ?, ?);`;

    sql_connection.query(queryUserinfoDuringRegistSelectionQ, [userID], (error, results, fields) => {
        if (error) throw error;

        if (results.length > 0) {
            console.log("이미 존재하는 아이디로 회원가입시도.");
            res.render("signupPage", { signupResult: 'fail' });
        }
        else {
            /* ADD A NEW USER UPDATE TO THE CUSTOMER TABLE */
            sql_connection.beginTransaction((err) => {
                if (err) throw err;



                sql_connection.query(queryUserNormalAddDuringRegistInsertion_1Q_1, [userLastName, userFirstName], (error, results, fields) => {
                    if (error) {
                        return sql_connection.rollback(() => {
                            throw error;
                        });
                    }

                    const newCusId = results.insertId;

                    sql_connection.query(queryUserNormalAddDuringRegistInsertion_2Q_2, [newCusId], (error, results, fields) => {
                        if (error) {
                            return sql_connection.rollback(() => {
                                throw error;
                            });
                        }

                        sql_connection.query(queryUserNormalAddDuringRegistInsertion_3Q_3, [userID, userPassword, newCusId], (error, results, fields) => {
                            if (error) {
                                return sql_connection.rollback(() => {
                                    throw error;
                                });
                            }

                            sql_connection.commit((err) => {
                                if (err) {
                                    return sql_connection.rollback(() => {
                                        throw err;
                                    });
                                }
                                // sc
                                console.log("serverlog: 회원가입 완료");

                                //res.send("회원가입 완료");

                                // redirection
                                res.redirect("/login");

                            });

                        });




                    });





                });
            });
        }
    });
});

/* End */


/* fund(mypage) and deposit cash routing defined */

app.get('/getFunds',
    isAuthenticated, (req, res) => { /* getFunds -> GET 방식만 처리. POST 방식으로 들어오는 요청에 대해서 처리하지 않음 */

        // 세션에서 CusID 가져옴 
        var id = req.session.CusId;  // req.session.CusId

        if (!id || typeof id === 'undefined') {
            console.log('req.session.CusId : ', id);
            console.log('req.session.CusId : ', req.session.CusId);
            console.log('redirect to /login..');
            return res.redirect('/login');
        }

        sql_connection.query(`SELECT MarginAvailable AS CustomerFund FROM account_ WHERE CusId = ?`, [id], (err, results) => {
            if (err) throw err;

            if (results.length > 0) {

                var page = ejs.render(fundPage, { data: results });
                return res.send(page);

            } else {
                console.log('/getFunds (path): Server Detected: results. length 0 on marginbalance request..');
                res.sendStatus(500);
            }


        });

    });

app.post('/cashAdd', isAuthenticated, (req, res) => {
    var id = req.session.CusId;
    const { cash_a } = req.body;
    const queryUpdateMoneyAddQ = `update account_ set MarginAvailable = MarginAvailable + ? where AccNum = ?`;

    if (!id || typeof id === 'undefined') {
        return res.redirect('/login');
    }
    if (typeof cash_a === 'undefined') {
        return res.redirect('/getFunds');
    }

    sql_connection.query(queryUpdateMoneyAddQ, [cash_a, id], (err, results) => {
        if (err) throw err;

        sql_connection.query(`SELECT MarginAvailable AS CustomerFund FROM account_ WHERE CusId = ?`, [id], (err, results) => {
            if (err) throw err;

            if (results.length > 0) {

                var page = ejs.render(fundPage, { data: results });
                return res.send(page);

            } else {
                console.log('/getFunds (path): Server Detected: results. length 0 on marginbalance request..');
                res.sendStatus(500);
            }


        });
    });
});

app.post('/cashSub', isAuthenticated, (req, res) => {
    var id = req.session.CusId;
    const { cash_s } = req.body;
    const queryUpdateMoneySubQ = `update account_ set MarginAvailable = MarginAvailable - ? where AccNum = ?`;

    if (!id || typeof id === 'undefined') {
        return res.redirect('/login');
    }
    if (typeof cash_s === 'undefined') {
        return res.redirect('/getFunds');
    }

    sql_connection.query(queryUpdateMoneySubQ, [cash_s, id], (err, results) => {
        if (err) throw err;

        sql_connection.query(`SELECT MarginAvailable AS CustomerFund FROM account_ WHERE CusId = ?`, [id], (err, results) => {
            if (err) throw err;

            if (results.length > 0) {

                var page = ejs.render(fundPage, { data: results });
                return res.send(page);

            } else {
                console.log('/getFunds (path): Server Detected: results. length 0 on marginbalance request..');
                res.sendStatus(500);
            }


        });
    });
});

/* End */





/* temporary admin dev routing defined */

app.get("/", (req, res) => {
    res.render("app")
});
app.get("/adminSuperDashboard", async (req, res) => {
    fs.readFile('./queries.sql', 'utf-8', (err, data) => {
        if (err) {
            console.error('Error reading SQL file:', err);
            return res.status(500).send('Internal Server Error');
        }

        const queries = data.split(';').map(query => query.trim()).filter(query => query.length > 0);

        executeQueries(queries, (err, results) => {
            if (err) {
                console.error('Error in /adminSuperDashboard:', err);
                return res.status(500).send('Internal Server Error');
            }

            const concat = [];
            var n = 8;
            while (n > 0) {
                concat.push(results[results.length - n]);
                n = n - 1;
            }
            var page = ejs.render(adminSuperDashboardPage, {
                data: concat,
            });
            res.send(page);
        });
    });

});
app.get("/connectcheck_" + targetTable[i], (req, res) => {
    sql_connection.query("SELECT * FROM " + targetTable[i] + ";", (err, result) => {
        if (err) throw err;
        else {
            var page = ejs.render(connectTestPage, {
                data: result,
            });
            res.send(page);

            i = i + 1;
            if (i == targetTable.length) i = 0;
        }
    });
});  // remove soon
app.post('/log', (req, res) => {
    console.log('[Client log] ', req.body.message);
    res.sendStatus(200);
});  // debug purpose, also remove soon
//



//






/* version one, two NOT being used currently.. */
/*

    var versionOne_ALPHA_FULL = 
    WITH Previous_Close_ AS(SELECT stocksymbol, stockpricehistory.shar
    eprice AS previous_close_price FROM stockpricehistory WHERE timestamp_ = (SELECT MAX(timestamp_) F
    ROM stockpricehistory WHERE stocksymbol = ?) and stocksymbol = ?) SELECT Stock.stockname, Stock
        .stocksymbol, Stock.shareprice AS current_price, Pre
    vious_Close_.previous_close_price, ROUND((Stock.shareprice - Previous_Close_.previo

    us_close_price), 2) AS change_price, ROUND((((Stock.shareprice - Previous_Close_.previ
    ous_close_price) / Previous_Close_.previous_close_price  ) * 100), 2) AS change_percent FROM Stock JOIN Previous_Close_ ON Stock.stocksymbol = Previous_Close_.stocksymbol;
    var versionTwo_BETA_SIMPLE =
    WITH Previous_Close_ AS(SELECT stocksy
    mbol, stockpricehistory.shareprice AS previous_close_price FROM stockpricehisto
    ry WHERE timestamp_ =
    (SELECT MAX(timestamp_) FROM stockpricehistory WHERE stocksymbol = ?) and stocksymbol
        = ?) SELECT Stock.stockname, Stock.stocksymbol, Stock.shareprice AS current_price, ROUND((((Stock.shareprice - Previous_Close_.previous_close_price) /
        Previous_Close_.previous_close_price) * 100), 2) AS change_percent FROM Stock JOIN Previous_Close_ ON Stock.stocksymbol = Previous_Close_.stocksymbol;
*/

/* var versionThr_GAMMA_BEST = `WITH Previous_Close_ AS (
    SELECT 
    stocksymbol,
    MAX(timestamp_) AS latest_timestamp
FROM 
    stockpricehistory
GROUP BY 
    stocksymbol
),
something AS (
select
Previous_Close_.stocksymbol,
stockpricehistory.shareprice AS previous_close_price    
from stockpricehistory
join Previous_Close_ on Previous_Close_.stocksymbol = stockpricehistory.stocksymbol
where stockpricehistory.timestamp_ = Previous_Close_.latest_timestamp
)
SELECT 
Stock.stockname, 
Stock.stocksymbol, 
Stock.shareprice AS current_price, 
ROUND(
(
  (
    (
      Stock.shareprice - something.previous_close_price
    ) / something.previous_close_price
  ) * 100
), 
2
) AS change_percent 
FROM 
Stock 
JOIN something ON Stock.stocksymbol = something.stocksymbol`;*/







//



// Get the latest transaction price for a stock
const getLatestTransactionPrice = (stockSymbol, callback) => {
    const query = 'SELECT pricepershare FROM transact JOIN order_ ON order_.OrderId = transact.OrderId WHERE StockSymbol = ? ORDER BY transact.timestamp_ DESC LIMIT 1';
    sql_connection.query(query, [stockSymbol], (err, results) => {

        if (err) throw err;

        callback(results.length > 0 ? results[0].pricepershare : null);
    });
};

// Fetch all stock symbols from the database
const getAllStockSymbols = (callback) => {

    const query = 'SELECT StockSymbol FROM stock';
    sql_connection.query(query, (err, results) => {

        if (err) throw err;

        callback(results.map(row => row.StockSymbol));

    });
};

// Save closing price to stockpricehistory
const saveClosingPrice = (stockSymbol) => {
    getLatestTransactionPrice(stockSymbol, (latestPrice) => {
        if (latestPrice !== null) {

            const query = 'INSERT INTO stockpricehistory (StockSymbol, SharePrice, Timestamp_) VALUES (?, ?, ?)';
            sql_connection.query(query, [stockSymbol, latestPrice, new Date()], (err) => {
                if (err) throw err;

            });
        } else {
            const query_exception_dealing_query = 'INSERT INTO stockpricehistory (StockSymbol, SharePrice, Timestamp_) VALUES (?, (SELECT SharePrice FROM stock WHERE StockSymbol = ?), ?)';
            sql_connection.query(query_exception_dealing_query, [stockSymbol, stockSymbol, new Date()], (err) => {
                if (err) throw err;
                // console.log(`[But Exceptionally dealt] Inserted closing price for ${stockSymbol}: `);
            });
        }
    });
};

// Check if the market is closed
cron.schedule('* * * * *', () => {
    const now = new Date();
    const currentHour = now.getHours(); // 1 ~ 23 으로 테스트하기 (현재 아래코드 보면, -1 넣어뒀음) 18시로 테스트하고 싶으면 === 18
    const currentMinute = now.getMinutes();

    // Check if market closes automatically 1분마다 
    if (currentHour === -1 && [7, 8, 9].includes(currentMinute)) { // <- hard coded yet just for my convenience  // later it should be modified
        //console.log('Market closed. Fetching closing prices...');
        //console.log(currentHour) console.log(currentMinute)
        console.log(currentMinute)

        getAllStockSymbols((symbols) => {

            for (let i = 0; i < symbols.length; i++) {

                saveClosingPrice(symbols[i]);
            }
        });
    }
});




//
app.listen(3001, () => {
    console.log("서버 실행 중");
});











// DetailPriceSelection 알고리즘 <- 이건 지우지 말기 일단
/*

const queryDetailPricePercentageSelectionQ = `SELECT
    stocksymbol,
    stockpricehistory.shareprice AS previous_close_price
FROM
    stockpricehistory
WHERE
    timestamp_ = (SELECT MAX(timestamp_) FROM stockpricehistory WHERE stocksymbol = ?)
    and stocksymbol = ?`;

 var page = ejs.render(detailPercentPage, {
                data: results,
            });
            res.send(page);

sql connection query (queryDetailPricePercentageSelectionQ, [ss, ss], () => {} */







//


//









