const express = require('express');
const router = express.Router();
const usersController = require('../controllers/UsersController');
const ordersController = require('../controllers/OrdersController');
const isAuthenticated = require('../middleware/auth');
// HERE THIS FILE contains "GET" ROUTES ONLY

/* ordersController defined */
router.get('/placestock/:symbol', isAuthenticated, ordersController.myPlaceStockBySymbol);  // /placestock path 
router.get('/ordersalllog', isAuthenticated, ordersController.myOrdersAllLog);  // / path 
router.get('/orderseespecific/:id', ordersController.getOrder , ordersController.myOrderSeeSpecificById);  // / path 
router.get('/transactions/:symbol', isAuthenticated, ordersController.myTransactionsBySymbol);  // / path   //HARDCODED HARDCODED HARDCODED HARDCODED HARDCODED 
router.get('/materialweblistofmine/:symbol', isAuthenticated, ordersController.myMaterialWebListOfMineBySymbol);  // / path 
router.get('/bid/:symbol', isAuthenticated, ordersController.myBidBySymbol);  // / path 
/* usersController defined */
router.get('/search_general', usersController.mySearchGeneral);  // / path 
router.get('/welcome', usersController.myWelcome);  // / path 
router.get('/home', isAuthenticated, usersController.myHome);  // / path 
router.get('/login', usersController.getMyLogin);  // / path 
router.get('/signup', usersController.getMySignup);  // / path 
router.get('/getFunds', isAuthenticated, usersController.myGetFunds);  // / path 
router.get('/getPortfolio', isAuthenticated, usersController.myGetPortfolio);  // / path
router.get('/getOrderCancelable', isAuthenticated, usersController.myGetOrderCancelable);  // / path 
router.get('/adminSuperDashboard', usersController.myAdminSuperDashboard);  // / path 













































































//

































//






module.exports = router;


