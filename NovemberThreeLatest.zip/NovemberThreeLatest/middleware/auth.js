

function isAuthenticated(req, res, next) {
    
    if (req.session.userID) {
        
        return next();
    }
    // 로그인 페이지로 리디렉션
    res.redirect('/login');
}

module.exports = isAuthenticated;
