const sql_connection = require('../config/db');
const ejs = require('ejs');

const { getWelcomePage, getLoginPage, getSignupPage, getFivePreferPricePage, getPlaceStockPage, getOrdersPage, getTransactionsPage, getHomePage } = require('../shared');



// POST(+small amount of GET) METHOD (Focusing on POST, not neccesarily GET)
exports.createOrder = (req, res) => {
    const p_Data = req.body;
    for (const key in p_Data) {
        if (p_Data.hasOwnProperty(key)) {
            console.log(`${key}: ${p_Data[key]}`);
        }
    }

    console.log(p_Data);
    console.log('post method');
    console.log('path:   ~/api/orders');
    console.log('c_o__OrdersController_js');
    console.log('routing success!!');
    res.json({ message: 'Greatly Received: additional msg: createOrder Binding (OrdersController_js test).' });
    //res.send('createOrder Binding (OrdersController_js test)');
    console.log('res send() completed.');
};

exports.getOrder = (req, res, next) => {
    let order;
    try {
        const my_custom_select_query = `SELECT * from order_ where OrderId = ?`;

        sql_connection.query(my_custom_select_query, [req.params.id], (err, results) => {
            if (err) throw err;

            if (results.length > 0) {
                order = results[0];
                res.order = order;
                next();
            } else {
                // order is null (result is null)
                return res.status(404).json({ message: 'Order does not exist. ' });
            }
        })


    } catch (err) {
        return res.status(500).json({ message: err.message })
    }

};


exports.saveTransactionArr = async (transactionArr) => {

    if (!Array.isArray(transactionArr) || !transactionArr.length) {
        console.log('Transaction array is empty');
        return;
    }

    const my_custom_query = `INSERT INTO transact (OrderId, PricePerShare) VALUES (?, ?)`;

    let i = 0;

    try {
        while (i < transactionArr.length) {
            await sql_connection.promise().query(my_custom_query, [transactionArr[i].OrderId, transactionArr[i].PricePerShare]);
            i = i + 1;
        }
    } catch (err) {
        console.log('Error during saveTransactionArr:', err);
    }
};

exports.updateFilledOrderArr = async (filledOrderArr) => {
    if (!Array.isArray(filledOrderArr) || !filledOrderArr.length) {
        console.log('Filled order array is empty');
        return;
    }

    try {
        const my_custom_query = `UPDATE order_ SET NumShares = 0, Completed = 1 WHERE OrderId IN (${filledOrderArr.map(() => '?').join(', ')})`;
        const values = filledOrderArr;
        await sql_connection.promise().execute(my_custom_query, values);
    } catch (err) {
        console.log('Error during updateFilledOrderArr:', err);
    }
};
exports.queryAndMatchPairs = async (req, res, isNewOrder) => {

    let transactionArr = [];
    let filledOrderArr = [];
    let topPairResult;
    let { OrderId, NumShares } = req.body;
    let OriginalNumShares = NumShares;

    if (isNewOrder && req.body.NumShares <= 0) {
        return res.status(400).json({ message: 'Invalid order input' });
    }

    const searchForPair = async () => {
        const filterQuery = `
        SELECT * FROM order_
        WHERE StockSymbol = ?
        AND OrderType = ?
        AND StopPrice ${req.body.OrderType === 'Buy' ? '<=' : '>='} ?
        AND NumShares > 0
        AND Completed = 0
        ORDER BY StopPrice ${req.body.OrderType === 'Buy' ? 'ASC' : 'DESC'}, Timestamp_ ASC
        LIMIT 1
        `;

        const updateQuery = `
        UPDATE order_
        SET NumShares = NumShares - ?, isPartiallyFilled = 1
        WHERE OrderId = ?
        `;


        try {
            const [rows] = await sql_connection.promise().query(filterQuery, [req.body.StockSymbol, (req.body.OrderType === 'Buy') ? 'Sell' : 'Buy', parseInt(req.body.StopPrice)]);

            if (rows.length === 0) {
                return null;
            }

            let resulted_order = rows[0];

            await sql_connection.promise().query(updateQuery, [resulted_order.NumShares, resulted_order.OrderId]);
            const [mresults] = await sql_connection.promise().query(`select * from order_ where OrderId = ?`, [resulted_order.OrderId]);
            if (mresults.length > 0) {
                resulted_order = mresults[0];
            }

            return resulted_order;


        } catch (err) {
            console.log(err);
            return null;
        }
    }


    let RemainingNumShares = NumShares;
    while (RemainingNumShares > 0) {
        topPairResult = await searchForPair();

        // No matching trading pair is found
        if (!topPairResult) {
            try {
                //  myTmpBool 필요함 나중을 위해서 (코드 지우면 안될듯)
                let myTmpBool;
                if (RemainingNumShares > 0 && NumShares !== RemainingNumShares) {
                    myTmpBool = 1;
                }
                if (isNewOrder) {
                    // insert into query statement (save)
                    if (typeof myTmpBool === 'undefined') {
                        // myTmpBool 이 1이 아닌 경우(type of undefined 와 같음)
                        const my_f_query = `insert into order_ (CusAccNum,StockSymbol,OrderType,OriginalNumShares,NumShares,StopPrice,Completed,isPartiallyFilled, PriceType) values (?,?,?,?,?,?,0,0,'Limit_Stop')`;
                        await sql_connection.promise().query(my_f_query, [req.body.CusAccNum, req.body.StockSymbol, req.body.OrderType, req.body.NumShares, req.body.NumShares, parseInt(req.body.StopPrice)]);

                    } else {
                        // myTmpBool == 1 인 경우
                        const my_f_query = `insert into order_ (CusAccNum,StockSymbol,OrderType,OriginalNumShares,NumShares,StopPrice,Completed,isPartiallyFilled, PriceType) values (?,?,?,?,?,?,0,1,'Limit_Stop')`;
                        await sql_connection.promise().query(my_f_query, [req.body.CusAccNum, req.body.StockSymbol, req.body.OrderType, req.body.NumShares, req.body.NumShares, parseInt(req.body.StopPrice)]);
                    }

                } else {
                    // update (updateOne)
                    if (typeof myTmpBool === 'undefined') {
                        // myTmpBool 이 1이 아닌 경우(type of undefined 와 같음)
                        const my_c_query = `update order_ set StopPrice = ?, NumShares = ?, OriginalNumShares = ? where OrderId = ?`;
                        sql_connection.promise().query(my_c_query, [parseInt(req.body.StopPrice), req.body.NumShares, OriginalNumShares, OrderId]);

                    } else {
                        // myTmpBool == 1 인 경우
                        const my_c_query = `update order_ set StopPrice = ?, NumShares = ?, OriginalNumShares = ?, isPartiallyFilled = 1 where OrderId = ?`;
                        sql_connection.promise().query(my_c_query, [parseInt(req.body.StopPrice), req.body.NumShares, OriginalNumShares, OrderId]);

                    }

                }
            } catch (err) {
                console.log(err);
                return res.status(400).json({ message: err.message });
            }
            break;
        } else { // A matching trading pair is found

            const [tmp] = await sql_connection.promise().query(`select OrderId from order_ ORDER BY OrderId desc limit 1`);
            const NextOrderId = parseInt(tmp[0].OrderId) + 1;


            const buy_order_id = req.body.OrderType === 'Buy' ? NextOrderId : topPairResult.OrderId;
            const sell_order_id = req.body.OrderType === 'Sell' ? NextOrderId : topPairResult.OrderId;

            // If one existing order can fill the entire new order
            if (topPairResult.NumShares >= 0) {

                if (buy_order_id) {
                    transactionArr.push({
                        OrderId: parseInt(buy_order_id),

                        PricePerShare: parseInt((parseInt(req.body.StopPrice) + parseInt(topPairResult.StopPrice)) / 2),

                    });
                }
                if (sell_order_id) {
                    transactionArr.push({

                        OrderId: parseInt(sell_order_id),

                        PricePerShare: parseInt((parseInt(req.body.StopPrice) + parseInt(topPairResult.StopPrice)) / 2),

                    });
                }



                RemainingNumShares = 0;

                if (isNewOrder) {
                    // insert into query statement (save)
                    const my_f_query = `insert into order_ (CusAccNum,StockSymbol,OrderType,OriginalNumShares,NumShares,StopPrice,Completed,isPartiallyFilled, PriceType) values (?,?,?,?,0,?,1,1,'Limit_Stop')`;
                    await sql_connection.promise().query(my_f_query, [req.body.CusAccNum, req.body.StockSymbol, req.body.OrderType, req.body.NumShares, parseInt(req.body.StopPrice)]);

                } else {
                    // update (updateOne)
                    const my_u_query = `update order_ set StopPrice = ?, NumShares = 0, OriginalNumShares = ?, isPartiallyFilled = 1, Completed = 1 where OrderId = ?`;
                    await sql_connection.promise().query(my_u_query, [parseInt(req.body.StopPrice), OriginalNumShares, OrderId]);
                }


                topPairResult.NumShares === 0 && filledOrderArr.push(topPairResult.OrderId);

            } else { // It will take multiple orders
                if (buy_order_id) {
                    transactionArr.push({
                        OrderId: parseInt(buy_order_id),

                        PricePerShare: parseInt((parseInt(req.body.StopPrice) + parseInt(topPairResult.StopPrice)) / 2),

                    });
                }
                if (sell_order_id) {
                    transactionArr.push({

                        OrderId: parseInt(sell_order_id),

                        PricePerShare: parseInt((parseInt(req.body.StopPrice) + parseInt(topPairResult.StopPrice)) / 2),

                    });
                }


                RemainingNumShares = Math.abs(topPairResult.NumShares);

                if (isNewOrder) {
                    // insert into query statement (save)

                    const my_f_query = `insert into order_ (CusAccNum,StockSymbol,OrderType,OriginalNumShares,NumShares,StopPrice,is_filled,isPartiallyFilled, PriceType) values (?,?,?,?,?,?,0,1,'Limit_Stop')`;
                    await sql_connection.promise().query(my_f_query, [req.body.CusAccNum, req.body.StockSymbol, req.body.OrderType, req.body.NumShares, RemainingNumShares, parseInt(req.body.StopPrice)]);
                } else {
                    // update (updateOne)

                    const my_u_query = `update order_ set StopPrice = ?, NumShares = ?, OriginalNumShares = ?, isPartiallyFilled = 1, Completed = 0 where OrderId = ?`;
                    sql_connection.promise().query(my_u_query, [parseInt(req.body.StopPrice), RemainingNumShares, OriginalNumShares, OrderId]);
                }


                filledOrderArr.push(topPairResult.OrderId);
            }
        }

    }




    await saveTransactionArr(transactionArr);
    await updateFilledOrderArr(filledOrderArr);

};



exports.myTossOrder = async (req, res) => {
    await queryAndMatchPairs(req, res, true); // true <-> isNewOrder <-> new order true. all meaning same, true (but can set false for update patch or delete)
    res.status(200).redirect('/orders');
};

exports.myPlaceStock = (req, res) => {
    //placeStockPage

    if (typeof req.query.stocksymbol === 'undefined') console.error('error stocksymbol of tmp');
    var page = ejs.render(getPlaceStockPage(), {
        qdata: req.query.stocksymbol || ''
    });
    res.send(page);
};


exports.myOrders = (req, res) => {
    const my_custom_selall_query = `SELECT * from order_ ORDER BY Timestamp_ DESC`;
    try {

        sql_connection.query(my_custom_selall_query, (err, results) => {
            if (err) throw err;
            const orders = results;

            var page = ejs.render(getOrdersPage(), {
                orders: orders
            });
            res.send(page);


        });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

exports.myTransactions = (req, res) => {
    const my_custom_selall_query = `SELECT * FROM transact ORDER BY Timestamp_ DESC`;
    try {

        sql_connection.query(my_custom_selall_query, (err, results) => {
            if (err) throw err;
            const transactions = results;

            var page = ejs.render(getTransactionsPage(), {
                transactions: transactions
            });
            res.send(page);


        });

    } catch (err) {
        res.status(500).json({ message: err.message });
    }

};

exports.myOrdersById = (req, res) => {
    res.status(200).json(res.order);
};
