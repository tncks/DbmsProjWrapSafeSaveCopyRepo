const express = require('express');
const router = express.Router();
const usersController = require('../controllers/UsersController');
const ordersController = require('../controllers/OrdersController');
const isAuthenticated = require('../middleware/auth');
// bottom line has other stuff sets / check it
// HERE THIS FILE contains "GET" ROUTES ONLY
//router.get('/orders', ordersController.createOrder);  // /orders path
/* ordersController defined */
router.get('/placestock', ordersController.myPlaceStock);  // /placestock path 
router.get('/orders', ordersController.myOrders);  // / path 
router.get('/transactions', ordersController.myTransactions);  // / path 
router.get('/orders/:id', ordersController.getOrder , ordersController.myOrdersById);  // / path 
/* usersController defined */
router.get('/getOrderBook', usersController.myGetOrderBook);  // / path 
router.get('/fivePreferPrice', usersController.myFivePreferPrice);  // / path 
router.get('/search_general', usersController.mySearchGeneral);  // / path 
router.get('/welcome', usersController.myWelcome);  // / path 
router.get('/home', isAuthenticated, usersController.myHome);  // / path 
router.get('/login', usersController.getMyLogin);  // / path 
router.get('/signup', usersController.getMySignup);  // / path 
router.get('/getFunds', isAuthenticated, usersController.myGetFunds);  // / path 
router.get('/adminSuperDashboard', usersController.myAdminSuperDashboard);  // / path 
// login 이나 signup 등은 loginController.myLogin 등등 으로 또 분할하고 적용하기 나중에 
// 그리고, 위에 require 도 추가하고 새 이름의 파일도 생성하고 연결  

















module.exports = router;



/*


const accInfoController = require('../controllers/AccInfoController');
const customerController = require('../controllers/CustomerController');
const doRegisterEmployeeController = require('../controllers/DoRegisterEmployeeController');
const manOrdersController = require('../controllers/ManOrdersController');
const searchStockController = require('../controllers/SearchStockController');

const addAccountController = require('../controllers/AddAccountController');
const customerListController = require('../controllers/CustomerListController');
const ecYearController = require('../controllers/ECYearController');
const manOrderStockController = require('../controllers/ManOrderStockController');
const setStockPriceController = require('../controllers/SetStockPriceController');

const addCustController = require('../controllers/AddCustController');
const deleteCustController = require('../controllers/DeleteCustController');
const editCustController = require('../controllers/EditCustController');
const manUtilitiesController = require('../controllers/ManUtilitiesController');
const stockController = require('../controllers/StockController');

const addCustUserController = require('../controllers/AddCustUserController');
const deleteCustUserController = require('../controllers/DeleteCustUserController');
const editEmpController = require('../controllers/EditEmpController');
const mostActiveStocksController = require('../controllers/MostActiveStocksController');
const stockHistoryController = require('../controllers/StockHistoryController');

const addEmpController = require('../controllers/AddEmpController');
const deleteEmpController = require('../controllers/DeleteEmpController');
const employeeListController = require('../controllers/EmployeeListController');

const suggestedStockController = require('../controllers/SuggestedStockController');

const addEmpUserController = require('../controllers/AddEmpUserController');
const deleteEmpUserController = require('../controllers/DeleteEmpUserController');
const helpController = require('../controllers/HelpController');
const orderStockController = require('../controllers/OrderStockController');
const transactionController = require('../controllers/TransactionController');

const adminController = require('../controllers/AdminController');
const doExportController = require('../controllers/DoExportController');
const homeController = require('../controllers/HomeController');
const portfolioController = require('../controllers/PortfolioController');
const transactionListController = require('../controllers/TransactionListController');

const authController = require('../controllers/AuthController');
const doImportController = require('../controllers/DoImportController');
const loginController = require('../controllers/LoginController');
const registerCustomerController = require('../controllers/RegisterCustomerController');
const userController = require('../controllers/UsersController');

const bestStockController = require('../controllers/BestStockController');
const doLoginController = require('../controllers/DoLoginController');
const mailingListController = require('../controllers/MailingListController');
const registerEmployeeController = require('../controllers/RegisterEmployeeController');
const userListController = require('../controllers/UserListController');

const colleagueListController = require('../controllers/ColleagueListController');
const doOrderStockController = require('../controllers/DoOrderStockController');
const mainHelpController = require('../controllers/MainHelpController');
const revenueSummaryController = require('../controllers/RevenueSummaryController');

const cusRepUtilitiesController = require('../controllers/CusRepUtilitiesController');
const doRegisterCustomerController = require('../controllers/DoRegisterCustomerController');
const manOrderCustomerController = require('../controllers/ManOrderCustomerController');
const salesController = require('../controllers/SalesController');


*/