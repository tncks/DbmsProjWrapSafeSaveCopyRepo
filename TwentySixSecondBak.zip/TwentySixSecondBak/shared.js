const fs = require('fs');
const path = require('path');

const getPageContent = (pageName) => {
  return fs.readFileSync(path.join(__dirname, 'views', `${pageName}.ejs`), 'utf8');
};

const basicQ = `WITH Previous_Close_ AS (
    SELECT 
        stocksymbol,
        MAX(timestamp_) AS latest_timestamp
    FROM 
        stockpricehistory
    GROUP BY 
        stocksymbol
),
something AS (
    select
    Previous_Close_.stocksymbol,
    stockpricehistory.shareprice AS previous_close_price    
    from stockpricehistory
    join Previous_Close_ on Previous_Close_.stocksymbol = stockpricehistory.stocksymbol
    where stockpricehistory.timestamp_ = Previous_Close_.latest_timestamp
)
SELECT 
  Stock.stockname, 
  Stock.stocksymbol, 
  Stock.shareprice AS current_price, 
  ROUND(
    (
      (
        (
          Stock.shareprice - something.previous_close_price
        ) / something.previous_close_price
      ) * 100
    ), 
    2
  ) AS change_percent 
FROM 
  Stock 
  JOIN something ON Stock.stocksymbol = something.stocksymbol`;

module.exports = {
  getWelcomePage: () => getPageContent('welcomePage'),
  getLoginPage: () => getPageContent('loginPage'),
  getSignupPage: () => getPageContent('signupPage'),
  getFivePreferPricePage: () => getPageContent('fivePreferPricePage'),
  getPlaceStockPage: () => getPageContent('placeStockPage'),
  getOrdersPage: () => getPageContent('ordersPage'),
  getTransactionsPage: () => getPageContent('transactionsPage'),
  getFundPage: () => getPageContent('fundPage'),
  getHomePage: () => getPageContent('homePage'),
  getAdminSuperDashboardPage: () => getPageContent('adminSuperDashboardPage'),
  getSearchGeneralPage: () => getPageContent('searchGeneralPage'),
  basicQ
};




















//const ejs = require("ejs");
// const welcomePage = fs.readFileSync('./views/welcomePage.ejs', 'utf8');
// const fivePreferPricePage = fs.readFileSync('./views/fivePreferPricePage.ejs', 'utf8');
// const placeStockPage = fs.readFileSync('./views/placeStockPage.ejs', 'utf8');
// const ordersPage = fs.readFileSync('./views/ordersPage.ejs', 'utf8');
// const transactionsPage = fs.readFileSync('./views/transactionsPage.ejs', 'utf8');
// const homePage = fs.readFileSync('./views/homePage.ejs', 'utf8');
// const fundPage = fs.readFileSync('./views/fundPage.ejs', 'utf8');
// const loginPage = fs.readFileSync('./views/loginPage.ejs', 'utf8');
// const signupPage = fs.readFileSync('./views/signupPage.ejs', 'utf8');
// const connectTestPage = fs.readFileSync('./views/connectTestPage.ejs', 'utf8');
// const adminSuperDashboardPage = fs.readFileSync('./views/adminSuperDashboardPage.ejs', 'utf8');