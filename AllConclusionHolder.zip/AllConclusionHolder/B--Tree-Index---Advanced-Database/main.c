#include "bpt.h"

void my_printSpace(int level) {
    for (int i = 0; i < level; i++) {
        printf("\t"); 
    }
}
void my_print_tree(Node *node, int level) {
    // 노드가 NULL인 경우
    if (node == NULL) {
        return;
    }

    
    my_printSpace(level);
    printf("Node at [%p] "/*with '%d' keys: "*/, node/*, node->num_keys*/);
    
    // 키를 출력
    for (int i = 0; i < node->num_keys; i++) {
        printf("%ld %s", node->keys[i]->v.intV, node->is_leaf == 1 ? "(lf) " : " ");
    }
    printf("\n");

    
    if (!node->is_leaf) {
        
        for (int i = 0; i < node->num_keys + 1; i++) {
            Node *child = *((Node**)node->pointers + i);
            
            my_print_tree(child, level + 1);
        }
    }
}

int main (){
  // fprintf(stdout, "\n@ ONE. t i and find\n");
  // testInsertAndFind();
  // fprintf(stdout, "\n@ TWO. t del\n");
  // testDelete();
  fprintf(stdout, "\n@ THR. t idx scan\n");
  testIndexScan();
/*fprintf(stdout, "\n@ TWO. t del\n");
  testDelete();
  fprintf(stdout, "\n@ THR. t idx scan\n");
  testIndexScan(); */

  // while(scanf("%c", &instruction) != EOF){
  //       switch(instruction){
  //           case 'i':
  //               scanf("%ld %s", &input, buf);
  //               db_insert(input, buf);
  //               break;
  //           case 'f':
  //               scanf("%ld", &input);
  //               result = db_find(input);
  //               if (result) {
  //                   printf("Key: %ld, Value: %s\n", input, result);
  //                   free(result);
  //               }
  //               else
  //                   printf("Not Exists\n");

  //               fflush(stdout);
  //               break;
  //           case 'd':
  //               scanf("%ld", &input);
  //               db_delete(input);
  //               break;
  //           case 'q':
  //               while (getchar() != (int)'\n');
  //               return EXIT_SUCCESS;
  //               break;   

  //       }
  //       while (getchar() != (int)'\n');
  //  }

  return 0;
}

















// ************************************************************ 
void
testInsertAndFind (void)
{

  RID insert[] = { 
    {1,1},
    {2,2},
    {1,3},
    {3,4},
    {4,5},
  //   {1,6},
  //   {1,7},
  //   {1,8},
  //  {3,9},
  //   {4,10},
  //  {1,11},
  //  {2,12},
  //  {1,13},
  }; // {page, slot}
  int numInserts = sizeof(insert) / sizeof(insert[0]);
  Value **keys;
  char *stringKeys[] = {
    "i1",
    "i2",
    "i3",
    "i4",
    "i5",
    // "i6",
    // "i7",
    // "i8",
    // "i9",
    // "i10",
    // "i11",
    // "i12",
    // "i13"
  };
  //testName = "test b-tree inserting and search";
  int i, testint;
  BTreeHandle *tree = NULL;
  
  keys = createValues(stringKeys, numInserts);

  // init
  TEST_CHECK(initIndexManager(NULL));
  TEST_CHECK(createBtree("testidx", DT_INT, 2));
  TEST_CHECK(openBtree(&tree, "testidx"));

  // insert keys
  // if(traceDebug) printf("insert keys\n");
  for(i = 0; i < numInserts; i++) {
    TEST_CHECK(insertKey(tree, keys[i], insert[i]));
    // if(traceDebug) printf("------------sequence [%d]\n\n-------------------------\n\n---printTree!!\t ",i);
    // if(traceDebug) printTree(tree);
	  //if(i>0) TEST_CHECK(printTree(tree));
  }

  // check index stats
  // if(traceDebug) printf("check index stats\n");
  TEST_CHECK(getNumNodes(tree, &testint));
  //ASSERT_EQUALS_INT(testint,2, "number of nodes in btree");
  TEST_CHECK(getNumEntries(tree, &testint));
  //ASSERT_EQUALS_INT(testint, numInserts, "number of entries in btree");

  //added
  /*function call */
  BTreeManager *tMgr = (BTreeManager *) tree->mgmtData;
  printf("\n\n");
  my_print_tree(tMgr->root, 0);
  printf("\n\n");
  printBufferPoolInfo(&tMgr->bufferPool, 1000);
  printf("\n\n");
  //end

  // search for keys
  // if(traceDebug) printf("search for keys\n");
  for(i = 0; i < numInserts; i++)
    {
      int pos = rand() % numInserts;
      RID rid;
      Value *key = keys[pos];

      TEST_CHECK(findKey(tree, key, &rid));
      //ASSERT_EQUALS_RID(insert[pos], rid, "did we find the correct RID?");
    }

  // cleanup
  TEST_CHECK(closeBtree(tree));
  TEST_CHECK(deleteBtree("testidx"));
  TEST_CHECK(shutdownIndexManager());
  freeValues(keys, numInserts);

  TEST_DONE();
}

// ************************************************************ 
void
testDelete (void)
{
  RID insert[] = { 
    {1,1},
    {2,3},
    {1,2},
    {3,5},
    {4,4},
    {3,2}, 
  };
  int numInserts = 6;
  Value **keys;
  char *stringKeys[] = {
    "i1",
    "i11",
    "i13",
    "i17",
    "i23",
    "i52"
  };
  //testName = "test b-tree inserting and search";
  int i, iter;
  BTreeHandle *tree = NULL;
  int numDeletes = 6;
  bool *deletes = (bool *) malloc(numInserts * sizeof(bool));
  if(!deletes) {
	fprintf(stderr, "Memory allocation failed\n");
  }
  
  keys = createValues(stringKeys, numInserts);

  // init
  TEST_CHECK(initIndexManager(NULL));

  // create test b-tree and randomly remove entries
  for(iter = 0; iter < 6; iter++)
    {
      // randomly select entries for deletion (may select the same on twice)
      for(i = 0; i < numInserts; i++)
	deletes[i] = FALSE;
      for(i = 0; i < numDeletes; i++)
	deletes[rand() % numInserts] = TRUE;

      // init B-tree
      TEST_CHECK(createBtree("testidx", DT_INT, 2));
      TEST_CHECK(openBtree(&tree, "testidx"));

      // insert keys
      for(i = 0; i < numInserts; i++)
	TEST_CHECK(insertKey(tree, keys[i], insert[i]));
      
//------------------------------------
      // delete entries
      for(i = 0; i < numInserts; i++)
      {
	  if (deletes[i]) TEST_CHECK(deleteKey(tree, keys[i]));
      }


//------------------------------------

      // search for keys
      
      for(i = 0; i < 6; i++)
	{
	  int pos = rand() % numInserts;
	  RID rid;
	  Value *key = keys[pos];
	  
	  if (deletes[pos])
	    {
	      int rc = findKey(tree, key, &rid);
        if(rc == -1000) printf("\n");
	      //ASSERT_TRUE((rc == RC_IM_KEY_NOT_FOUND), "entry was deleted, should not find it");
	    }
	  else
	    {
	      TEST_CHECK(findKey(tree, key, &rid));
	      //ASSERT_EQUALS_RID(insert[pos], rid, "did we find the correct RID?");
	    }
	}

//------------------------------------
      // cleanup
      // if(traceDebug) printf("now, cleanup performing..\n");
      TEST_CHECK(closeBtree(tree));
      TEST_CHECK(deleteBtree("testidx"));
    }

  TEST_CHECK(shutdownIndexManager());
  freeValues(keys, numInserts);
  free(deletes);

  TEST_DONE();
}

// ************************************************************ 
void
testIndexScan (void)
{
  RID insert[] = { 
    {1,1},
    {2,3},
    {1,2},
    {3,5},
    {4,4},
    {3,2}, 
  };
  int numInserts = 6;
  Value **keys;
  char *stringKeys[] = {
    "i1",
    "i11",
    "i13",
    "i17",
    "i23",
    "i52"
  };
  
  //testName = "random insertion order and scan";
  int i, testint, iter, rc;
  BTreeHandle *tree = NULL;
  BT_ScanHandle *sc = NULL;
  RID rid;
  
  keys = createValues(stringKeys, numInserts);

  // init
  TEST_CHECK(initIndexManager(NULL));

  for(iter = 0; iter < 6; iter++)
    {
      int *permute;

      // create permutation
      permute = createPermutation(numInserts);

      // create B-tree
      TEST_CHECK(createBtree("testidx", DT_INT, 2));
      TEST_CHECK(openBtree(&tree, "testidx"));

      // insert keys
      for(i = 0; i < numInserts; i++)
        TEST_CHECK(insertKey(tree, keys[permute[i]], insert[permute[i]]));

      // check index stats
      TEST_CHECK(getNumEntries(tree, &testint));
      ASSERT_EQUALS_INT(testint, numInserts, "number of entries in btree");
      
      // execute scan, we should see tuples in sort order
      openTreeScan(tree, &sc);
      i = 0;
      while((rc = nextEntry(sc, &rid)) == RC_OK)
      {
        RID expRid = insert[i++];
        ASSERT_EQUALS_RID(expRid, rid, "did we find the correct RID?");
      }
      ASSERT_EQUALS_INT(RC_IM_NO_MORE_ENTRIES, rc, "no error returned by scan");
      ASSERT_EQUALS_INT(numInserts, i, "have seen all entries");
      closeTreeScan(sc);

      // cleanup
      TEST_CHECK(closeBtree(tree));
      TEST_CHECK(deleteBtree("testidx"));
      free(permute);
    }

  TEST_CHECK(shutdownIndexManager());
  freeValues(keys, numInserts);

  TEST_DONE();
}

// ************************************************************ 
int *
createPermutation (int size)
{
  int *result = (int *) malloc(size * sizeof(int));
  if(!result) {
	fprintf(stderr, "Memory allocation failed\n");
  }
  int i;

  for(i = 0; i < size; result[i] = i, i++);

  for(i = 0; i < 100; i++)
    {
      int l, r, temp;
      l = rand() % size;
      r = rand() % size;
      temp = result[l];
      result[l] = result[r];
      result[r] = temp;
    }
  
  return result;
}

// ************************************************************ 
Value **
createValues (char **stringVals, int size)
{
  Value **result = (Value **) malloc(sizeof(Value *) * size);
  if(!result) {
	fprintf(stderr, "Memory allocation failed\n");
  }
  int i;
  
  for(i = 0; i < size; i++)
    result[i] = stringToValue(stringVals[i]);

  return result;
}

// ************************************************************ 
void
freeValues (Value **vals, int size)
{
  while(--size >= 0)
    free(vals[size]);
  free(vals);
}

