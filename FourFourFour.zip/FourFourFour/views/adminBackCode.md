<!-- 
<!-- <body>
    <h4>Readonly 작업만 된 page 즉 SELECT 문 이것저것 다양한 조합 눈으로만 확인하는 페이지(여기서 CRUD 구현 노노 update insert 노노 불가능 페이지임)</h4>
    <p>      null 이랑 0이랑 똑같이 null 하나로만 보일 수 있음 주의</p>

    <% data.forEach(function(tableData) { %>
        <h2>Table: <%= tableData.table %></h2>
        <% if (tableData.data.length > 0) { %>
            <table>
                <thead>
                    <tr>
                        <th width="50"> </th>
                        <% Object.keys(tableData.data[0]).forEach(key => { %>
                            <th><%= key %></th>
                        <% }) %>
                    </tr>
                </thead>
                <tbody>
                    <% var i = 1; %>
                    <% tableData.data.forEach(function(val) { %>
                        <tr>
                            <td>Tuple_<%= i %></td>
                            <% Object.values(val).forEach(value => { %>
                                <td><%= (value === null || value === 0) ? 'null' : value %></td>
                            <% }) %>
                        </tr>
                        <% i = i + 1; %>
                    <% }) %>
                </tbody>
            </table>
        <% } else { %>
            <p>No data available for <%= tableData.table %>.</p>
        <% } %>
    <% }) %>
</body> --> -->
