
const express = require('express');
const path = require('path');
const app = express();
const session = require('./config/session');
const userRoutes = require('./routes/userRoutes');
const orderRoutes = require('./routes/orderRoutes');
const sql_connection = require('./config/db');
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(session);
app.use('/', userRoutes);
app.use('/api', orderRoutes);
app.set("view engine", "ejs");
app.set("views", "./views");
app.set("views", path.join(__dirname, 'views'));
const cron = require('node-cron');
app.get('/', (req, res) => {
    res.render('sitemapDeveloperPage');
});

// under test, 내역 검색 API
app.get('/api/timelyorder', async (req, res) => {
    
    let sql = `SELECT * from order_ WHERE CusAccNum = ?`;
    const params = [];
    params.push(req.session.CusId);
    if (req.query.period) {
        const period = req.query.period;
        let dateCondition = '';
        switch (period) {
            case 'today':
                dateCondition = 'DATE(order_.Timestamp_) = CURDATE()';
                break;
            case 'thisMonth':
                dateCondition = 'MONTH(order_.Timestamp_) = MONTH(CURDATE()) AND YEAR(order_.Timestamp_) = YEAR(CURDATE())';
                break;
            case 'lastMonth':
                dateCondition = 'MONTH(order_.Timestamp_) = MONTH(CURDATE() - INTERVAL 1 MONTH) AND YEAR(order_.Timestamp_) = YEAR(CURDATE())';
                break;
            case 'last3Months':
                dateCondition = 'order_.Timestamp_ >= NOW() - INTERVAL 3 MONTH';
                break;
            case 'lastYear':
                dateCondition = 'order_.Timestamp_ >= NOW() - INTERVAL 1 YEAR';
                break;
            default:
                break;
        }
        sql += ` AND ${dateCondition}`;
    }
    if (req.query.startDate_ && req.query.endDate_) {
        sql += ' AND order_.Timestamp_ BETWEEN ? AND ?';
        params.push(req.query.startDate_ + ' 00:00:00', req.query.endDate_ + ' 23:59:59'); // DATETIME 포맷에 맞춤
    }
    try {
        const [results] = await sql_connection.promise().query(sql, params);
        const orders = results;
        if (results && results.length > 0) {
            res.json({ orders: orders });
        } else {
            res.json({ orders: [] });
        }
    } catch(err) {
        console.log(err);
    }    
});



// under test, 거래 내역 검색 API
app.get('/api/trades', async (req, res) => {
    //
    let sql = `WITH transact_ AS (SELECT stock.StockName, order_.StockSymbol, transact.Timestamp_, transact.PricePerShare, transact.TradeQuantity, order_.OrderType FROM transact JOIN order_ ON transact.OrderId = order_.OrderId INNER JOIN stock ON order_.StockSymbol = stock.StockSymbol WHERE order_.CusAccNum = ? ORDER BY transact.Timestamp_ DESC) SELECT transact_.StockName, transact_.StockSymbol as Symbol, transact_.Timestamp_ as TradedTimeAt, transact_.PricePerShare as Price, transact_.TradeQuantity, transact_.OrderType as TradePosition FROM transact_ WHERE 1=1`;
    const params = [];
    params.push(req.session.CusId);
    if (req.query.period) {
        const period = req.query.period;
        let dateCondition = '';
        switch (period) {
            case 'today':
                dateCondition = 'DATE(transact_.Timestamp_) = CURDATE()';
                break;
            case 'thisMonth':
                dateCondition = 'MONTH(transact_.Timestamp_) = MONTH(CURDATE()) AND YEAR(transact_.Timestamp_) = YEAR(CURDATE())';
                break;
            case 'lastMonth':
                dateCondition = 'MONTH(transact_.Timestamp_) = MONTH(CURDATE() - INTERVAL 1 MONTH) AND YEAR(transact_.Timestamp_) = YEAR(CURDATE())';
                break;
            case 'last3Months':
                dateCondition = 'transact_.Timestamp_ >= NOW() - INTERVAL 3 MONTH';
                break;
            case 'lastYear':
                dateCondition = 'transact_.Timestamp_ >= NOW() - INTERVAL 1 YEAR';
                break;
            default:
                break;
        }
        sql += ` AND ${dateCondition}`;
    }
    if (req.query.startDate && req.query.endDate) {
        sql += ' AND transact_.Timestamp_ BETWEEN ? AND ?';
        params.push(req.query.startDate + ' 00:00:00', req.query.endDate + ' 23:59:59'); // DATETIME 포맷에 맞춤
    }
    try {
        const [results] = await sql_connection.promise().query(sql, params);
        if (results && results.length > 0) {
            res.json({ data: results });
        } else {
            res.json({ data: [] });
        }
    } catch(err) {
        console.log(err);
    }    
});




// Fetch all
const getAllStockSymbols = (callback) => {
    const query = 'SELECT StockSymbol FROM stock';
    sql_connection.query(query, (err, results) => {
        if (err) throw err;
        callback(results.map(row => row.StockSymbol));
    });
};
// Save closing price to stockpricehistory
const saveClosingPrice = (stockSymbol) => {
    
    sql_connection.query(`INSERT INTO stockpricehistory (StockSymbol, SharePrice, Timestamp_) VALUES (?, (SELECT SharePrice FROM stock WHERE StockSymbol = ?), ?) `, [stockSymbol, stockSymbol, new Date()], (err, results) => {
        if (err) throw err;

        if(results.length > 0) {
            //console.log(`saveClosingPrice:  results.length > 0`);
        } else {
            //console.log(`saveClosingPrice:  NOT results.length > 0 NOT`);
        }

    });

    
};

// Check if the market close time and determine if it should record every close price
cron.schedule('* * * * *', () => {
    const now = new Date();
    const currentHour = now.getHours(); // 1 ~ 23 .. 
    const currentMinute = now.getMinutes();

    // Check if market closes
    if (/**/currentHour === -1/*없앨거면좌항을없애면됨 20분마다로 셋하려면*/ && [15, 35, 55].includes(currentMinute)) { 
        console.log('** Market closed. Make Record closing prices... **');
        getAllStockSymbols((symbols) => {

            for (let i = 0; i < symbols.length; i++) {

                saveClosingPrice(symbols[i]);
            }
        });
    }
});






//
app.listen(3001, () => {
    console.log("서버 실행 중");
});







module.exports = app;



// DetailPriceSelection 알고리즘 <- 이건 지우지 말기 일단
/*

const queryDetailPricePercentageSelectionQ = `SELECT
    stocksymbol,
    stockpricehistory.shareprice AS previous_close_price
FROM
    stockpricehistory
WHERE
    timestamp_ = (SELECT MAX(timestamp_) FROM stockpricehistory WHERE stocksymbol = ?)
    and stocksymbol = ?`;

 let page = ejs.render(detailPercentPage, {
                data: results,
            });
            res.send(page);

sql connection query (queryDetailPricePercentageSelectionQ, [ss, ss], () => {} */



