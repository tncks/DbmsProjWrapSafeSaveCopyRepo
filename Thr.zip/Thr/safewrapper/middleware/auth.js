//const session = require('express-session');

var checkerDEbug_CNT = 0;

function isAuthenticated(req, res, next) {
    checkerDEbug_CNT = checkerDEbug_CNT + 1;
    console.log('checkerCNT: ', checkerDEbug_CNT);
    if (req.session.userID) {
        console.log('*IF*: checkerCNT: ', checkerDEbug_CNT);
        return next();
    }
    // userId가 없으면 로그인 페이지로 리디렉션
    res.redirect('/login');
}

module.exports = isAuthenticated;
