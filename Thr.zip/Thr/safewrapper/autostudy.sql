DELIMITER $$

CREATE PROCEDURE MatchOrders()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE orderId INT;
    DECLARE stock VARCHAR(5);
    DECLARE numShares INT;
    DECLARE orderType VARCHAR(4);
    DECLARE priceType VARCHAR(15);
    DECLARE stopPrice FLOAT;
    DECLARE matchedOrderId INT;
    DECLARE matchedShares INT;
    DECLARE pricePerShare FLOAT;
    DECLARE transFee FLOAT;
    DECLARE accNum INT;

    DECLARE cur CURSOR FOR
        SELECT OrderId, StockSymbol, NumShares, OrderType, PriceType, StopPrice, CusAccNum
        FROM order_
        WHERE Completed = 0
        ORDER BY StockSymbol, OrderType, Timestamp_;

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        -- Log error details here
        ROLLBACK; -- Roll back the transaction on error
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'An error occurred during order processing';
    END;

    -- Start single transaction
    START TRANSACTION;

    OPEN cur;

    read_loop: LOOP
        FETCH cur INTO orderId, stock, numShares, orderType, priceType, stopPrice, accNum;
        IF done THEN
            LEAVE read_loop;
        END IF;

        -- 예수금 처리 (Cash Balance Check)
        IF priceType = 'MARKET' AND orderType = 'BUY' THEN
            IF (SELECT CashBalance FROM account_ WHERE AccNum = accNum) < (numShares * pricePerShare) THEN
                SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Insufficient cash balance for the buy order';
            END IF;
        END IF;

        -- 매도 주문 처리 (Sell Order Validation)
        IF orderType = 'SELL' THEN
            DECLARE currentShares INT;

            SELECT NumShares INTO currentShares 
            FROM portfolio 
            WHERE StockSymbol = stock AND AccNum = accNum 
            FOR UPDATE; -- Pessimistic Locking

            IF currentShares < numShares THEN
                SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Insufficient shares for the sell order';
            END IF;
        END IF;

        -- 시장가 및 지정가 주문 처리
        DECLARE matchedOrderFound BOOLEAN DEFAULT FALSE;

        IF priceType = 'MARKET' THEN
            SET matchedOrderFound = EXISTS (SELECT 1 FROM order_ WHERE StockSymbol = stock AND OrderType != orderType AND Completed = 0);
        ELSEIF priceType = 'LIMIT' THEN
            SET matchedOrderFound = EXISTS (SELECT 1 FROM order_ WHERE StockSymbol = stock AND OrderType != orderType AND Completed = 0 AND CurSharePrice <= stopPrice);
        END IF;

        IF matchedOrderFound THEN
            SELECT OrderId, NumShares, CurSharePrice INTO matchedOrderId, matchedShares, pricePerShare
            FROM order_
            WHERE StockSymbol = stock 
              AND OrderType != orderType 
              AND Completed = 0 
              AND (priceType = 'MARKET' OR (priceType = 'LIMIT' AND CurSharePrice <= stopPrice))
            ORDER BY Timestamp_ 
            LIMIT 1;

            -- 거래 기록 추가 및 포트폴리오 업데이트를 위한 공통 블록
            SET transFee = numShares * 0.01; -- 거래 수수료 1%

            INSERT INTO transact (OrderId, TransFee, PricePerShare)
            VALUES (orderId, transFee, pricePerShare);

            UPDATE portfolio
            SET NumShares = COALESCE(NumShares, 0) + LEAST(numShares, matchedShares)
            WHERE StockSymbol = stock AND AccNum = accNum;

            UPDATE order_ 
            SET NumShares = NumShares - LEAST(numShares, matchedShares), Completed = CASE WHEN NumShares <= LEAST(numShares, matchedShares) THEN 1 ELSE 0 END 
            WHERE OrderId IN (orderId, matchedOrderId);

            -- 남은 수량이 0이면 주문을 기록하고 삭제
            IF (SELECT NumShares FROM order_ WHERE OrderId = orderId) = 0 THEN
                INSERT INTO order_history (OrderId, Timestamp_, Status) 
                VALUES (orderId, NOW(), 'DELETED');
                DELETE FROM order_ WHERE NumShares = 0;
            END IF;
        END IF;
    END LOOP;

    CLOSE cur;

    -- Commit the entire transaction at the end
    COMMIT;
END $$

DELIMITER ;
